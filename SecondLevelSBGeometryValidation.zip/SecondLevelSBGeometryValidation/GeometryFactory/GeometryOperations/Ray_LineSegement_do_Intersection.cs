﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace SecondLevelSBValidation
{
    public class Coplane_Ray_LineSegement_do_Intersection
    {
        public Boolean Intersection = false;
        public Point3D IntersectionPoint = new Point3D(); // MUST initialization
        public double Distance = 0; // ray - intersection point

        public Coplane_Ray_LineSegement_do_Intersection(Ray3D ray, LineSegment3D LineSegment)
        {
            // determination of the relationship between ray and linesegement
            Vector3D vector = new Vector3D();
            Vector3D Vline = vector.VectorConstructor(LineSegment.StartPoint, LineSegment.EndPoint);

            if (vector.IsParallel(ray.Direction, Vline)) // overlap or parallel
            {
                Vector3D V1 = vector.VectorConstructor(ray.StartPoint, LineSegment.StartPoint);
                Vector3D V2 = vector.VectorConstructor(ray.StartPoint, LineSegment.EndPoint);
                if (vector.IsParallel(V1, Vline)) // ray overlap with the line segement
                {
                    if (vector.IsEqual(vector.UnitVector(V1), vector.UnitVector(V2))) // ray startpoint in the out of line segement
                    {
                        if (vector.IsEqual(vector.UnitVector(V1), vector.UnitVector(ray.Direction))) // intersect
                        {
                            Intersection = true;
                            Point3D point = new Point3D();
                            double D1 = point.Distance(ray.StartPoint, LineSegment.StartPoint);
                            double D2 = point.Distance(ray.StartPoint, LineSegment.EndPoint);
                            if (D1 > D2)
                            {
                                Distance = D2;
                                IntersectionPoint = LineSegment.EndPoint;
                            }
                            else
                            {
                                Distance = D1;
                                IntersectionPoint = LineSegment.StartPoint;
                            }
                        }
                        else
                        {
                            Intersection = false;
                        }
                    }
                    else // start point in the scope of line segement--- intersect
                    {
                        Intersection = true;
                        Distance = 0;
                        IntersectionPoint = ray.StartPoint;
                    }
                }
                else // ray parallel with the line segement in the same plane
                {
                    Intersection = false;
                }
            }

            else // ray neither parallel nor overlap with line segeemnt
            {
                Vector3D vector1 = new Vector3D();
                Vector3D OA = vector1.VectorConstructor(ray.StartPoint, LineSegment.StartPoint);
                Vector3D AB = Vline;
                double f1 = 0;
                double f2 = 0;

                double fz = AB.x * ray.Direction.y - AB.y * ray.Direction.x;
                double fy = AB.x * ray.Direction.z - AB.z * ray.Direction.x;
                double fx = AB.y * ray.Direction.z - AB.z * ray.Direction.y;

                if (fz != 0)
                {
                    f1 = (OA.y * ray.Direction.x - OA.x * ray.Direction.y) / fz;
                }
                else if (fy != 0)
                {
                    f1 = (OA.z * ray.Direction.x - OA.x * ray.Direction.z) / fy;
                }
                else if (fx != 0)
                {
                    f1 = (OA.z * ray.Direction.y - OA.y * ray.Direction.z) / fx;
                }

                if (ray.Direction.x != 0)
                {
                    f2 = (f1 * AB.x + OA.x) / ray.Direction.x;
                }
                else if (ray.Direction.y != 0)
                {
                    f2 = (f1 * AB.y + OA.y) / ray.Direction.y;
                }
                else if (ray.Direction.z != 0)
                {
                    f2 = (f1 * AB.z + OA.z) / ray.Direction.z;
                }


                if (f2 > 0)
                {
                    if (f1 >= 0 && f1 <= 1)
                    {
                        double checkz = OA.z + f1 * AB.z;
                        double check = f2 * ray.Direction.z;
                        if (check == checkz)
                        {
                            Intersection = true;
                            IntersectionPoint.x = ray.StartPoint.x + f2 * ray.Direction.x;
                            IntersectionPoint.y = ray.StartPoint.y + f2 * ray.Direction.y;
                            IntersectionPoint.z = ray.StartPoint.z + f2 * ray.Direction.z;
                            Point3D point = new Point3D();
                            Distance = point.Distance(ray.StartPoint, IntersectionPoint);
                        }
                    }
                }
                else Intersection = false;
            }
        }
    }
}
