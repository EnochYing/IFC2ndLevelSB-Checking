﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecondLevelSBValidation
{
    public class Vector3D
    {
        public double x = 0;
        public double y = 0;
        public double z = 0;

        public Vector3D()
        {

        }

        public Vector3D(double x, double y, double z)
        {
            this.x = x;
            this.y = y;
            this.z = z;
        }
        public Vector3D NewVector(Point3D A)
        {
            Vector3D Vector = new Vector3D();
            Vector.x = A.x;
            Vector.y = A.y;
            Vector.z = A.z;

            return Vector;
        }

        public Vector3D NewVector (double x, double y,double z)
        {
            Vector3D Vector = new Vector3D();
            Vector.x = x;
            Vector.y = y;
            Vector.z = z;

            return Vector;
        }

        // vector length
        public double VectorLength(Vector3D A)
        {
            double VL = 0;
            VL = Math.Sqrt(A.x * A.x + A.y * A.y + A.z * A.z);
            
            return VL;
        }

        public Vector3D VectorConstructor (Point3D A, Point3D B)
        {
            Vector3D _Vector = new Vector3D();
            _Vector.x = B.x - A.x;
            _Vector.y = B.y - A.y;
            _Vector.z = B.z - A.z;
            return _Vector;
        }
    
        // create unit vector to represent the axis direction
        public Vector3D UnitVector(Vector3D _Point3D)
        {
            Vector3D _Axis = new Vector3D();
            double k = Math.Sqrt(_Point3D.x * _Point3D.x + _Point3D.y * _Point3D.y + _Point3D.z * _Point3D.z);
            if (k != 0)
            {
                _Axis.x = _Point3D.x / k;
                _Axis.y = _Point3D.y / k;
                _Axis.z = _Point3D.z / k;
                return _Axis;
            }
            else return _Point3D;
        }

        // Vector - Vector
        public Vector3D Subtraction (Vector3D A, Vector3D B)
        {
            Vector3D _Vector3D = new Vector3D();
            _Vector3D.x = B.x - A.x;
            _Vector3D.y = B.y - A.y;
            _Vector3D.z = B.z - A.z;

            return _Vector3D;
        }

        // Vector + Vector
        public Vector3D Addition(Vector3D A, Vector3D B)
        {
            Vector3D _Vector3D = new Vector3D();
            _Vector3D.x = B.x + A.x;
            _Vector3D.y = B.y + A.y;
            _Vector3D.z = B.z + A.z;

            return _Vector3D;
        }

        // number * Vector
        public Vector3D Multiply_double_Vector3D(double A, Vector3D B)
        {
            Vector3D _Vector3D = new Vector3D();
            _Vector3D.x = B.x * A;
            _Vector3D.y = B.y * A;
            _Vector3D.z = B.z * A;

            return _Vector3D;
        }

        // Dot product
        // When the A is a unit vector and B represents a vertex then Dot Product represents the projection of B on the A axis 
        public double DotProduct (Vector3D A, Vector3D B)
        {
            double DP = 0;
            DP = A.x * B.x + A.y * B.y + A.z * B.z;

            return DP;
        }

        // Cross product: a vector that is vectial to the A and B according to the right hand rule from A to B
        // When A and B are unit vector and their angle is 90 degree, the cross product is unit vector
        public Vector3D CrossProduct (Vector3D A, Vector3D B)
        {
            Vector3D CP = new Vector3D();
            CP.x = A.y * B.z - B.y * A.z;
            CP.y = (-1) * (A.x * B.z - B.x * A.z);
            CP.z = A.x * B.y - B.x * A.y;

            return CP;
        }

        // Vector A = Vector B: direction 
        // should compare the angle difference instead of taking them as 3D points which is another story
        // two vectors should be unit vectors
        public bool IsEqual(Vector3D UnitA, Vector3D UnitB)
        {
            double cos = UnitA.x * UnitB.x + UnitA.y * UnitB.y + UnitA.z * UnitB.z;

            double dDeff_cos = Math.Abs(cos - 1);

            if (dDeff_cos < 0.00001)         
                    return true;
            else
                return false;
        }

        // Vector A // VectorB
        public bool IsParallel (Vector3D A, Vector3D B)
        {
            bool Parallel = false;
            Vector3D vector = new Vector3D();
            Vector3D UA = vector.UnitVector(A);
            Vector3D UB = vector.UnitVector(B);
            Vector3D UB1 = vector.Multiply_double_Vector3D(-1.0,UB);

            if (vector.IsEqual(UA,UB) || vector.IsEqual(UA, UB1))
            {
                Parallel = true;
            }

            return Parallel;
        }

        public bool IsSameDirection(Vector3D A, Vector3D B)
        {
            Vector3D vector = new Vector3D();
            Vector3D UA = vector.UnitVector(A);
            Vector3D UB = vector.UnitVector(B);

            if (vector.IsEqual(UA, UB))
                return true;
            else
                return false;
        }
    }

    public class Vector2D
    {
        public double x = 0;
        public double y = 0;

        public Vector2D VectorConstructor(Point2D A, Point2D B)
        {
            Vector2D _Vector = new Vector2D();
            _Vector.x = B.x - A.x;
            _Vector.y = B.y - A.y;
            return _Vector;
        }



        // Vector A // VectorB
        public bool IsParallel(Vector2D A, Vector2D B)
        {
            bool Parallel = false;
            Vector2D vector = new Vector2D();
            Vector2D UA = vector.UnitVector(A);
            Vector2D UB = vector.UnitVector(B);
            Vector2D UB1 = vector.Multiply_double_Vector2D(-1.0, UB);

            if (vector.IsEqual(UA, UB) || vector.IsEqual(UA, UB1))
            {
                Parallel = true;
            }

            return Parallel;
        }

        // create unit vector to represent the axis direction
        public Vector2D UnitVector(Vector2D _Point2D)
        {
            Vector2D _Axis = new Vector2D();
            double k = Math.Sqrt(_Point2D.x * _Point2D.x + _Point2D.y * _Point2D.y);
            if (k != 0)
            {
                _Axis.x = _Point2D.x / k;
                _Axis.y = _Point2D.y / k;
                return _Axis;
            }
            else return _Point2D;
        }

        // Vector A = Vector B: direction 
        // should compare the angle difference instead of taking them as 3D points which is another story
        // two vectors should be unit vectors
        public bool IsEqual(Vector2D UnitA, Vector2D UnitB)
        {
            double cos = UnitA.x * UnitB.x + UnitA.y * UnitB.y;

            double dDeff_cos = Math.Abs(cos - 1);

            if (dDeff_cos < 0.00001)
                return true;
            else
                return false;
        }

        // number * Vector
        public Vector2D Multiply_double_Vector2D(double A, Vector2D B)
        {
            Vector2D _Vector2D = new Vector2D();
            _Vector2D.x = B.x * A;
            _Vector2D.y = B.y * A;
  
            return _Vector2D;
        }

    }

}
