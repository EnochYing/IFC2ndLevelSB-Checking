﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecondLevelSBValidation
{
   public class IfcPolyline
    {
        private Polyline3D Polyline3D = new Polyline3D(); // Original representation in IFC: the start point may be the same with the endpoint; always 3D (if 2D in IFC set z = 0)
        public Polyline3D Polygon3D = new Polyline3D(); // Geometrical representation: the start point must be not same with the endpoint; always 3D (if 2D in IFC set z = 0)
        public List<Int64> IFCCartesianPointInstances_Not2D = new List<Int64>();

        public IfcPolyline(Int64 IfcPolylineInstance)
        {
            Int64 PointsInstance = 0;

            IfcEngine.sdaiGetAttrBN(IfcPolylineInstance, "Points", IfcEngine.sdaiAGGR, out PointsInstance);
            Int64 NumPointsInstance = IfcEngine.sdaiGetMemberCount(PointsInstance);
            if (NumPointsInstance != 0)
            {
                for (Int64 iPointsInstance = 0; iPointsInstance < NumPointsInstance; iPointsInstance++)
                {
                    Point2D _Point2D = new Point2D();      // must state here instead of out of the if statement, or a unexcepted error will occur 
                    Point3D _Point3D = new Point3D();
                    Int64 IFCCartesianPointInstance = 0;
                    IfcEngine.engiGetAggrElement(PointsInstance, iPointsInstance, IfcEngine.sdaiINSTANCE, out IFCCartesianPointInstance);
                    Int64 CartesianPointsCoordinateInstance = 0;
                    IfcEngine.sdaiGetAttrBN(IFCCartesianPointInstance, "Coordinates", IfcEngine.sdaiAGGR, out CartesianPointsCoordinateInstance);
                    Int64 NumCartesianPointsCoordinateInstance = IfcEngine.sdaiGetMemberCount(CartesianPointsCoordinateInstance);
                    if (NumCartesianPointsCoordinateInstance != 2)
                    {
                        IFCCartesianPointInstances_Not2D.Add(IFCCartesianPointInstance);
                    }

                    if (NumCartesianPointsCoordinateInstance != 0)
                    {
                        for (Int64 iCartesianPointsCoordinateInstance = 0; iCartesianPointsCoordinateInstance < NumCartesianPointsCoordinateInstance; iCartesianPointsCoordinateInstance++)
                        {
                            double CartesianCoordinates = 0;
                            IfcEngine.engiGetAggrElement(CartesianPointsCoordinateInstance, iCartesianPointsCoordinateInstance, IfcEngine.sdaiREAL, out CartesianCoordinates);
                            if (iCartesianPointsCoordinateInstance == 0)
                            {
                                _Point3D.x = CartesianCoordinates;
                            }
                            else if (iCartesianPointsCoordinateInstance == 1)
                            {
                                _Point3D.y = CartesianCoordinates;
                            }
                            else if (iCartesianPointsCoordinateInstance == 2)
                            {
                                _Point3D.z = CartesianCoordinates;
                            }
                        }
                        this.Polyline3D.Vertices.Add(_Point3D);
                    }
                }

                Point3D p = new Point3D();
                if (p.IsSamePoint(this.Polyline3D.Vertices[0], this.Polyline3D.Vertices[this.Polyline3D.Vertices.Count - 1], 10))
                {
                    for (int i = 0; i < this.Polyline3D.Vertices.Count - 1; i++)
                    {
                        this.Polygon3D.Vertices.Add(this.Polyline3D.Vertices[i]);
                    }
                }
                else
                {
                    for (int i = 0; i < this.Polyline3D.Vertices.Count; i++)
                    {
                        this.Polygon3D.Vertices.Add(this.Polyline3D.Vertices[i]);
                    }
                }
            }
        }
    }
}
