﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace SecondLevelSBValidation
{
   public class Ray3D_AABB_do_Intersection
    {
        // Amy Williams, Steve Barrus, R. Keith Morley, and Peter Shirley: "An
        // Efficient and Robust Ray-Box Intersection Algorithm" Journal of graphics tools, 10(1):49-54, 2005
        // This described algorithm using IEEE numerical properties to ensure the intersection test is both robust and efficient

        public bool Test(Ray3D Ray, BoundingBox3D BoundingBox)
        {
            double txmin;
            double txmax;
            double tymin;
            double tymax;
            double tzmin;
            double tzmax;

            Vector3D InRayDir = new Vector3D();
            InRayDir.x = 1 / Ray.Direction.x;   // Can store in the Ray structure instead of calculting in each time of ray - box inersection test 
            InRayDir.y = 1 / Ray.Direction.y;   // Can store in the Ray structure instead of calculting in each time of ray - box inersection test 
            InRayDir.z = 1 / Ray.Direction.z;   // Can store in the Ray structure instead of calculting in each time of ray - box inersection test 

            if (InRayDir.x >= 0)
            {
                txmin = (BoundingBox.xmin - Ray.StartPoint.x) * InRayDir.x;
                txmax = (BoundingBox.xmax - Ray.StartPoint.x) * InRayDir.x;
            }
            else
            {
                txmin = (BoundingBox.xmax - Ray.StartPoint.x) * InRayDir.x;
                txmax = (BoundingBox.xmin - Ray.StartPoint.x) * InRayDir.x;
            }

            if (InRayDir.y >= 0)
            {
                tymin = (BoundingBox.ymin - Ray.StartPoint.y) * InRayDir.y;
                tymax = (BoundingBox.ymax - Ray.StartPoint.y) * InRayDir.y;
            }
            else
            {
                tymin = (BoundingBox.ymax - Ray.StartPoint.y) * InRayDir.y;
                tymax = (BoundingBox.ymin - Ray.StartPoint.y) * InRayDir.y;
            }

            if ((txmin > tymax) || (tymin > txmax))
            {
                return false;
            }

            if (tymin > txmin)
            {
                txmin = tymin;
            }
            if (tymax < txmax)
            {
                txmax = tymax;
            }

            if (InRayDir.z >= 0)
            {
                tzmin = (BoundingBox.zmin - Ray.StartPoint.z) * InRayDir.z;
                tzmax = (BoundingBox.zmax - Ray.StartPoint.z) * InRayDir.z;
            }
            else
            {
                tzmin = (BoundingBox.zmax - Ray.StartPoint.z) * InRayDir.z;
                tzmax = (BoundingBox.zmin - Ray.StartPoint.z) * InRayDir.z;
            }

            if ((txmin > tzmax) || (tzmin > txmax)) 
            {
                return false;
            }

            if (tzmin > txmin)
            {
                txmin = tzmin;
            }

            if (tzmax < txmax)
            {
                txmax = tzmax;
            }

            if (txmin < 0)
            {
                if (txmax < 0)
                // txmax = (ymax - r.y) / rd.y > 0 means the intersection point is on the "ray" instead of on the "line"  -- as long as the txmax >0, it will add the geometric meaning of "Ray"
                // txmax >= txmin --- always correct
                // txmax = 0 means that if a ray emitted from the surface of the box and point out of the box, the start point will be is recongnised as an intersection (obviously this is not necessary)!!!
                // txmax = tmin means that the instersection point is on the edges of the box (this is required)
                // For ray, the direction vector should be careful to distingusih from a line; as the slope of a ray is equal to the relevant line
                // therefore, the direction should be represented 

                {
                    return false;
                }
            }

            return true;
        }
    }
}
