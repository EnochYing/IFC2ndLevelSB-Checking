﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecondLevelSBValidation
{
    public class Triangle2D
    {
        public Point2D Vertex1 = new Point2D();
        public Point2D Vertex2 = new Point2D();
        public Point2D Vertex3 = new Point2D();
        public Vector3D NormalVector = new Vector3D();  // MUST be unit vector
        public List<Ray3D> MonteCarloRaySet = new List<Ray3D>(); // complex data structure shoule be instantited

    }

    public class Triangle3D
    {
        public Point3D Vertex1 = new Point3D();
        public Point3D Vertex2 = new Point3D();
        public Point3D Vertex3 = new Point3D();
        public Vector3D NormalVector = new Vector3D();
        public List<Ray3D> MonteCarloRaySet = new List<Ray3D>();  // complex data structure shoule be instantited

        public Vector3D ExtractTriangleSurfaceNormal(Triangle3D triangle)
        {
            Vector3D _SurfaceNormal = new Vector3D();
            Vector3D vector = new Vector3D();

            Vector3D AB = new Vector3D(); // A refers to the start point of the polyline, B refers to the second point
            Vector3D AD = new Vector3D(); // vector not co line with AB vector and the direction from AB to AD should be the direction of the polyline

            AB.x = triangle.Vertex2.x - triangle.Vertex1.x;
            AB.y = triangle.Vertex2.y - triangle.Vertex1.y;
            AB.z = triangle.Vertex2.z - triangle.Vertex1.z;

            AD.x = triangle.Vertex3.x - triangle.Vertex1.x;
            AD.y = triangle.Vertex3.y - triangle.Vertex1.y;
            AD.z = triangle.Vertex3.z - triangle.Vertex1.z;

            _SurfaceNormal = vector.UnitVector(vector.CrossProduct(AB, AD));
            return _SurfaceNormal;
        }
    }



    public class TriangleVector
    {
        public Vector3D Vertex1 = new Vector3D();
        public Vector3D Vertex2 = new Vector3D();
        public Vector3D Vertex3 = new Vector3D();
        public Vector3D NormalVector = new Vector3D(); // compute according to vertex 1->2->3
    }

}
