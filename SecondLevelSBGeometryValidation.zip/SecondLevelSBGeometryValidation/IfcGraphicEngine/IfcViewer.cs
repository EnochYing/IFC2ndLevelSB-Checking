﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecondLevelSBValidation
{
    // Most of code for this class come from http://rdf.bg/ifc-engine-dll.php; 
    // interface: 接口，用于描述一组类的公共方法/公共属性. 它不实现任何的方法或属性; 只是告诉继承它的类必须至少要实现哪些功能; 继承它的类可以增加自己的方法 
    public interface IfcViewer  
    {
        /// <summary>
        /// Accessor
        /// </summary>
        IfcRenderer Renderer
        {
            get;
            set;
        }

        /// <summary>
        /// An IFC item has been selected
        /// </summary>
        /// <param name="ifcItem"></param>
        void OnSelect(IfcItem ifcItem);
    }
}
