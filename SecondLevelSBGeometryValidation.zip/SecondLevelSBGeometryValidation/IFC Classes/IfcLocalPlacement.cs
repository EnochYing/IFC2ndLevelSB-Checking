﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecondLevelSBValidation
{
    public class IfcLocalPlacement
    {
        public List<double[,]> TransfMatrixChainToRoot = new List<double[,]>();
        public double[,] TransforMatrixToRoot = new double[4, 4];                  // Transformation from current placement to the LCS of IfcSite

        //The lowest-level (current) LCS for the object (May also refer to IfcAxis2Placement2D); 
        //actually we can directly use TransfMatrixChainToRoot[0]
        //public IfcAxis2Placement3D RelativePlacement; 

        public IfcLocalPlacement(Int64 IfcLocalPlacementInstance)
        {
            this.TransfMatrixChainToRoot = TransfMatrixChain(IfcLocalPlacementInstance);

            //Int64 IfcAxis2Placement3DInstance = 0;
            //IfcEngine.sdaiGetAttrBN(IfcLocalPlacementInstance, "RelativePlacement", IfcEngine.sdaiINSTANCE, out IfcAxis2Placement3DInstance);
            //this.RelativePlacement = new IfcAxis2Placement3D(IfcAxis2Placement3DInstance);

            double[,] TM = this.TransfMatrixChainToRoot[this.TransfMatrixChainToRoot.Count - 1];
            AffineTR2 MatrixMultiply = new AffineTR2();
            for (int i = this.TransfMatrixChainToRoot.Count - 2; i >= 0; i--) // 矩阵乘法不一定满足交换律
            {
                TM = MatrixMultiply.TRMatrix(TM, this.TransfMatrixChainToRoot[i]);
            }
            this.TransforMatrixToRoot = TM;
        }

        private List<double[,]> TransfMatrixChain(Int64 IfcLocalPlacementInstance)
        {
            List<double[,]> MatrixChain = new List<double[,]>();

            Int64 IfcAxis2Placement3DInstance = 0;
            IfcEngine.sdaiGetAttrBN(IfcLocalPlacementInstance, "RelativePlacement", IfcEngine.sdaiINSTANCE, out IfcAxis2Placement3DInstance);
            IfcAxis2Placement3D Axis2Placement3D = new IfcAxis2Placement3D(IfcAxis2Placement3DInstance);
            AffineTR _AffineTR = new AffineTR();
            double[,] TRMatrix = _AffineTR.TRMatrix(Axis2Placement3D.LCSLocation, Axis2Placement3D.LCSxAxis, Axis2Placement3D.LCSzAxis);
            MatrixChain.Add(TRMatrix);

            Int64 ParentLocalPlacement = 0;
            IfcEngine.sdaiGetAttrBN(IfcLocalPlacementInstance, "PlacementRelTo", IfcEngine.sdaiINSTANCE, out ParentLocalPlacement);

            if (ParentLocalPlacement != 0)
            {
                List<double[,]> TransfMatrixToRoot_1 = TransfMatrixChain(ParentLocalPlacement);
                MatrixChain.AddRange(TransfMatrixToRoot_1);
            }

            return MatrixChain;
        }
    }
}
