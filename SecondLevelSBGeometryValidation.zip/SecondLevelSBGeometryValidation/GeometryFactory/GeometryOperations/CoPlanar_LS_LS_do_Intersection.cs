﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MathNet.Numerics.LinearAlgebra;

namespace SecondLevelSBValidation
{
    public class Coplanar_LS_LS_do_Intersection
    {
        public bool Result = false;

        //public Coplanar_LS_LS_do_Intersection(LineSegment3D AB, LineSegment3D CD)
        //{
        //    Point3D point = new Point3D();
        //    Vector3D vector = new Vector3D();
        //    Vector3D vector_AB = vector.VectorConstructor(AB.StartPoint, AB.EndPoint);
        //    Vector3D vector_CD = vector.VectorConstructor(CD.StartPoint, CD.EndPoint);
        //    Vector3D vector_AC = vector.VectorConstructor(AB.StartPoint, CD.StartPoint);

        //    bool isParallel = vector.IsParallel(vector_AB, vector_CD);
        //    if (isParallel) // two line sgement is parallel or overlap
        //    {
        //        if (new IsPointOnLineSegment(CD.StartPoint, AB).Result || new IsPointOnLineSegment(CD.EndPoint, AB).Result) // AB and CD is coline and have an overlap
        //            Result = true;
        //        else if (new IsPointOnLineSegment(AB.StartPoint, CD).Result || new IsPointOnLineSegment(AB.EndPoint, CD).Result)
        //            Result = true;
        //        else
        //            Result = false;
        //    }
        //    else
        //    {
        //        // construct matrix
        //        double[,] Transfer = new double[3, 3];
        //        Transfer[0, 0] = vector_AB.x;
        //        Transfer[1, 0] = vector_AB.y;
        //        Transfer[2, 0] = vector_AB.z;

        //        Transfer[0, 1] = vector_CD.x * (-1);
        //        Transfer[1, 1] = vector_CD.y * (-1);
        //        Transfer[2, 1] = vector_CD.z * (-1);

        //        Transfer[0, 2] = 0;
        //        Transfer[1, 2] = 0;
        //        Transfer[2, 2] = 0;

        //        MatrixBuilder<double> M = Matrix<double>.Build;
        //        Matrix<double> transfer = M.DenseOfArray(Transfer);
        //        VectorBuilder<double> V = Vector<double>.Build;
        //        double[] right = { vector_AC.x, vector_AC.y, vector_AC.z };
        //        Vector<double> Right = V.DenseOfArray(right);
        //        Vector<double> parameters = transfer.LU().Solve(Right);

        //        if (parameters[0] >= 0 && parameters[0] <= 1) // tolerance setting???
        //        {
        //            if (parameters[1] >= 0 && parameters[1] <= 1) // tolerance setting???
        //                Result = true;
        //        }
        //    }
        //}
    }
}
