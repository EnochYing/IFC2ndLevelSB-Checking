﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecondLevelSBValidation
{
    public class Point2D
    {
        public double x;
        public double y;

        public bool EqualsPoint(Point2D newPoint)
        {

            double dDeff_X = Math.Abs(x - newPoint.x);
            double dDeff_Y = Math.Abs(y - newPoint.y);

            if ((dDeff_X < ConstantValue.SmallValue) && (dDeff_Y < ConstantValue.SmallValue))
                return true;
            else
                return false;
        }

       

        public static bool SamePoints(Point2D Point1, Point2D Point2)
        {
            double dDeff_X = Math.Abs(Point1.x - Point2.x);
            double dDeff_Y = Math.Abs(Point1.y - Point2.y);

            if ((dDeff_X < ConstantValue.SmallValue*10) && (dDeff_Y < ConstantValue.SmallValue*10))
                return true;
            else
                return false;
        }

        public bool SamePoint(Point2D Point1, Point2D Point2)
        {
            double dDeff_X = Math.Abs(Point1.x - Point2.x);
            double dDeff_Y = Math.Abs(Point1.y - Point2.y);

            if ((dDeff_X < ConstantValue.SmallValue*10) && (dDeff_Y < ConstantValue.SmallValue*10))
                return true;
            else
                return false;
        }
        public bool InLine(LineSegment lineSegment)
        {
            bool bInline = false;

            double Ax, Ay, Bx, By, Cx, Cy;
            Bx = lineSegment.EndPoint.x;
            By = lineSegment.EndPoint.y;
            Ax = lineSegment.StartPoint.x;
            Ay = lineSegment.StartPoint.y;
            Cx = this.x;
            Cy = this.y;

            double L = lineSegment.GetLineSegmentLength();
            double s = Math.Abs(((Ay - Cy) * (Bx - Ax) - (Ax - Cx) * (By - Ay)) / (L * L));

            if (Math.Abs(s - 0) < ConstantValue.SmallValue)
            {
                if ((SamePoints(this, lineSegment.StartPoint)) ||
                    (SamePoints(this, lineSegment.EndPoint)))
                    bInline = true;
                else if ((Cx < lineSegment.GetXmax())
                    && (Cx > lineSegment.GetXmin())
                    && (Cy < lineSegment.GetYmax())
                    && (Cy > lineSegment.GetYmin()))
                    bInline = true;
            }
            return bInline;
        }

        // -
        public Point2D Subtraction(Point2D A, Point2D B)
        {
            Point2D _Point2D = new Point2D();
            _Point2D.x = B.x - A.x;
            _Point2D.y = B.y - A.y;
            
            return _Point2D;
        }

        //  + 
        public Point2D Addition(Point2D A, Point2D B)
        {
            Point2D _Point2D = new Point2D();
            _Point2D.x = B.x + A.x;
            _Point2D.y = B.y + A.y;
            
            return _Point2D;
        }

        // number * Point2D
        public Point2D Multiply_double_Point2D(double A, Point2D B)
        {
            Point2D _Point2D = new Point2D();
            _Point2D.x = B.x * A;
            _Point2D.y = B.y * A;
           
            return _Point2D;
        }

    }

    // should use public otherwise other project cannot use it 
    // while this project is referenced and the namespace is declared in other project
    //internla class can only be used in the same namespace
    public class Point3D
    {
        public double x;
        public double y;
        public double z;

        public Point3D()
        {

        }

        public Point3D(double x, double y, double z)
        {
            this.x = x;
            this.y = y;
            this.z = z;
        }

        //  - 
        public Point3D Subtraction(Point3D A, Point3D B)
        {
            Point3D _Point3D = new Point3D();
            _Point3D.x = B.x - A.x;
            _Point3D.y = B.y - A.y;
            _Point3D.z = B.z - A.z;

            return _Point3D;
        }

        //  + 
        public Point3D Addition(Point3D A, Point3D B)
        {
            Point3D _Point3D = new Point3D();
            _Point3D.x = B.x + A.x;
            _Point3D.y = B.y + A.y;
            _Point3D.z = B.z + A.z;

            return _Point3D;
        }

        // number * Point3D
        public Point3D Multiply_double_Point3D(double A, Point3D B)
        {
            Point3D _Point3D = new Point3D();
            _Point3D.x = B.x * A;
            _Point3D.y = B.y * A;
            _Point3D.z = B.z * A;

            return _Point3D;
        }

        public double Distance (Point3D A, Point3D B)
        {
            double Dis = 0;
            Dis = Math.Sqrt(Math.Pow((B.x - A.x), 2) + Math.Pow((B.y - A.y), 2) + Math.Pow((B.z - A.z), 2));

            return Dis;
        }

 
        public bool IsSamePoint(Point3D PointA, Point3D PointB, double toleranceScale)
        {
            double dDeff_X = Math.Abs(PointB.x - PointA.x);
            double dDeff_Y = Math.Abs(PointB.y - PointA.y);
            double dDeff_Z = Math.Abs(PointB.z - PointA.z);

            double tolerance = ConstantValue.SmallValue * toleranceScale; 

            if ((dDeff_X < tolerance) && (dDeff_Y < tolerance))
            {
                if (dDeff_Z < tolerance)
                {
                    return true;
                } else
                {
                    return false;
                }
            }                
            else
                return false;
        }
    }
}
