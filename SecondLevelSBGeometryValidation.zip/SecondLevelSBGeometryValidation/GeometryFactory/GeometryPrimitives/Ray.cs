﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace SecondLevelSBValidation
{
    public class Ray3D
    {
        public Point3D StartPoint = new Point3D();
        public Vector3D Direction = new Vector3D();  // should be unit vector

        public List<Ray3D> Rays_Triangle_MonteCarlo(Int64 NumRay, Triangle3D triangle3D)
        {
            // looser version to avoid too small gaps
            double tolerancePosition_d = 0.00001;
            double tolerancePosition_u = 0.99999;

            // rigorous version
            //double tolerancePosition_d = 0.0000001;
            //double tolerancePosition_u = 0.9999999;
            double tolerancePolarAngle = 89 / 90.0;
            List<Ray3D> RaySet = new List<Ray3D>();

            // A -> vertex 1; B -> vertex 2; C -> vertex 3
            Vector3D vector = new Vector3D();
            Point3D _Point3D = new Point3D();
            Point3D _A = triangle3D.Vertex1;
            Point3D _AB = _Point3D.Subtraction(triangle3D.Vertex1, triangle3D.Vertex2);
            Point3D _AC = _Point3D.Subtraction(triangle3D.Vertex1, triangle3D.Vertex3);

            Random RandomAB = new Random();
            Random RandomAC = new Random();
            Random Random_Azimuth = new Random();
            Random Random_Polar = new Random();

            for (Int64 i = 0; i < NumRay; i++)
            {
                Ray3D ray = new Ray3D();

                // 1. determine the start point of the ray set; 
                // the start point MUST locate in the interior of the triangle (on any of the three sides is not allowed)
                double k1 = RandomAB.NextDouble();  // return a double greater than or equal to 0.0
                if (k1 < tolerancePosition_d)
                    k1 = tolerancePosition_d;
                else if (k1 > tolerancePosition_u)
                    k1 = tolerancePosition_u;               

                double k2 = RandomAC.NextDouble();
                if (k2 < tolerancePosition_d)
                {
                    k2 = tolerancePosition_d;
                    if (k1 + k2 > tolerancePosition_u)
                        k1 = tolerancePosition_u - k2;
                }
                else if (k2 > tolerancePosition_u)
                {
                    k2 = tolerancePosition_u;
                    if (k1 + k2 > tolerancePosition_u)
                    {
                        k2 -= tolerancePosition_d;
                        k1 = tolerancePosition_d;
                    }                     
                } else
                {
                    if (k1 + k2 > tolerancePosition_u)
                    {
                        k2 = tolerancePosition_d;
                        k1 = tolerancePosition_u - tolerancePosition_d;
                    }
                }

                Point3D k1_AB = _Point3D.Multiply_double_Point3D(k1, _AB);
                Point3D k2_AC = _Point3D.Multiply_double_Point3D(k2, _AC);

                ray.StartPoint.x = _A.x + k1_AB.x + k2_AC.x;
                ray.StartPoint.y = _A.y + k1_AB.y + k2_AC.y;
                ray.StartPoint.z = _A.z + k1_AB.z + k2_AC.z;

                // 2. determine the direction of the start points
                // Introduce a new LCS: origin--endpoint; z--adverse surface normal; x-- endpoint-> vertex 1
                Vector3D Z = vector.Multiply_double_Vector3D(-1, triangle3D.NormalVector);
                Vector3D X = vector.UnitVector(vector.VectorConstructor(ray.StartPoint, triangle3D.Vertex1));
                Vector3D Y = yAxis(X, Z);

                double a = Math.PI * tolerancePolarAngle * Random_Polar.NextDouble() / 2; // Random1 != 1 -- Random.nextdouble() : Returns a random floating-point number that is greater than or equal to 0.0, and less than 1.0.
                double b = 2 * Math.PI * Random_Azimuth.NextDouble();
                double parameterX = Math.Sin(a) * Math.Cos(b);
                double parameterY = Math.Sin(a) * Math.Sin(b);
                double parameterZ = Math.Cos(a);

                ray.Direction.x = parameterX * X.x + parameterY * Y.x + parameterZ * Z.x;
                ray.Direction.y = parameterX * X.y + parameterY * Y.y + parameterZ * Z.y;
                ray.Direction.z = parameterX * X.z + parameterY * Y.z + parameterZ * Z.z;
                ray.Direction = vector.UnitVector(ray.Direction);

                RaySet.Add(ray);
            }
            return RaySet;
        }

        // calculate the unit vector of yAxis: right hand rule based on cross product 
        private Vector3D yAxis(Vector3D _xAxis, Vector3D _zAxis)
        {
            Vector3D _yAxis = new Vector3D();
            double x = 0;
            double y = 0;
            double z = 0;
            double d = 0;
            // when computing the cross product(k * i = |k| X |i| X sina X j)-- is not Dot Product, the z axis should be the second row. This ensures that the output of yaxis comply the right hand rule.
            x = _zAxis.y * _xAxis.z - _xAxis.y * _zAxis.z;
            y = (-1) * (_zAxis.x * _xAxis.z - _xAxis.x * _zAxis.z);
            z = _zAxis.x * _xAxis.y - _xAxis.x * _zAxis.y;
            d = Math.Sqrt(x * x + y * y + z * z);
            _yAxis.x = x / d;
            _yAxis.y = y / d;
            _yAxis.z = z / d;
            return _yAxis;
        }


        //// construct a ray set based on Monte Carlo method 
        //// the rays are located in a 2D triangle surface 
        //// the Normal of the triangle is z or -z 
        //// the angles between their direction and the TRIANGLE SURFACE NORMAL should not be more than 90 degree
        //public List<Ray3D> RaySetConstruction_TriangleSurface_MonteCarlo (Int64 NumRay, Triangle2D TriangleSurface)
        //{
        //    double tolerancePosition_d = 0.0001;
        //    double tolerancePosition_u = 0.9999;
        //    double toleranceAzimuthAngle = 88.0 / 90.0;  // double toleranceAzimuthAngle = 88 / 90; --- the value will be "0"
        //    List<Ray3D> RaySet = new List<Ray3D>();                                
        //    Point2D _Point2D = new Point2D();
        //    Point2D _A = TriangleSurface.Vertex1;
        //    Point2D _AB = _Point2D.Subtraction(TriangleSurface.Vertex1, TriangleSurface.Vertex2); 
        //    Point2D _AC = _Point2D.Subtraction(TriangleSurface.Vertex1, TriangleSurface.Vertex3);
        //    // A -> vertex 1; B -> vertex 2; C -> vertex 3：
        //    // according to the ordered vertices using right hand rule, the surface normal vector is adverse to the z direction of LCS that used to determine the direction of rays
        //    // Thus if the surface normal vector is same to the SB surface normal, the following is correct; if not, the cosa need time (-1);

        //    Random _RandomAB = new Random();  // must be out of the for loop otherwise the k1 will always be the same value
        //    Random _RandomAC = new Random();

        //    // determine the start point of the ray set; 
        //    // the start point MUST locate in the interior of the triangle (on any of the three sides is not allowed)
        //    for (Int64 i = 0; i < NumRay; i++)
        //    {
        //        Ray3D _Ray = new Ray3D();

        //        #region  give constraints on the random number generator ---time consuming
        //        //double k1 = _RandomAB.NextDouble();  // return a double greater than or equal to 0.0
        //        //while (k1 == 0)  // start point cannot on the 2nd side 
        //        //                 // give contraints to random number generator directly will be extremely time consuming !!!!!
        //        //{
        //        //    k1 = _RandomAB.NextDouble();
        //        //}
        //        //Point2D k1_AB = _Point2D.Multiply_double_Point2D(k1, _AB); // random cannot be assigned to a variable

        //        //double k2 = _RandomAC.NextDouble();
        //        //while (k2 == 0 || k1 + k2 >= 1)    // k1 + k2 < 1 -- start point on the 1st and 3rd side is not allowed
        //        //{
        //        //    k2 = _RandomAC.NextDouble();
        //        //}
        //        //Point2D k2_AC = _Point2D.Multiply_double_Point2D(k2, _AC);
        //        #endregion

        //        double k1 = _RandomAB.NextDouble();  // return a double greater than or equal to 0.0
        //        if (k1 < tolerancePosition_d)
        //        {
        //            k1 += tolerancePosition_d;
        //        }
        //        else if (k1 > tolerancePosition_u)
        //        {
        //            k1 -= tolerancePosition_d;
        //        }
        //        Point2D k1_AB = _Point2D.Multiply_double_Point2D(k1, _AB); // random cannot be assigned to a variable

        //        double limit = 1 - tolerancePosition_d;
        //        double k2 = _RandomAC.NextDouble();
        //        if (k2 == 0)
        //        {
        //            k2 += tolerancePosition_d;
        //        }
        //        if (k2 + k1 > limit)
        //        {
        //            k2 = limit - k1;
        //        }
        //        Point2D k2_AC = _Point2D.Multiply_double_Point2D(k2, _AC);

        //        _Ray.StartPoint.x = _A.x + k1_AB.x + k2_AC.x;
        //        _Ray.StartPoint.y = _A.y + k1_AB.y + k2_AC.y;
        //        _Ray.StartPoint.z = 0;
        //        RaySet.Add(_Ray);
        //    }

        //    //determine the direction of the start points
        //    //set a LCS on the startpoint, so the direction can be represented as (0,0,0) and (sinacosb, sinasinb,cosa)
        //    // the LCS reference to the CS of SB --- CS of space: z axis --- -(1) * surface normal of SB; x --- (1,0,0)

        //    Matrix_AffineRotation Matrix_AR = new Matrix_AffineRotation();
        //    Vector3D xAxis = new Vector3D(); // CS used for defining ray sets: related to the LCS of SB
        //    xAxis = xAxis.NewVector(1, 0, 0); // assume the local x is (1,0,0)
        //    Vector3D zAxis = new Vector3D();
        //    zAxis = zAxis.Multiply_double_Vector3D(-1, TriangleSurface.NormalVector);
        //    double[,] AR = Matrix_AR.RMatrix(xAxis,zAxis);

        //    Random Random1 = new Random();
        //    Random Random2 = new Random();
        //    for (int i = 0; i < NumRay; i++)
        //    {
        //        double a = Math.PI * toleranceAzimuthAngle * Random1.NextDouble() / 2; // Random1 != 1 -- Random.nextdouble() : Returns a random floating-point number that is greater than or equal to 0.0, and less than 1.0.
        //        double b = 2 * Math.PI * Random2.NextDouble();

        //        Vector3D LocalDir = new Vector3D();
        //        LocalDir.x = Math.Sin(a) * Math.Cos(b);  // lcs
        //        LocalDir.y = Math.Sin(a) * Math.Sin(b);  // lcs
        //        LocalDir.z = Math.Cos(a);                // lcs

        //        // Must emitted from the back side of the SB 
        //        // normal of triangled SB MUST be UNIT vector
        //        // the direction is adverse to the surface normal vector of the SB           

        //        Matrix_SurfaceNormalTransf transfer = new Matrix_SurfaceNormalTransf();
        //        Vector3D V = transfer.SurfaceNormalTransf(LocalDir, AR);
        //        RaySet[i].Direction = V.UnitVector(V); // cs of SB

        //    }
        //    return RaySet;
        //}

    }

    public class Ray2D
    {
        public Point2D StartPoint = new Point2D();
        public Vector2D Directon = new Vector2D();
    }
}
