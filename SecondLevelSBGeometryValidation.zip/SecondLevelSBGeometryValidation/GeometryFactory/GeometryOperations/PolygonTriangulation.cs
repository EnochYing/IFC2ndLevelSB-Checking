﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecondLevelSBValidation
{
    
    public class SimplePolygonEarClipping  // triangulate an polygon by clockwise direction; starting point MUST not be equal to the ending point  ----  Must consider the situations in IFCPolyline
    {
        // Triangulate arbitrary simple polygons using the ear clipping method proposed by 
        // ElGindy, H., Everett, H., Toussaint, G. T. (1993). "Slicing an ear using prune-and-search". Pattern Recognition Letters. 14 (9): 719–722
        // Simple polygon: flat shape consisting of straight, non-intersecting line segments or "sides" that are joined pair-wise to form a closed path; no holes; concave or convex
        // 2D triangulation; new vertices are not allowed; o(n*n)
        
        private Point2D[] InputVertices;
        private Point2D[] UpdatedPolygonVertices;

        private System.Collections.ArrayList m_alEars = new System.Collections.ArrayList();
        private Point2D[][] m_aPolygons; // baisc element is an array; is not equal to [,]

        public int NumberOfPolygons  // number of the final triangles
        {
            get
            {
                return m_aPolygons.Length;
            }
        }

        public Point2D[] Polygons(int index)  // store the triangles
        {
            if (index < m_aPolygons.Length)
                return m_aPolygons[index];
            else
                return null;
        }

        public SimplePolygonEarClipping(Point2D[] vertices)  // load the polygon that is to be triangulated
        {
            Int64 nVertices = vertices.Length;
            if (nVertices < 3)
            {
                System.Diagnostics.Trace.WriteLine("To make a polygon, " + " at least 3 points are required!");
                return;
            }

            //initalize the 2D points
            InputVertices = new Point2D[nVertices];

            for (int i = 0; i < nVertices; i++)
            {
                InputVertices[i] = vertices[i];
            }

            //make a working copy,  m_aUpdatedPolygonVertices are in count clock direction from user view
            SetUpdatedPolygonVertices();

        }

        /****************************************************
		To fill UpdatedPolygonVertices array with input array.
		
		UpdatedPolygonVertices is a working array that will be updated when an ear is cut till UpdatedPolygonVertices
		makes triangle (a convex polygon).
	   ******************************************************/
        private void SetUpdatedPolygonVertices()
        {
            Int64 nVertices = InputVertices.Length;
            UpdatedPolygonVertices = new Point2D[nVertices];

            for (int i = 0; i < nVertices; i++)
                UpdatedPolygonVertices[i] = InputVertices[i];

            //UpdatedPolygonVertices should be in count clock wise
            if (Polygon2D.PointsDirection(UpdatedPolygonVertices) == PolygonDirection.Clockwise)
            {
                Polygon2D.ReversePointsDirection(UpdatedPolygonVertices);
            }
                
        }

        /**********************************************************
		To check the Pt is in the Triangle or not.
		If the Pt is in the line or is a vertex, then return true.
		If the Pt is out of the Triangle, then return false.

		This method is used for triangle only.
		***********************************************************/
        private bool TriangleContainsPoint(Point2D[] trianglePts, Point2D pt)
        {
            if (trianglePts.Length != 3)
                return false;

            for (int i = trianglePts.GetLowerBound(0);i < trianglePts.GetUpperBound(0); i++)
            {
                if (pt.EqualsPoint(trianglePts[i]))
                    return true;
            }

            bool bIn = false;

            LineSegment line0 = new LineSegment(trianglePts[0], trianglePts[1]);
            LineSegment line1 = new LineSegment(trianglePts[1], trianglePts[2]);
            LineSegment line2 = new LineSegment(trianglePts[2], trianglePts[0]);

            if (pt.InLine(line0) || pt.InLine(line1)|| pt.InLine(line2))
                bIn = true;
            else //point is not in the lines
            {
                double dblArea0 = Polygon2D.PolygonArea(new Point2D[] {trianglePts[0],trianglePts[1], pt});
                double dblArea1 = Polygon2D.PolygonArea(new Point2D[] {trianglePts[1],trianglePts[2], pt});
                double dblArea2 = Polygon2D.PolygonArea(new Point2D[] {trianglePts[2],trianglePts[0], pt});

                if (dblArea0 > 0)
                {
                    if ((dblArea1 > 0) && (dblArea2 > 0))
                        bIn = true;
                }
                else if (dblArea0 < 0)
                {
                    if ((dblArea1 < 0) && (dblArea2 < 0))
                        bIn = true;
                }
            }
            return bIn;
        }

        /****************************************************************
		To check whether the Vertex is an ear or not based updated Polygon vertices

		ref. www-cgrl.cs.mcgill.ca/~godfried/teaching/cg-projects/97/Ian
		/algorithm1.html

		If it is an ear, return true,
		If it is not an ear, return false;
		*****************************************************************/
        private bool IsEarOfUpdatedPolygon(Point2D vertex)
        {
            Polygon2D polygon = new Polygon2D(UpdatedPolygonVertices);

            if (polygon.PolygonVertex(vertex))
            {
                bool bEar = true;
                if (polygon.PolygonVertexType(vertex) == VertexType.ConvexPoint)
                {
                    Point2D pi = vertex;
                    Point2D pj = polygon.PreviousPoint(vertex); //previous vertex
                    Point2D pk = polygon.NextPoint(vertex);//next vertex

                    for (int i = UpdatedPolygonVertices.GetLowerBound(0);
                        i < UpdatedPolygonVertices.GetUpperBound(0); i++)
                    {
                        Point2D pt = UpdatedPolygonVertices[i];
                        if (!(pt.EqualsPoint(pi) || pt.EqualsPoint(pj) || pt.EqualsPoint(pk)))
                        {
                            if (TriangleContainsPoint(new Point2D[] { pj, pi, pk }, pt))
                                bEar = false;
                        }
                    }
                } //ThePolygon.getVertexType(Vertex)=ConvexPt
                else  //concave point
                    bEar = false; //not an ear/
                return bEar;
            }
            else //not a polygon vertex;
            {
                System.Diagnostics.Trace.WriteLine("IsEarOfUpdatedPolygon: " +
                    "Not a polygon vertex");
                return false;
            }
        }

        /****************************************************
		Set up m_aPolygons: add ears and been cut Polygon togather
		****************************************************/
        private void SetPolygons()
        {
            int nPolygon = m_alEars.Count + 1; //ears plus updated polygon
            m_aPolygons = new Point2D [nPolygon][];

            for (int i = 0; i < nPolygon - 1; i++) //add ears
            {
                Point2D[] points = (Point2D[])m_alEars[i];

                m_aPolygons[i] = new Point2D[3]; //3 vertices each ear
                m_aPolygons[i][0] = points[0];
                m_aPolygons[i][1] = points[1];
                m_aPolygons[i][2] = points[2];
            }

            //add UpdatedPolygon:
            m_aPolygons[nPolygon - 1] = new Point2D[UpdatedPolygonVertices.Length];

            for (int i = 0; i < UpdatedPolygonVertices.Length; i++)
            {
                m_aPolygons[nPolygon - 1][i] = UpdatedPolygonVertices[i];
            }
        }

        /********************************************************
		To update m_aUpdatedPolygonVertices:
		Take out Vertex from m_aUpdatedPolygonVertices array, add 3 points
		to the m_aEars
		**********************************************************/
        private void UpdatePolygonVertices(Point2D vertex)
        {
            System.Collections.ArrayList alTempPts = new System.Collections.ArrayList();

            for (int i = 0; i < UpdatedPolygonVertices.Length; i++)
            {
                if (vertex.EqualsPoint(UpdatedPolygonVertices[i])) //add 3 pts to FEars
                {
                    Polygon2D polygon = new Polygon2D(UpdatedPolygonVertices);
                    Point2D pti = vertex;
                    Point2D ptj = polygon.PreviousPoint(vertex); //previous point
                    Point2D ptk = polygon.NextPoint(vertex); //next point

                    Point2D[] aEar = new Point2D[3]; //3 vertices of each ear
                    aEar[0] = ptj;
                    aEar[1] = pti;
                    aEar[2] = ptk;

                    m_alEars.Add(aEar);
                }
                else
                {
                    alTempPts.Add(UpdatedPolygonVertices[i]);
                } //not equal points
            }

            if (UpdatedPolygonVertices.Length- alTempPts.Count == 1)
            {
                int nLength = UpdatedPolygonVertices.Length;
                UpdatedPolygonVertices = new Point2D[nLength - 1];

                for (int i = 0; i < alTempPts.Count; i++)
                    UpdatedPolygonVertices[i] = (Point2D)alTempPts[i];
            }
        }
        /*******************************************************
    To cut an ear from polygon to make ears and an updated polygon:
    *******************************************************/
        public void CutEar()
        {
            Polygon2D polygon = new Polygon2D (UpdatedPolygonVertices);
            bool bFinish = false;

            //if (polygon.GetPolygonType()==PolygonType.Convex) //don't have to cut ear
            //	bFinish=true;

            if (UpdatedPolygonVertices.Length == 3) //triangle, don't have to cut ear
                bFinish = true;

            Point2D pt = new Point2D();
            while (bFinish == false) //UpdatedPolygon
            {
                int i = 0;
                bool bNotFound = true;
                while (bNotFound && (i < UpdatedPolygonVertices.Length)) //loop till find an ear
                {
                    pt = UpdatedPolygonVertices[i];
                    if (IsEarOfUpdatedPolygon(pt))
                        bNotFound = false; //got one, pt is an ear
                    else
                        i++;
                } //bNotFount
                  //An ear found:}
                if (pt != null)
                    UpdatePolygonVertices(pt);

                polygon = new Polygon2D (UpdatedPolygonVertices);
                //if ((polygon.GetPolygonType()==PolygonType.Convex)
                //	&& (m_aUpdatedPolygonVertices.Length==3))

                if (UpdatedPolygonVertices.Length == 3)
                    bFinish = true;
            } //bFinish=false

            SetPolygons();
        }

    }

    public class SimplePolygonTriangulation
    {
        // points in a Polyline2D should be stored orderly and the starting point and the ending point should not be the same --- IfcPolyline may occur    

        public List<Triangle2D> Triangulation(Polyline2D  _Polyline2D) 
        {
            Point2D _Point = new Point2D();
            bool flag = false;

            //because we need modify the input polyline, by assignning the input to a temp and modify the temp so that the original input will be not affected.
            // in C# this means the _Polyline2D is same to the temp; when the temp is modefied the _polyline2D will also modefied;
            int k = _Polyline2D.Vertices.Count;
            if (_Point.SamePoint(_Polyline2D.Vertices[0], _Polyline2D.Vertices[k - 1]))
            {
                _Polyline2D.Vertices.RemoveAt(k - 1);
                flag = true;
                // in IFCPolyline the starting point may also be the end point; in this case the repeated end point will be removed;
            }   // BUT BE careful!!! this will modify the input _Polyline2D
                // More reasonable method: assign the polyline 2D to a new temp; and modify the temp

            Point2D[] _Polygon= new Point2D [_Polyline2D.Vertices.Count];
            for (int i =0; i< _Polyline2D.Vertices.Count; i++)
            {
                _Polygon[i]= _Polyline2D.Vertices[i];
            }

            List<Triangle2D> _triangles = new List<Triangle2D>();
            SimplePolygonEarClipping _SimplePolygonEarClipping = new SimplePolygonEarClipping(_Polygon);
            _SimplePolygonEarClipping.CutEar();

            if (_SimplePolygonEarClipping == null)
            {
                return null;
            }

            for (int i = 0; i < _SimplePolygonEarClipping.NumberOfPolygons; i++)
            {
                int nPoints = _SimplePolygonEarClipping.Polygons(i).Length;   // actually Polygons(i) represent ith triangle
                Triangle2D _Triangle = new Triangle2D();
                List<Point2D> _Point2Ds = new List<Point2D>();               

                for (int j = 0; j < nPoints; j++)
                {
                    Point2D _Point2D = new Point2D();
                    _Point2D.x = _SimplePolygonEarClipping.Polygons(i)[j].x;
                    _Point2D.y = _SimplePolygonEarClipping.Polygons(i)[j].y;
                    _Point2Ds.Add(_Point2D);
                }
                _Triangle.Vertex1 = _Point2Ds[0];
                _Triangle.Vertex2 = _Point2Ds[1];
                _Triangle.Vertex3 = _Point2Ds[2];
                
                _triangles.Add(_Triangle);
            }

            if (flag) // if the last point of the _polyline2D has been removed
            {
                _Polyline2D.Vertices.Add(_Polyline2D.Vertices[0]); // add the removed point at the end to maintain the input polyline
            }

            return _triangles;
        }

    }


}
