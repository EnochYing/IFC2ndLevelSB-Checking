﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecondLevelSBValidation
{
    public class IfcDimensionalScale
    {
        public float scale = 1;  // mm

        // Pay attention to the UNIT of dimension: different Ifc files may have different UNIT for deminsion/length definition
        public IfcDimensionalScale(Int64 IfcModel)
        {   
            Int64 IfcSIUnitInstances = IfcEngine.sdaiGetEntityExtentBN(IfcModel, "IfcSIUnit");
            Int64 NumIfcSIUnitInstances = IfcEngine.sdaiGetMemberCount(IfcSIUnitInstances);
            for (int i = 0; i < NumIfcSIUnitInstances; i++)
            {
                Int64 IfcSIUnitInstance = 0;
                IfcEngine.engiGetAggrElement(IfcSIUnitInstances, i, IfcEngine.sdaiINSTANCE, out IfcSIUnitInstance);
                IfcSIUnit unit = new IfcSIUnit(IfcSIUnitInstance);
                if (unit.IsLenghthUnit)
                {
                    if (unit.Name == ".MILLI.")
                    {
                        scale = 1;
                    }
                    else if (unit.Name == ".CENTI.")
                    {
                        scale = 10;
                    }
                    else if (unit.Name == ".METRE.")
                    {
                        scale = 1000;
                    }
                    break;
                }
            }       
        }
    }
}
