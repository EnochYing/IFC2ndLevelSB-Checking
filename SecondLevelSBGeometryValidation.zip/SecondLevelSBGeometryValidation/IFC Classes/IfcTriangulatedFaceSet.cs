﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecondLevelSBValidation
{
    public class IfcTriangulatedFaceSet
    {
        // IFC schemam the data structure (Implicit representation): strorage saving, simplicity but cannot be straightforwardly used       
        public List<Point3D> CartesianPointList = new List<Point3D>();
        public List<double[]> CoordIndex = new List<double[]>();     // Must be double [3];
        public List<Point3D> NormalList = new List<Point3D>();       // Normal on the vertices;
        public List<double[]> NormalIndex = new List<double[]>();    // Must be double [3]

        // Explicit representation: one vertice coordinates are repeated in all relevant triangles; 
        // This may be problematic when the model is large and the geometry is extremely complex.
        public List<Triangle3D> ExplicitTriBrep = new List<Triangle3D>();
        public BoundingBox3D AABB = new BoundingBox3D();  // wrap the TriBrep with an AABB;

        public IfcTriangulatedFaceSet(Int64 IfcModel, Int64 IfcBuildingElementInstance)  // Generate 3D Triangulated Brep geometry for building elements
        {
            SetFormat(IfcModel);
            
            // calculted the space needed for storage: Numer of vertices and indices
            Int64 noVertices = 0;   // Number of the vertices
            Int64 noIndices = 0;    // Number of the indices
            IfcEngine.initializeModellingInstance(IfcModel, ref noVertices, ref noIndices, 0, IfcBuildingElementInstance);

            if (noVertices != 0 && noIndices != 0)
            {
                float[] vertexArray = new float[noVertices * 6];     //  array used for storing real vertices coordinates 
                Int32[] indexArray = new Int32[noIndices];           //  array used for storing the indeices
                IfcEngine.finalizeModelling(IfcModel, vertexArray, indexArray, 0);    // fill the actual data into relevant array

                //  Return the part of the index array representing the triangle set that visualizes the IFC instance
                //  Array's vertexArray and indexArray are filled with data.
                //  startIndex points to the first index in the indexArray of relevance
                //  In total 3 * primitiveCount elements on the indexArray represent all the triangles of the object.
                //  startVertex is a derived value and given as some applications can get performance gain from this information.               

                // extract the triangles and the surface normal 
                // all the coordinates are represented in the root CS (ifcsite)
                int NumTriangle = indexArray.Length / 3;
                int NumVertices = vertexArray.Length / 6;
                for (int i = 0; i < NumTriangle; i++)
                {
                    Triangle3D triangle = new Triangle3D();
                    int index_v1 = indexArray[i * 3 + 0];  // the index of the 1st vertex of the ith triangle 
                    int index_v2 = indexArray[i * 3 + 1];  // the index of the 2nd vertex of the ith triangle 
                    int index_v3 = indexArray[i * 3 + 2];  // the index of the 3rd vertex of the ith triangle 
                  
                    // vertex 1
                    triangle.Vertex1.x = vertexArray[index_v1 * 6 + 0];
                    triangle.Vertex1.y = vertexArray[index_v1 * 6 + 1];
                    triangle.Vertex1.z = vertexArray[index_v1 * 6 + 2];

                    // vertex 2
                    triangle.Vertex2.x = vertexArray[index_v2 * 6 + 0];
                    triangle.Vertex2.y = vertexArray[index_v2 * 6 + 1];
                    triangle.Vertex2.z = vertexArray[index_v2 * 6 + 2];

                    // vertex 3
                    triangle.Vertex3.x = vertexArray[index_v3 * 6 + 0];
                    triangle.Vertex3.y = vertexArray[index_v3 * 6 + 1];
                    triangle.Vertex3.z = vertexArray[index_v3 * 6 + 2];

                    // normal 
                    // Be careful: the surface nomal produced by IfcEngine is correct for the 3D solid (pointing outside) 
                    // but is not consistent to that computed based on the produced triangle using right-hand rule
                    triangle.NormalVector.x = vertexArray[index_v1 * 6 + 3];
                    triangle.NormalVector.y = vertexArray[index_v1 * 6 + 4];
                    triangle.NormalVector.z = vertexArray[index_v1 * 6 + 5];

                    // cannot compute the surface normal of the triangle belonging to a 3D solid as IfcEngine does not arrange the order of vertices for surface normal computation
                    // in  other words, the surface normal directly extracted is correct but is not consistent to the order of the vertices of the triangle
                    // triangle.NormalVector = triangle.ExtractTriangleSurfaceNormal(triangle); XXXXXX

                    // ******** NOTE: This function also applies to IfcRelSpaceBoundary, but for some Ifc files, the surface normal for a triangle may be adverse to the correct direction
                    // ******** This explain why in these files the visual surface of SBs are inside instead of outside 

                    this.ExplicitTriBrep.Add(triangle);
                }

                this.AABB = new BoundingBox3D(this.ExplicitTriBrep);
            }
        }

        private void SetFormat(Int64 IfcModel)
        {
            Int64 setting = 0, mask = 0;
            mask += IfcEngine.flagbit2;          //    PRECISION (32/64 bit)
            mask += IfcEngine.flagbit3;          //    INDEX ARRAY (32/64 bit)
            mask += IfcEngine.flagbit5;          //    NORMALS
            mask += IfcEngine.flagbit8;          //    TRIANGLES
            mask += IfcEngine.flagbit12;         //    WIREFRAME

            setting += 0;                        //    SINGLE PRECISION (float)
            setting += 0;                        //    32 BIT INDEX ARRAY (Int32)
            setting += IfcEngine.flagbit5;       //    NORMALS ON
            setting += IfcEngine.flagbit8;       //    TRIANGLES ON
            setting += 0;                        //    WIREFRAME OFF
            //setting += IfcEngine.flagbit12;    //    WIREFRAME ON
            IfcEngine.setFormat(IfcModel, setting, mask);
        }
    }
}


