﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecondLevelSBValidation
{
    public struct ConstantValue
    {
        public const double SmallValue = 0.000001;
        public const double BigValue = 99999;
    }

    public enum PolygonDirection
    {
        Unknown,
        Clockwise,
        Count_Clockwise
    }

    public enum PolylineDirection
    {
        Unknown,
        Clockwise,
        Count_Clockwise
    }

    public enum VertexType
    {
        ErrorPoint,
        ConvexPoint,
        ConcavePoint
    }

    public enum TopologicalRelationship
    {
        Contain,
        Intersection,
        Disjoint
    }
}
