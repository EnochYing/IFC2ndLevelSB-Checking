﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SharpDX.Direct3D9;

namespace SecondLevelSBValidation
{
    // Most of code for this class come from http://rdf.bg/ifc-engine-dll.php; 
    // interface: 接口，用于描述一组类的公共方法/公共属性. 它不实现任何的方法或属性; 只是告诉继承它的类至少要实现哪些功能; 继承它的类可以增加自己的方法 
    public interface IfcRenderer : IDisposable   
    {
        /// <summary>
        /// Accessor
        /// </summary>
        IfcViewer Viewer
        {
            get;
            set;
        }

        /// <summary>
        /// Accessor
        /// </summary>
        bool ShowFaces
        {
            get;
            set;
        }

        /// <summary>
        /// Accessor
        /// </summary>
        bool ShowWireframes
        {
            get;
            set;
        }

        /// <summary>
        /// Accessor
        /// </summary>
        bool SelectOnMouseHover
        {
            get;
            set;
        }

        /// <summary>
        /// Resets the scene
        /// </summary>
        void Reset();

        /// <summary>
        /// Repaints the image
        /// </summary>
        void Redraw();

        /// <summary>
        /// An IFC item has been selected
        /// </summary>
        /// <param name="ifcItem"></param>
        void OnSelect(IfcItem ifcItem);

        /// <summary>
        /// Saves the image as a file
        /// </summary>
        void SaveToFile(string strFile, ImageFileFormat imageFileFormat);
    }
}
