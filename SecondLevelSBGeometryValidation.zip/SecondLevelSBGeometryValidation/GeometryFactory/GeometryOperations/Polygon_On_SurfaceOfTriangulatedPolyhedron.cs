﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace SecondLevelSBValidation
{
    public class Polygon_On_SurfaceOfTriangulatedPolyhedron
    {
        public bool Result = false;

        public Polygon_On_SurfaceOfTriangulatedPolyhedron(Polyline3D polygon, List<Triangle3D> TriangulatedPolyhedron, double toleranceScale)
        {
            // find all the triangles of polyhedron that are coplanar with the polygon
            List<Triangle3D> Triangles_Coplanar_Polygon = new List<Triangle3D>();
            for (int j = 0; j < TriangulatedPolyhedron.Count; j++)
            {
                Polyline3D Surface = new Polyline3D();
                Surface.SurfaceNormal = TriangulatedPolyhedron[j].NormalVector;
                Surface.Vertices.Add(TriangulatedPolyhedron[j].Vertex1);
                Surface.Vertices.Add(TriangulatedPolyhedron[j].Vertex2);
                Surface.Vertices.Add(TriangulatedPolyhedron[j].Vertex3);

                if (new IsCoplanarPolygon(polygon, Surface, toleranceScale).Result)
                {
                    Triangles_Coplanar_Polygon.Add(TriangulatedPolyhedron[j]);
                }
            }

            bool checkResult = true;
            // check whether all the vertices of SB is located in one of these triangles
            for (int k = 0; k < polygon.Vertices.Count; k++)
            {
                bool flag = false;
                for (int s = 0; s < Triangles_Coplanar_Polygon.Count; s++)
                {
                    Coplanar_Point_In_Triangle check = new Coplanar_Point_In_Triangle(polygon.Vertices[k], Triangles_Coplanar_Polygon[s], toleranceScale);
                    if (check.Result)
                    {
                        flag = true;
                        break;
                    }
                }

                if (!flag)
                {
                    checkResult = false;
                    break;
                }
            }

           Result = checkResult;
        }
    }
}
