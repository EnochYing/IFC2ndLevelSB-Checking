﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SharpDX.Direct3D9;
using System.Runtime.InteropServices;

// RGBA color: an extension of RGB color model with an alpha channel - which specifies the opacity for a color.
// A = 0: fully transparent; A=1: fully opaque
public class STRUCT_COLOR  // 百分比; 非整数0-255
{
    public float R;  // red 
    public float G;  // green
    public float B;  // blue
    public float A;  // opaque degree
};

public class STRUCT_MATERIAL
{
    public bool active;

    // Common material parameters: 人看材料是本质是通过光线感知
    public STRUCT_COLOR ambient;  // 环境光
    public STRUCT_COLOR diffuse;  // 散射光
    public STRUCT_COLOR specular; // 反射光
    public STRUCT_COLOR emissive; // Object 本身发射光： ‘Emission’ is a property of the Standard Shader which allows static objects in our scene to emit light.

    public double transparency; 
    public double shininess;  // The shininess of a material interacts with its specular property and the lighting in a scene to produce bright highlights on a surface.

    // A struct is a 'value type', which can't be null 
    // If really need to null this, then make it into a 'nullable' type by adding "?"
    // 显著区别：class 可以设置为Null, struct 不能
    public Material? MTRL = null;  // Assign the extracted redering material to the SharpDX.Direct3D9;

    public STRUCT_MATERIAL next;
    public STRUCT_MATERIAL prev;
}

public class STRUCT_MATERIALS   // corresponding to the material definition in IFC schema
{
    public Int64 indexArrayOffset;
    public Int64 indexArrayPrimitives;
    public Int64 indexOffsetForFaces; // this value assigned in SharpDXRenderer

    public STRUCT_MATERIAL material;
    public STRUCT_MATERIALS next;
}

public class STRUCT_MATERIAL_META_INFO
{
    public bool isPoint;
    public bool isEdge;
    public bool isShell;

    public Int64 expressID;  // refer to the P21 Line number
    public STRUCT_MATERIAL material;

    public STRUCT_MATERIAL_META_INFO child;
    public STRUCT_MATERIAL_META_INFO next;  // one object may carry more than one 3D geometry represnetation; each representation should be assigned its own material
}


namespace SecondLevelSBValidation
{
    // Most of these codes for this class come from http://rdf.bg/ifc-engine-dll.php; 
    // The materials refer to the rendering materials defined by the ifcstyleditem instead of the ifcmaterials
    public class IfcMaterialsBuilder
    {
        #region Members

        private readonly Int64 _rdfClassTransformation; 
        private readonly Int64 _rdfClassCollection;
        private readonly Int64 _owlDataTypePropertyExpressID;
        private readonly Int64 _owlObjectTypePropertyMatrix;
        private readonly Int64 _owlObjectTypePropertyObject;
        private readonly Int64 _owlObjectTypePropertyObjects;

        /// <summary>
        /// Model
        /// </summary>
        private Int64 _ifcModel = 0;

        /// <summary>
        /// Counter
        /// </summary>
        private Int64 _iTotalAllocatedMaterials = 0;

        private STRUCT_MATERIAL _firstMaterial = null;
        private STRUCT_MATERIAL _lastMaterial = null;
        private STRUCT_MATERIAL _defaultMaterial = null;
        private STRUCT_MATERIALS _materialsRoot = null;

        /// <summary>
        /// The final list of materials
        /// </summary>
        /// SharpDX.Material
        private List<Material> _lsMaterials = new List<Material>();

        #endregion // Members

        /// <summary>
        /// ctor
        /// </summary>
        /// <param name="ifcModel"></param>
        public IfcMaterialsBuilder(Int64 ifcModel)
        {
            if (ifcModel == 0)
            {
                throw new ArgumentException();
            }

            _ifcModel = ifcModel;

            _defaultMaterial = newMaterial();

            _defaultMaterial.ambient.R = 0;  
            _defaultMaterial.ambient.G = 1f; // total green
            _defaultMaterial.ambient.B = 0;
            _defaultMaterial.ambient.A = 0;  // total transparent
            _defaultMaterial.diffuse.R = 0; 
            _defaultMaterial.diffuse.G = 0.8f;
            _defaultMaterial.diffuse.B = 0;
            _defaultMaterial.diffuse.A = 0;
            _defaultMaterial.specular.R = 0;  
            _defaultMaterial.specular.G = 0.8f;
            _defaultMaterial.specular.B = 0;
            _defaultMaterial.specular.A = 0;
            _defaultMaterial.emissive.R = 0; 
            _defaultMaterial.emissive.G = 0.8f;
            _defaultMaterial.emissive.B = 0;
            _defaultMaterial.emissive.A = 0;

            _defaultMaterial.transparency = 1;  // 透明
            _defaultMaterial.shininess = 1;  // 发亮

            _defaultMaterial.active = true;

            _rdfClassTransformation = IfcEngine.GetClassByName(_ifcModel, "Transformation"); //???
            _rdfClassCollection = IfcEngine.GetClassByName(_ifcModel, "Collection");  //???
            _owlDataTypePropertyExpressID = IfcEngine.GetPropertyByName(_ifcModel, "expressID");  //???
            _owlObjectTypePropertyMatrix = IfcEngine.GetPropertyByName(_ifcModel, "matrix");  //???
            _owlObjectTypePropertyObject = IfcEngine.GetPropertyByName(_ifcModel, "object");  //???
            _owlObjectTypePropertyObjects = IfcEngine.GetPropertyByName(_ifcModel, "objects"); //???
        }

        /// <summary>
        /// Entry point: override for IfcRelSpaceBoundary
        /// </summary>
        /// <param name="ifcInstance"></param>
        public STRUCT_MATERIALS extractMaterials(Int64 ifcInstance)
        {
            if (ifcInstance == 0)
            {
                throw new ArgumentException();
            }
            STRUCT_MATERIAL_META_INFO materialMetaInfo = null; // 初始化之后才能用ref

            IntPtr ifcProductRepresentationInstance; // 不用初始化就可以用 out； IntPtr 句柄---可以使string 或 int
            IfcEngine.sdaiGetAttrBN(ifcInstance, "Representation", IfcEngine.sdaiINSTANCE, out ifcProductRepresentationInstance);

            // ref 关键字使参数按引用传递。当控制权传递回调用方法时，在方法中对参数所做的任何更改都将反映在该变量中。
            // 使用了ref和out的效果和C中使用了指针变量一样。它直接对原数进行操作，而不是对原数的Copy进行操作。
            // C#中通过使用方法来获取返回值时，通常只能得到一个返回值。当一个方法需要返回多个值的时候，就需要用到ref和out ---- 不用单独去构建一个class来存储
            // out 与 ref 关键字类似，不同之处在于: ref 要求变量必须在传递之前进行初始化.
            if (IsInstanceOf(ifcInstance, "IfcSpace")) // for archicad, specific visualization material is assgiend to IfcSpace
            {
                getRGB_space(ifcInstance, ref materialMetaInfo);
            } else if (ifcProductRepresentationInstance != IntPtr.Zero)
            {
                getRGB_productDefinitionShape((Int64)ifcProductRepresentationInstance, ref materialMetaInfo);
            } else if (IsInstanceOf(ifcInstance, "IfcRelSpaceBoundary2ndLevel") || IsInstanceOf(ifcInstance, "IfcRelSpaceBoundary"))  // assign default material to space boundary
            {
                getRGB_spaceBoundary(ifcInstance, ref materialMetaInfo);
            }

            if (materialMetaInfo != null)
            {
                bool bUnique = true;
                bool bDefaultColorIsUsed = false;
                STRUCT_MATERIAL returnedMaterial = null;

                // delete duplicates; add missing ones
                minimizeMaterialItems(materialMetaInfo, ref returnedMaterial, ref bUnique, ref bDefaultColorIsUsed);

                if (!bUnique)
                {
                    returnedMaterial = null;
                }

                if (returnedMaterial != null)
                {
                    return new_STRUCT_MATERIALS(returnedMaterial, ifcInstance);
                }
            } // if (materialMetaInfo != null)

            _materialsRoot = null;
            if (materialMetaInfo != null)
            {
                Int64 setting = 0;
                Int64 mask = 0;
                mask += IfcEngine.flagbit12;   //    WIREFRAME
                setting += 0;                         //    WIREFRAME OFF
                IfcEngine.setFormat(_ifcModel, setting, mask);

                STRUCT_MATERIALS materials = null;
                walkThroughGeometry__transformation(ifcInstance, ref materials, ref materialMetaInfo); // ????
            }

            if (_materialsRoot != null)
            {
                return _materialsRoot;
            }
            else
            {
                return new_STRUCT_MATERIALS(_firstMaterial, ifcInstance);
            }      
        }

        private void getRGB_space(Int64 ifcSpaceInstance, ref STRUCT_MATERIAL_META_INFO materialMetaInfo)
        {
            if (materialMetaInfo == null)
            {
                materialMetaInfo = newMaterialMetaInfo(ifcSpaceInstance); // create a new and initialized materialMetaInfo; initialization of materialMetaInfo
            }
            else
            {
                materialMetaInfo.next = newMaterialMetaInfo(ifcSpaceInstance);
            }
            materialMetaInfo.material.ambient.R = 0;
            materialMetaInfo.material.ambient.G = 1f; // total green
            materialMetaInfo.material.ambient.B = 0;
            materialMetaInfo.material.ambient.A = 1;  // total transparent
            materialMetaInfo.material.diffuse.R = 0;
            materialMetaInfo.material.diffuse.G = 0;
            materialMetaInfo.material.diffuse.B = 0;
            materialMetaInfo.material.diffuse.A = 1;
            materialMetaInfo.material.specular.R = 0;
            materialMetaInfo.material.specular.G = 0;
            materialMetaInfo.material.specular.B = 0;
            materialMetaInfo.material.specular.A = 1;
            materialMetaInfo.material.emissive.R = 0;
            materialMetaInfo.material.emissive.G = 0;
            materialMetaInfo.material.emissive.B = 0;
            materialMetaInfo.material.emissive.A = 1;

            materialMetaInfo.material.transparency = 1;  // 透明
            materialMetaInfo.material.shininess = 1;  // 发亮
        }

        private void getRGB_spaceBoundary(Int64 ifcRelSpaceBoundaryInstance, ref STRUCT_MATERIAL_META_INFO materialMetaInfo)
        {
            if (materialMetaInfo == null)
            {
                materialMetaInfo = newMaterialMetaInfo(ifcRelSpaceBoundaryInstance); // create a new and initialized materialMetaInfo; initialization of materialMetaInfo
            }
            else
            {
                materialMetaInfo.next = newMaterialMetaInfo(ifcRelSpaceBoundaryInstance);
            }

            Int64 RelatedBuildingElementInstance = 0;
            IfcEngine.sdaiGetAttrBN(ifcRelSpaceBoundaryInstance, "RelatedBuildingElement", IfcEngine.sdaiINSTANCE, out RelatedBuildingElementInstance);
            Int64 RelatingSpaceInstance = 0;
            IfcEngine.sdaiGetAttrBN(ifcRelSpaceBoundaryInstance, "RelatingSpace", IfcEngine.sdaiINSTANCE, out RelatingSpaceInstance);
            IntPtr DescriptionPtr = IntPtr.Zero;
            IfcEngine.sdaiGetAttrBN(ifcRelSpaceBoundaryInstance, "Description", IfcEngine.sdaiUNICODE, out DescriptionPtr);
            string Description = Marshal.PtrToStringUni(DescriptionPtr);

            if (IsInstanceOfPhysicalElement(_ifcModel, RelatedBuildingElementInstance)) 
            {
                if (Description != "Shading")  // lighter dark-physical elements
                {
                    materialMetaInfo.material.ambient.R = (float)130 / (float)255; // 环境光(important): 模拟间接光照, 经过多次反射平衡的光，它的强度是均匀的，并且分布是一样的; 只设置这个的话 surface 无论从哪个角度看都是一样的
                    materialMetaInfo.material.ambient.G = (float)130 / (float)255;
                    materialMetaInfo.material.ambient.B = (float)130 / (float)255;
                    materialMetaInfo.material.ambient.A = 0;  // total opta    
                } else if (Description == "Shading")
                {
                    materialMetaInfo.material.ambient.R = (float)50 / (float)255;
                    materialMetaInfo.material.ambient.G = (float)190 / (float)255;
                    materialMetaInfo.material.ambient.B = (float)100 / (float)255;
                    materialMetaInfo.material.ambient.A = 0;  // total transparent
                }
            }
            else if (IsInstanceOf(_ifcModel, RelatedBuildingElementInstance, "IfcDoor") || IsInstanceOf(_ifcModel, RelatedBuildingElementInstance, "IfcDoorStandardCase"))  // purple-door    
            {
                materialMetaInfo.material.ambient.R = (float)253 / (float)255;
                materialMetaInfo.material.ambient.G = (float)127 / (float)255;
                materialMetaInfo.material.ambient.B = (float)255 / (float)255;
                materialMetaInfo.material.ambient.A = 0;  // total transparent
            }
            else if (IsInstanceOf(_ifcModel, RelatedBuildingElementInstance, "IfcWindow") || IsInstanceOf(_ifcModel, RelatedBuildingElementInstance, "IfcWindowStandardCase")) // blue-window
            {
                materialMetaInfo.material.ambient.R = (float)75 / (float)255;
                materialMetaInfo.material.ambient.G = (float)100 / (float)255;
                materialMetaInfo.material.ambient.B = (float)255 / (float)255;
                materialMetaInfo.material.ambient.A = 0;  // total transparent
            }
            else if (IsInstanceOf(_ifcModel, RelatedBuildingElementInstance, "IfcShadingDevice"))
            {
                materialMetaInfo.material.ambient.R = (float)50 / (float)255;
                materialMetaInfo.material.ambient.G = (float)190 / (float)255;
                materialMetaInfo.material.ambient.B = (float)100 / (float)255;
                materialMetaInfo.material.ambient.A = 0;  // total transparent
            }
            else if (IsInstanceOf(_ifcModel, RelatedBuildingElementInstance, "IfcOpeningElement") || IsInstanceOf(_ifcModel, RelatedBuildingElementInstance, "IfcOpeningStandardCase") || IsInstanceOf(_ifcModel, RelatedBuildingElementInstance, "IfcVirtualElement"))  // virtual SBs including space-space and space-opening element   
            {
                materialMetaInfo.material.ambient.R = (float)255 / (float)255;
                materialMetaInfo.material.ambient.G = (float)0 / (float)255;
                materialMetaInfo.material.ambient.B = (float)0 / (float)255;
                materialMetaInfo.material.ambient.A = 0;  // total transparent       
            }
          
            float dValue1 = 0;  // shut off diffuse ---- pure dark;
            materialMetaInfo.material.diffuse.R = dValue1 * materialMetaInfo.material.ambient.R;   // 漫反射光 (important): 模拟对粗糙表面的直接照
            materialMetaInfo.material.diffuse.G = dValue1 * materialMetaInfo.material.ambient.G;
            materialMetaInfo.material.diffuse.B = dValue1 * materialMetaInfo.material.ambient.B;
            materialMetaInfo.material.diffuse.A = 1;

            float dValue2 = 0; // shut off specular & emissive
            materialMetaInfo.material.specular.R = dValue2 * materialMetaInfo.material.ambient.R;   // 高光-镜面反射: 模拟对光滑表面的直接光照
            materialMetaInfo.material.specular.G = dValue2 * materialMetaInfo.material.ambient.G;
            materialMetaInfo.material.specular.B = dValue2 * materialMetaInfo.material.ambient.B;
            materialMetaInfo.material.specular.A = 1;

            materialMetaInfo.material.emissive.R = dValue2 * materialMetaInfo.material.ambient.R / (float)2;  // 自发光:对象自己发出的光,不是一种光源,而是一种不受光照影响的颜色, 自发光只增加自身颜色，而不影响场景内其他对象
            materialMetaInfo.material.emissive.G = dValue2 * materialMetaInfo.material.ambient.R / (float)2;
            materialMetaInfo.material.emissive.B = dValue2 * materialMetaInfo.material.ambient.R / (float)2;
            materialMetaInfo.material.emissive.A = 1;

            materialMetaInfo.material.transparency = 1;  // optacque; as sharpeDX calculate transparence(real) = 1- material.transparency
            materialMetaInfo.material.shininess = 1;  // 发亮: 光泽度，高光光斑的大小范围
        }     

        private bool IsInstanceOf(Int64 IfcModel, Int64 iInstance, string strType)
        {
            if (IfcEngine.sdaiGetInstanceType(iInstance) == IfcEngine.sdaiGetEntity(IfcModel, strType))
            {
                return true;
            }

            return false;
        }

        private bool IsInstanceOfPhysicalElement(Int64 ifcModel, Int64 iInstance)
        {
            List<Int64> PhysicalElementTypes = new List<Int64>();
            List<string> PhysicalElements = new List<string>();
            PhysicalElements.Add("IfcWallStandardCase");
            PhysicalElements.Add("IfcWall");
            PhysicalElements.Add("IfcWallElementedCase");
            PhysicalElements.Add("IfcCurtainWall");
            PhysicalElements.Add("IfcSlabStandardCase");
            PhysicalElements.Add("IfcSlab");
            PhysicalElements.Add("IfcSlabElementedCase");
            PhysicalElements.Add("IfcRoof");
            PhysicalElements.Add("IfcColumnStandardCase");
            PhysicalElements.Add("IfcColumn");
            PhysicalElements.Add("IfcBeamStandardCase");
            PhysicalElements.Add("IfcBeam");

            for (int i = 0; i < PhysicalElements.Count; i++)
            {
                PhysicalElementTypes.Add(IfcEngine.sdaiGetEntity(ifcModel, PhysicalElements[i]));
            }

            Int64 InstanceType = IfcEngine.sdaiGetInstanceType(iInstance);
            for (int i = 0; i < PhysicalElementTypes.Count; i++)
            {
                if (InstanceType == PhysicalElementTypes[i])
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Helper
        /// </summary>
        /// Map extracted materials with parameters to SharpDX.Material
        public void finalizeMaterials()
        {
            STRUCT_MATERIAL material = _firstMaterial;

            while (material != null)
            {
                System.Diagnostics.Debug.Assert(material.active);
                System.Diagnostics.Debug.Assert(material.MTRL == null);

                var mtrl = new Material(); // SharpDX

                mtrl.Ambient.R = material.ambient.R;
                mtrl.Ambient.G = material.ambient.G;
                mtrl.Ambient.B = material.ambient.B;
                mtrl.Ambient.A = (float)material.transparency;
                mtrl.Diffuse.R = material.diffuse.R;
                mtrl.Diffuse.G = material.diffuse.G;
                mtrl.Diffuse.B = material.diffuse.B;
                mtrl.Diffuse.A = (float)material.transparency;
                mtrl.Specular.R = material.specular.R;
                mtrl.Specular.G = material.specular.G;
                mtrl.Specular.B = material.specular.B;
                mtrl.Specular.A = (float)material.transparency;
                mtrl.Emissive.R = material.ambient.R / 2;
                mtrl.Emissive.G = material.ambient.G / 2;
                mtrl.Emissive.B = material.ambient.B / 2;
                mtrl.Emissive.A = (float)material.transparency / 2;
                mtrl.Power = 0.5F;

                material.MTRL = mtrl;  // assign the extracted redering material to the SharpDX.Direct3D9;
                _lsMaterials.Add(mtrl);

                material = material.next;
            } // while  (material != null) 
        }

        /// <summary>
        /// Getter
        /// </summary>
        public List<Material> Materials  // a list of materials that are involved in the IfcModel; the material is unique, no duplicate, no missing
        {
            get
            {
                return _lsMaterials;
            }
        }

        /// <summary>
        /// Helper
        /// </summary>
        /// <param name="owlInstance"></param>
        /// <param name="materials"></param>
        /// <param name="materialMetaInfo"></param>
        /// ?????????????????????????
        private void walkThroughGeometry__transformation(Int64 owlInstance, ref STRUCT_MATERIALS materials, ref STRUCT_MATERIAL_META_INFO materialMetaInfo)
        {
            System.Diagnostics.Debug.Assert(IfcEngine.GetInstanceClass(owlInstance) == _rdfClassTransformation);

            IntPtr owlInstanceObjectsPtr;
            Int64 iObjectCards = 0;
            IfcEngine.GetObjectTypeProperty(owlInstance, _owlObjectTypePropertyObject, out owlInstanceObjectsPtr, ref iObjectCards);

            if (iObjectCards == 1)
            {
                Int64[] owlInstanceObjects = new Int64[iObjectCards];
                Marshal.Copy(owlInstanceObjectsPtr, owlInstanceObjects, 0, (int)iObjectCards);

                walkThroughGeometry__collection(owlInstanceObjects[0], ref materials, ref materialMetaInfo);
            }
            else
            {
                System.Diagnostics.Debug.Assert(false);
            }
        }

        /// <summary>
        /// Helper
        /// </summary>
        /// <param name="owlInstance"></param>
        /// <param name="materials"></param>
        /// <param name="materialMetaInfo"></param>
        /// ????????????????????????
        private void walkThroughGeometry__collection(Int64 owlInstance, ref STRUCT_MATERIALS materials, ref STRUCT_MATERIAL_META_INFO materialMetaInfo)
        {
            if (IfcEngine.GetInstanceClass(owlInstance) == _rdfClassCollection)
            {
                IntPtr owlInstanceObjectsPtr;
                Int64 iObjectCards = 0;
                IfcEngine.GetObjectTypeProperty(owlInstance, _owlObjectTypePropertyObjects, out owlInstanceObjectsPtr, ref iObjectCards);

                if (iObjectCards > 0)
                {
                    Int64[] owlInstanceObjects = new Int64[iObjectCards];
                    Marshal.Copy(owlInstanceObjectsPtr, owlInstanceObjects, 0, (int)iObjectCards);

                    for (Int64 i = 0; i < iObjectCards; i++)
                    {
                        walkThroughGeometry__object(owlInstanceObjects[i], ref materials, materialMetaInfo);

                    }
                }
            }
            else
            {
                walkThroughGeometry__object(owlInstance, ref materials, materialMetaInfo);
            }
        }

        /// <summary>
        /// Helper
        /// </summary>
        /// <param name="owlInstance"></param>
        /// <param name="materials"></param>
        /// <param name="materialMetaInfo"></param>
        /// ???????????????????????
        private void walkThroughGeometry__object(Int64 owlInstance, ref STRUCT_MATERIALS materials, STRUCT_MATERIAL_META_INFO materialMetaInfo)
        {
            STRUCT_MATERIAL_META_INFO materialMetaInfoIterator = materialMetaInfo;

            IntPtr owlInstanceExpressIDPtr;
            Int64 expressIDCard = 0;
            IfcEngine.GetDataTypeProperty(owlInstance, _owlDataTypePropertyExpressID, out owlInstanceExpressIDPtr, ref expressIDCard);
            if (expressIDCard == 1)
            {
                Int64[] owlInstanceExpressID = new Int64[expressIDCard];
                Marshal.Copy(owlInstanceExpressIDPtr, owlInstanceExpressID, 0, (int)expressIDCard);

                Int64 expressID = owlInstanceExpressID[0];

                while ((materialMetaInfoIterator != null) && (materialMetaInfoIterator.expressID != expressID))
                {
                    materialMetaInfoIterator = materialMetaInfoIterator.next;
                }

                if (materialMetaInfoIterator != null)
                {
                    System.Diagnostics.Debug.Assert(materialMetaInfoIterator.expressID == expressID);

                    if (materialMetaInfoIterator.child != null)
                    {
                        if (IfcEngine.GetInstanceClass(owlInstance) == _rdfClassTransformation)
                        {
                            IntPtr owlInstanceObjectPtr;
                            Int64 objectCard = 0;
                            IfcEngine.GetObjectTypeProperty(owlInstance, _owlObjectTypePropertyObject, out owlInstanceObjectPtr, ref objectCard);

                            if (objectCard == 1)
                            {
                                Int64[] owlInstanceObject = new Int64[objectCard];
                                Marshal.Copy(owlInstanceObjectPtr, owlInstanceObject, 0, (int)objectCard);

                                walkThroughGeometry__object(owlInstanceObject[0], ref materials, materialMetaInfoIterator.child);

                            }
                            else
                            {
                                System.Diagnostics.Debug.Assert(false);
                            }
                        }
                        else if (IfcEngine.GetInstanceClass(owlInstance) == _rdfClassCollection)
                        {
                            IntPtr owlInstanceObjectsPtr;
                            Int64 objectsCard = 0;
                            IfcEngine.GetObjectTypeProperty(owlInstance, _owlObjectTypePropertyObjects, out owlInstanceObjectsPtr, ref objectsCard);

                            Int64[] owlInstanceObjects = new Int64[objectsCard];
                            Marshal.Copy(owlInstanceObjectsPtr, owlInstanceObjects, 0, (int)objectsCard);

                            for (Int64 i = 0; i < objectsCard; i++)
                            {
                                walkThroughGeometry__object(owlInstanceObjects[i], ref materials, materialMetaInfoIterator.child);
                            }
                        }
                        else
                        {
                            System.Diagnostics.Debug.Assert(false);
                        }
                    } // if (materialMetaInfoIterator.child != null)
                    else
                    {
                        //
                        //	Now recreate the geometry for this object
                        //
                        Int64 vertexBufferSize = 0;
                        Int64 indexBufferSize = 0;
                        Int64 transformationBufferSize = 0;
                        Int64 offset = 0;
                        IfcEngine.CalculateInstance(owlInstance, ref vertexBufferSize, ref indexBufferSize, ref transformationBufferSize);

                        if (materials != null)
                        {
                            offset = materials.indexArrayOffset + materials.indexArrayPrimitives * 3;

                            materials.next = new_STRUCT_MATERIALS(materialMetaInfoIterator.material);
                            materials.next.indexArrayOffset = offset;
                            materials.next.indexArrayPrimitives = indexBufferSize / 3;
                            materials = materials.next;
                        }
                        else
                        {
                            materials = new_STRUCT_MATERIALS(materialMetaInfoIterator.material);
                            materials.indexArrayOffset = offset;
                            materials.indexArrayPrimitives = indexBufferSize / 3;

                        }

                        if (_materialsRoot == null)
                        {
                            _materialsRoot = materials;
                        }
                    }

                    materialMetaInfoIterator = materialMetaInfoIterator.next;
                } // if (materialMetaInfoIterator != null)
                else
                {
                    System.Diagnostics.Debug.Assert(false);
                }
            }
            else
            {
                if (IfcEngine.GetInstanceClass(owlInstance) == _rdfClassTransformation)
                {
                    IntPtr owlInstanceObjectPtr;
                    Int64 objectCard = 0;
                    IfcEngine.GetObjectTypeProperty(owlInstance, _owlObjectTypePropertyObject, out owlInstanceObjectPtr, ref objectCard);

                    if (objectCard == 1)
                    {
                        Int64[] owlInstanceObject = new Int64[objectCard];
                        Marshal.Copy(owlInstanceObjectPtr, owlInstanceObject, 0, (int)objectCard);
                        walkThroughGeometry__object(owlInstanceObject[0], ref materials, materialMetaInfoIterator);
                    }
                    else
                    {
                        System.Diagnostics.Debug.Assert(false);
                    }
                }
                else if (IfcEngine.GetInstanceClass(owlInstance) == _rdfClassCollection)
                {
                    IntPtr owlInstanceObjectsPtr;
                    Int64 objectsCard = 0;
                    IfcEngine.GetObjectTypeProperty(owlInstance, _owlObjectTypePropertyObjects, out owlInstanceObjectsPtr, ref objectsCard);

                    Int64[] owlInstanceObjects = new Int64[objectsCard];
                    Marshal.Copy(owlInstanceObjectsPtr, owlInstanceObjects, 0, (int)objectsCard);

                    Int64 i = 0;
                    while (i < objectsCard)
                    {
                        walkThroughGeometry__object(owlInstanceObjects[i], ref materials, materialMetaInfoIterator);
                        i++;
                    }
                }
                else
                {
                    System.Diagnostics.Debug.Assert(false);
                }
            }
        }

        /// <summary>
        /// Helper
        /// </summary>
        /// <param name="materialMetaInfo"></param>
        /// <param name="ppMaterial"></param>
        /// <param name="bUnique"></param>
        /// <param name="bDefaultColorIsUsed"></param>
        private void minimizeMaterialItems(STRUCT_MATERIAL_META_INFO materialMetaInfo, ref STRUCT_MATERIAL ppMaterial, ref bool bUnique, ref bool bDefaultColorIsUsed)
        {
            while (materialMetaInfo != null)
            {
                //	Check nested child object (i.e. Mapped Items)
                if (materialMetaInfo.child != null)
                {
                    System.Diagnostics.Debug.Assert(materialMetaInfo.material.ambient.R == -1);
                    System.Diagnostics.Debug.Assert(materialMetaInfo.material.active == false);

                    deleteMaterial(materialMetaInfo.material);

                    materialMetaInfo.material = null;
                    minimizeMaterialItems(materialMetaInfo.child, ref ppMaterial, ref bUnique, ref bDefaultColorIsUsed);
                }

                //
                //	Complete Color
                //
                STRUCT_MATERIAL material = materialMetaInfo.material;
                if (material != null)
                {
                    if (material.ambient.R == -1)
                    {
                        materialMetaInfo.material = _defaultMaterial;
                        deleteMaterial(material);
                    }
                    else
                    {
                        if (material.diffuse.R == -1)
                        {
                            material.diffuse.R = material.ambient.R;
                            material.diffuse.G = material.ambient.G;
                            material.diffuse.B = material.ambient.B;
                            material.diffuse.A = material.ambient.A;
                        }
                        if (material.specular.R == -1)
                        {
                            material.specular.R = material.ambient.R;
                            material.specular.G = material.ambient.G;
                            material.specular.B = material.ambient.B;
                            material.specular.A = material.ambient.A;
                        }
                    }
                }
                else
                {
                    System.Diagnostics.Debug.Assert(materialMetaInfo.child != null);
                }

                //
                //	Merge the same colors
                //
                material = materialMetaInfo.material;
                if ((material != null) && (material != _defaultMaterial))
                {
                    System.Diagnostics.Debug.Assert(material.active == false);
                    System.Diagnostics.Debug.Assert(_firstMaterial == _defaultMaterial);

                    bool bAdjusted = false;
                    STRUCT_MATERIAL materialLoop = _firstMaterial.next;

                    while (materialLoop != null)
                    {
                        if ((materialLoop.active) &&
                              (material.transparency == materialLoop.transparency) &&
                              (material.ambient.R == materialLoop.ambient.R) &&
                              (material.ambient.G == materialLoop.ambient.G) &&
                              (material.ambient.B == materialLoop.ambient.B) &&
                              (material.ambient.A == materialLoop.ambient.A) &&
                              (material.diffuse.R == materialLoop.diffuse.R) &&
                              (material.diffuse.G == materialLoop.diffuse.G) &&
                              (material.diffuse.B == materialLoop.diffuse.B) &&
                              (material.diffuse.A == materialLoop.diffuse.A) &&
                              (material.specular.R == materialLoop.specular.R) &&
                              (material.specular.G == materialLoop.specular.G) &&
                              (material.specular.B == materialLoop.specular.B) &&
                              (material.specular.A == materialLoop.specular.A))
                        {
                            materialMetaInfo.material = materialLoop;

                            deleteMaterial(material);

                            materialLoop = null;
                            bAdjusted = true;
                        }
                        else
                        {
                            if (materialLoop.active == false)
                            {
                                while (materialLoop != null)
                                {
                                    System.Diagnostics.Debug.Assert(materialLoop.active == false);

                                    materialLoop = materialLoop.next;
                                }

                                materialLoop = null;
                            }
                            else
                            {
                                materialLoop = materialLoop.next;
                            }
                        }
                    } // while (materialLoop != null)

                    if (bAdjusted)
                    {
                        System.Diagnostics.Debug.Assert(materialMetaInfo.material.active);
                    }
                    else
                    {
                        System.Diagnostics.Debug.Assert(materialMetaInfo.material.active == false);
                        materialMetaInfo.material.active = true;
                    }

                    System.Diagnostics.Debug.Assert((materialLoop == null) || ((materialLoop == _defaultMaterial) && (materialLoop.next == null)));
                }

                //
                //	Assign default color in case of no color and no children
                //
                if ((materialMetaInfo.material == null) && (materialMetaInfo.child == null))
                {
                    materialMetaInfo.material = _defaultMaterial;
                }

                //
                //	Check if unique
                //
                material = materialMetaInfo.material;
                if (ppMaterial != null)
                {
                    if (ppMaterial != material)
                    {
                        if ((material == null) && (materialMetaInfo.child != null))
                        {
                            // NA
                        }
                        else
                        {
                            bUnique = false;
                        }
                    }
                }
                else
                {
                    System.Diagnostics.Debug.Assert(bUnique);

                    ppMaterial = material;
                }

                if (material == _defaultMaterial)
                {
                    bDefaultColorIsUsed = true;
                }

                materialMetaInfo = materialMetaInfo.next;
            } // while (materialMetaInfo != null)
        }

        /// <summary>
        /// Helper
        /// </summary>
        /// <param name="material"></param>
        private void deleteMaterial(STRUCT_MATERIAL material)
        {
            _iTotalAllocatedMaterials--;

            System.Diagnostics.Debug.Assert(material.active == false);

            STRUCT_MATERIAL prev = material.prev;
            STRUCT_MATERIAL next = material.next;

            if (prev == null)
            {
                System.Diagnostics.Debug.Assert(_firstMaterial == next.prev);
            }

            if (next == null)
            {
                System.Diagnostics.Debug.Assert(_lastMaterial == prev.next);
            }

            if (prev != null)
            {
                System.Diagnostics.Debug.Assert(prev.next == material);
                prev.next = next;
            }
            else
            {
                System.Diagnostics.Debug.Assert(_firstMaterial == material);

                _firstMaterial = next;

                next.prev = null;
            }

            if (next != null)
            {
                System.Diagnostics.Debug.Assert(next.prev == material);

                next.prev = prev;

            }
            else
            {
                System.Diagnostics.Debug.Assert(_lastMaterial == material);

                _lastMaterial = prev;

                System.Diagnostics.Debug.Assert(prev.next == null);
            }

            material.active = false;
        }

        /// <summary>
        /// Helper
        /// </summary>
        /// <param name="ifcObjectInstance"></param>
        /// <param name="materialMetaInfo"></param>
        private void getRGB_productDefinitionShape(Int64 ifcObjectInstance, ref STRUCT_MATERIAL_META_INFO materialMetaInfo)
        {
            IntPtr representationsSet;
            IfcEngine.sdaiGetAttrBN(ifcObjectInstance, "Representations", IfcEngine.sdaiAGGR, out representationsSet);

            Int64 iRepresentationsCount = IfcEngine.sdaiGetMemberCount((Int64)representationsSet);
            for (Int64 iRepresentation = 0; iRepresentation < iRepresentationsCount; iRepresentation++)
            {
                Int64 ifcShapeRepresentation;
                IfcEngine.engiGetAggrElement((Int64)representationsSet, iRepresentation, IfcEngine.sdaiINSTANCE, out ifcShapeRepresentation);

                if (ifcShapeRepresentation != 0)
                {
                    getRGB_shapeRepresentation(ifcShapeRepresentation, ref materialMetaInfo);
                }
            }
        }

        /// <summary>
        /// Helper
        /// </summary>
        /// <param name="ifcShapeRepresentationInstance"></param>
        /// <param name="materialMetaInfo"></param>
        private void getRGB_shapeRepresentation(Int64 ifcShapeRepresentationInstance, ref STRUCT_MATERIAL_META_INFO materialMetaInfo)
        {
            IntPtr representationIdentifier;
            IfcEngine.sdaiGetAttrBN(ifcShapeRepresentationInstance, "RepresentationIdentifier", IfcEngine.sdaiSTRING, out representationIdentifier);

            string strRepresentationIdentifier = Marshal.PtrToStringAnsi(representationIdentifier);

            IntPtr representationType;
            IfcEngine.sdaiGetAttrBN(ifcShapeRepresentationInstance, "RepresentationType", IfcEngine.sdaiSTRING, out representationType);

            string strRepresentationType = Marshal.PtrToStringAnsi(representationType);

            if (((strRepresentationIdentifier == "Body") || (strRepresentationIdentifier == "Mesh") || (strRepresentationIdentifier == "Facetation")) &&
                (strRepresentationType != "BoundingBox"))  // MUST be the preciese 3D representation of the element
            {
                IntPtr geometrySet;
                IfcEngine.sdaiGetAttrBN(ifcShapeRepresentationInstance, "Items", IfcEngine.sdaiAGGR, out geometrySet);

                STRUCT_MATERIAL_META_INFO materialMetaInfoIterator = materialMetaInfo;

                Int64 iGeometryCount = IfcEngine.sdaiGetMemberCount((Int64)geometrySet);
                for (Int64 iGeometry = 0; iGeometry < iGeometryCount; iGeometry++)
                {
                    Int64 iGeometryInstance = 0;
                    IfcEngine.engiGetAggrElement((Int64)geometrySet, iGeometry, IfcEngine.sdaiINSTANCE, out iGeometryInstance);

                    if (materialMetaInfoIterator == null)
                    {
                        materialMetaInfoIterator = materialMetaInfo = newMaterialMetaInfo(iGeometryInstance); // create a new and initialized materialMetaInfo
                    }
                    else
                    {
                        materialMetaInfoIterator = materialMetaInfoIterator.next = newMaterialMetaInfo(iGeometryInstance); // as an object can carry more than one geometry representation
                    }

                    IntPtr styledItemInstance;
                    IfcEngine.sdaiGetAttrBN(iGeometryInstance, "StyledByItem", IfcEngine.sdaiINSTANCE, out styledItemInstance);

                    if (styledItemInstance != IntPtr.Zero)
                    {
                        getRGB_styledItem((Int64)styledItemInstance, materialMetaInfoIterator.material); // used for geometry representation whose IfcStyledItem is directly extratced
                    }
                    else
                    {
                        // used for IfcMappedItem, IfcBooleanClippingResult/IfcBooleanResult,IFCSHELLBASEDSURFACEMODEL 
                        // for these representation, their IfcStyledItem may be missing; so that the styledItem of relevant geometric primitives will be checked 
                        searchDeeper(iGeometryInstance, ref materialMetaInfoIterator, materialMetaInfoIterator.material); 
                    } // else if (iItemInstance != 0)
                } // for (int iGeometry = ...
            }
        }

        /// <summary>
        /// Helper
        /// </summary>
        /// <param name="iGeometryInstance"></param>
        /// <param name="materialMetaInfo"></param>
        /// <param name="material"></param>
        private void searchDeeper(Int64 iGeometryInstance, ref STRUCT_MATERIAL_META_INFO materialMetaInfo, STRUCT_MATERIAL material)
        {
            IntPtr styledItemInstance;
            IfcEngine.sdaiGetAttrBN(iGeometryInstance, "StyledByItem", IfcEngine.sdaiINSTANCE, out styledItemInstance);

            if (styledItemInstance != IntPtr.Zero)
            {
                getRGB_styledItem((Int64)styledItemInstance, materialMetaInfo.material);

                if (material.ambient.R >= 0)
                {
                    return;
                }
            }

            //Int64 booleanClippingResultEntity = IfcEngine.sdaiGetEntity(_ifcModel, "IFCBOOLEANCLIPPINGRESULT");
            //Int64 booleanResultEntity = IfcEngine.sdaiGetEntity(_ifcModel, "IFCBOOLEANRESULT");
            //Int64 mappedItemEntity = IfcEngine.sdaiGetEntity(_ifcModel, "IFCMAPPEDITEM");

            if (IsInstanceOf(iGeometryInstance, "IFCBOOLEANRESULT") || IsInstanceOf(iGeometryInstance, "IFCBOOLEANCLIPPINGRESULT"))
            {
                IntPtr geometryChildInstance;
                IfcEngine.sdaiGetAttrBN(iGeometryInstance, "FirstOperand", IfcEngine.sdaiINSTANCE, out geometryChildInstance); // only need to check the styledItem 

                if (geometryChildInstance != IntPtr.Zero)
                {
                    searchDeeper((Int64)geometryChildInstance, ref materialMetaInfo, material);
                }
            } // if (IsInstanceOf(iGeometryInstance, "IFCBOOLEANRESULT") || ...
            else
            {
                if (IsInstanceOf(iGeometryInstance, "IFCMAPPEDITEM"))
                {
                    IntPtr representationMapInstance;
                    IfcEngine.sdaiGetAttrBN(iGeometryInstance, "MappingSource", IfcEngine.sdaiINSTANCE, out representationMapInstance);

                    IntPtr shapeRepresentationInstance;
                    IfcEngine.sdaiGetAttrBN((Int64)representationMapInstance, "MappedRepresentation", IfcEngine.sdaiINSTANCE, out shapeRepresentationInstance);

                    if (shapeRepresentationInstance != IntPtr.Zero)
                    {
                        System.Diagnostics.Debug.Assert(materialMetaInfo.child == null);

                        getRGB_shapeRepresentation((Int64)shapeRepresentationInstance, ref materialMetaInfo.child);
                    }
                } // if (IsInstanceOf(iParentInstance, "IFCMAPPEDITEM"))
                else
                {
                    if (IsInstanceOf(iGeometryInstance, "IFCSHELLBASEDSURFACEMODEL"))
                    {
                        IntPtr geometryChildAggr;
                        IfcEngine.sdaiGetAttrBN(iGeometryInstance, "SbsmBoundary", IfcEngine.sdaiAGGR, out geometryChildAggr);

                        STRUCT_MATERIAL_META_INFO materialMetaInfoIterator = materialMetaInfo;

                        Int64 iGeometryChildAggrCount = IfcEngine.sdaiGetMemberCount((Int64)geometryChildAggr);
                        for (int iGeometryChildAggr = 0; iGeometryChildAggr < iGeometryChildAggrCount; iGeometryChildAggr++)
                        {
                            Int64 iGeometryChildInstance = 0;
                            IfcEngine.engiGetAggrElement((Int64)geometryChildAggr, iGeometryChildAggr, IfcEngine.sdaiINSTANCE, out iGeometryChildInstance);

                            if (iGeometryChildInstance != 0)
                            {
                                if (materialMetaInfoIterator == null)
                                {
                                    materialMetaInfoIterator = materialMetaInfo.child = newMaterialMetaInfo(iGeometryChildInstance);
                                }
                                else
                                {
                                    materialMetaInfoIterator = materialMetaInfoIterator.next = newMaterialMetaInfo(iGeometryChildInstance);
                                }

                                searchDeeper(iGeometryChildInstance, ref materialMetaInfo, materialMetaInfo.material);
                            }
                        } // for (int iGeometryChildAggr = ...
                    } // if (IsInstanceOf(iGeometryInstance, "IFCSHELLBASEDSURFACEMODEL"))
                } // else if (IsInstanceOf(iGeometryInstance, "IFCMAPPEDITEM"))
            } // else if (IsInstanceOf(iGeometryInstance, "IFCBOOLEANRESULT") || ...
        }

        /// <summary>
        /// Helper
        /// </summary>
        /// <param name="iStyledItemInstance"></param>
        /// <param name="material"></param>
        private void getRGB_styledItem(Int64 iStyledItemInstance, STRUCT_MATERIAL material)
        {
            IntPtr stylesSet;
            IfcEngine.sdaiGetAttrBN(iStyledItemInstance, "Styles", IfcEngine.sdaiAGGR, out stylesSet);

            Int64 iStylesCount = IfcEngine.sdaiGetMemberCount((Int64)stylesSet);
            for (Int64 iStyle = 0; iStyle < iStylesCount; iStyle++)
            {
                Int64 iPresentationStyleAssignmentInstance = 0;
                IfcEngine.engiGetAggrElement((Int64)stylesSet, iStyle, IfcEngine.sdaiINSTANCE, out iPresentationStyleAssignmentInstance);

                if (iPresentationStyleAssignmentInstance != 0)
                {
                    getRGB_presentationStyleAssignment(iPresentationStyleAssignmentInstance, ref material);
                }
            } // for (int iStyle = ...
        }

        /// <summary>
        /// Helper
        /// </summary>
        /// <param name="iPresentationStyleAssignmentInstance"></param>
        /// <param name="material"></param>
        private void getRGB_presentationStyleAssignment(Int64 iPresentationStyleAssignmentInstance, ref STRUCT_MATERIAL material)
        {
            IntPtr stylesSet;
            IfcEngine.sdaiGetAttrBN(iPresentationStyleAssignmentInstance, "Styles", IfcEngine.sdaiAGGR, out stylesSet);

            Int64 iStylesCount = IfcEngine.sdaiGetMemberCount((Int64)stylesSet);
            for (int iStyle = 0; iStyle < iStylesCount; iStyle++)
            {
                Int64 iSurfaceStyleInstance = 0;
                IfcEngine.engiGetAggrElement((Int64)stylesSet, iStyle, IfcEngine.sdaiINSTANCE, out iSurfaceStyleInstance);

                if (iSurfaceStyleInstance != 0)
                {
                    getRGB_surfaceStyle(iSurfaceStyleInstance, ref material);
                }
            } // for (int iStyle = ...
        }

        /// <summary>
        /// Helper
        /// </summary>
        /// <param name="iSurfaceStyleInstance"></param>
        /// <param name="material"></param>
        private void getRGB_surfaceStyle(Int64 iSurfaceStyleInstance, ref STRUCT_MATERIAL material)
        {
            IntPtr stylesSet;
            IfcEngine.sdaiGetAttrBN(iSurfaceStyleInstance, "Styles", IfcEngine.sdaiAGGR, out stylesSet);

            Int64 iStylesCount = IfcEngine.sdaiGetMemberCount((Int64)stylesSet);
            for (Int64 iStyle = 0; iStyle < iStylesCount; iStyle++)
            {
                Int64 iSurfaceStyleRenderingInstance = 0;
                IfcEngine.engiGetAggrElement((Int64)stylesSet, iStyle, IfcEngine.sdaiINSTANCE, out iSurfaceStyleRenderingInstance);

                double dTransparency = 0;
                IfcEngine.sdaiGetAttrBN(iSurfaceStyleRenderingInstance, "Transparency", IfcEngine.sdaiREAL, out dTransparency);
                material.transparency = 1.0 - dTransparency; // ???

                IntPtr surfaceColourInstance;
                IfcEngine.sdaiGetAttrBN(iSurfaceStyleRenderingInstance, "SurfaceColour", IfcEngine.sdaiINSTANCE, out surfaceColourInstance);

                if (surfaceColourInstance != IntPtr.Zero)
                {
                    getRGB_colourRGB((Int64)surfaceColourInstance, material.ambient); // 环境光---底色
                }
                else
                {
                    System.Diagnostics.Debug.Assert(false);
                }

                IntPtr diffuseColourInstance;
                IfcEngine.sdaiGetAttrBN(iSurfaceStyleRenderingInstance, "DiffuseColour", IfcEngine.sdaiINSTANCE, out diffuseColourInstance);

                if (diffuseColourInstance != IntPtr.Zero)
                {
                    getRGB_colourRGB((Int64)diffuseColourInstance, material.diffuse);
                }
                else
                {
                    // pretty good! the type of iSurfaceStyleRenderingInstance is not sure; 
                    // which may be IfcColourRgb or IfcNormalisedRatioMeasure
                    // ADB used for entity instance that actually is only a value
                    Int64 iADB = 0;
                    IfcEngine.sdaiGetAttrBN(iSurfaceStyleRenderingInstance, "DiffuseColour", IfcEngine.sdaiADB, out iADB);

                    if (iADB != 0)
                    {
                        double dValue;
                        IfcEngine.sdaiGetADBValue(iADB, IfcEngine.sdaiREAL, out dValue);

                        material.diffuse.R = (float)dValue * material.ambient.R;
                        material.diffuse.G = (float)dValue * material.ambient.G;
                        material.diffuse.B = (float)dValue * material.ambient.B;
                    }
                }

                IntPtr specularColourInstance;
                IfcEngine.sdaiGetAttrBN(iSurfaceStyleRenderingInstance, "SpecularColour", IfcEngine.sdaiINSTANCE, out specularColourInstance);

                if (specularColourInstance != IntPtr.Zero)
                {
                    getRGB_colourRGB((Int64)specularColourInstance, material.specular);
                }
                else
                {
                    Int64 iADB = 0;
                    IfcEngine.sdaiGetAttrBN(iSurfaceStyleRenderingInstance, "SpecularColour", IfcEngine.sdaiADB, out iADB);

                    if (iADB != 0)
                    {
                        double dValue;
                        IfcEngine.sdaiGetADBValue(iADB, IfcEngine.sdaiREAL, out dValue);

                        material.specular.R = (float)dValue * material.ambient.R;
                        material.specular.G = (float)dValue * material.ambient.G;
                        material.specular.B = (float)dValue * material.ambient.B;
                    }
                }
            } // for (int iStyle = ...
        }

        /// <summary>
        /// Helper
        /// </summary>
        /// <param name="iSurfaceColourInstance"></param>
        /// <param name="color"></param>
        private void getRGB_colourRGB(Int64 iSurfaceColourInstance, STRUCT_COLOR color)
        {
            double dRed = 0, dGreen = 0, dBlue = 0;
            IfcEngine.sdaiGetAttrBN(iSurfaceColourInstance, "Red", IfcEngine.sdaiREAL, out dRed);
            IfcEngine.sdaiGetAttrBN(iSurfaceColourInstance, "Green", IfcEngine.sdaiREAL, out dGreen);
            IfcEngine.sdaiGetAttrBN(iSurfaceColourInstance, "Blue", IfcEngine.sdaiREAL, out dBlue);

            color.R = (float)dRed;
            color.G = (float)dGreen;
            color.B = (float)dBlue;
        }

        /// <summary>
        /// Helper
        /// </summary>
        /// <param name="iInstance"></param>
        /// <param name="strType"></param>
        /// <returns></returns>
        private bool IsInstanceOf(Int64 iInstance, string strType)
        {
            if (IfcEngine.sdaiGetInstanceType(iInstance) == IfcEngine.sdaiGetEntity(_ifcModel, strType))
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// Factory
        /// </summary>
        /// <returns></returns>
        private STRUCT_MATERIAL newMaterial()
        {
            _iTotalAllocatedMaterials++;

            STRUCT_MATERIAL material = new STRUCT_MATERIAL();

            material.ambient = new STRUCT_COLOR();
            material.ambient.R = -1;
            material.ambient.G = -1;
            material.ambient.B = -1;
            material.ambient.A = -1;

            material.diffuse = new STRUCT_COLOR();
            material.diffuse.R = -1;
            material.diffuse.G = -1;
            material.diffuse.B = -1;
            material.diffuse.A = -1;

            material.specular = new STRUCT_COLOR();
            material.specular.R = -1;
            material.specular.G = -1;
            material.specular.B = -1;
            material.specular.A = -1;

            material.emissive = new STRUCT_COLOR();
            material.emissive.R = -1;
            material.emissive.G = -1;
            material.emissive.B = -1;
            material.emissive.A = -1;

            material.transparency = -1;
            material.shininess = -1;

            material.next = null;
            material.prev = _lastMaterial;

            if (_firstMaterial == null)
            {
                System.Diagnostics.Debug.Assert(_lastMaterial == null);

                _firstMaterial = material;
            }

            _lastMaterial = material;

            if (_lastMaterial.prev != null)
            {
                _lastMaterial.prev.next = _lastMaterial;
            }

            material.active = false;

            return material;
        }

        /// <summary>
        /// Factory
        /// </summary>
        /// <param name="ifcInstance"></param>
        /// <returns></returns>
        private STRUCT_MATERIAL_META_INFO newMaterialMetaInfo(Int64 ifcInstance)
        {
            STRUCT_MATERIAL_META_INFO materialMetaInfo = new STRUCT_MATERIAL_META_INFO();

            if (ifcInstance != 0)
            {
                materialMetaInfo.expressID = IfcEngine.internalGetP21Line(ifcInstance);
            }
            else
            {
                materialMetaInfo.expressID = -1;
            }

            materialMetaInfo.isPoint = false;
            materialMetaInfo.isEdge = false;
            materialMetaInfo.isShell = false;

            materialMetaInfo.material = newMaterial();

            materialMetaInfo.child = null;
            materialMetaInfo.next = null;

            return materialMetaInfo;
        }

        /// <summary>
        /// Factory
        /// </summary>
        /// <param name="material"></param>
        /// <returns></returns>
        private STRUCT_MATERIALS new_STRUCT_MATERIALS(STRUCT_MATERIAL material)
        {
            STRUCT_MATERIALS materials = new STRUCT_MATERIALS();

            materials.indexArrayOffset = 0;
            materials.indexArrayPrimitives = 0;
            materials.material = material;
            materials.next = null;

            return materials;
        }

        /// <summary>
        /// Helper
        /// </summary>
        /// <param name="material"></param>
        /// <param name="ifcInstance"></param>
        /// <returns></returns>
        private STRUCT_MATERIALS new_STRUCT_MATERIALS(STRUCT_MATERIAL material, Int64 ifcInstance)
        {
            STRUCT_MATERIALS materials = new_STRUCT_MATERIALS(material); // create a default  STRUCT_MATERIALS type instance

            Int64 setting = 0;
            Int64 mask = 0;
            mask += IfcEngine.flagbit12;   //    WIREFRAME
            setting += 0;                         //    WIREFRAME OFF
            IfcEngine.setFormat(_ifcModel, setting, mask);

            Int64 iVertexBufferSize = 0; // 存放顶点的size
            Int64 iIndexBufferSize = 0;  // 存放index的size
            Int64 iTransformationBufferSize = 0; // 存放空间转换的size
            IfcEngine.CalculateInstance(ifcInstance, ref iVertexBufferSize, ref iIndexBufferSize, ref iTransformationBufferSize); // ???

            materials.indexArrayOffset = 0;
            materials.indexArrayPrimitives = iIndexBufferSize / 3; // number of triangles    

            return materials;
        }

       
    }
}
