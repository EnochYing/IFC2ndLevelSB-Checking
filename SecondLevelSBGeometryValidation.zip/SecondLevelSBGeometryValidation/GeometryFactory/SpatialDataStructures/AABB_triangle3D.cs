﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace SecondLevelSBValidation
{
    // AABB tree taking 3D triangles as input
    public class AABB_triangle3D_TreeNode
    {
        public BoundingBox3D AABBBox;    
        public List<Triangle3D> Triangles;  // only correctly populated in leaf nodes and the root node; other than leaf nodes, all other nodes carry the all the input triangles -- for efficiency consideration

        public AABB_triangle3D_TreeNode LeftChildren;
        public AABB_triangle3D_TreeNode RightChildren;

        public int Depth;   // for terminal condition
        //public int NTriangles; // for terminal condition


        // constructor to create a single node
        public AABB_triangle3D_TreeNode(BoundingBox3D Box)
        {
            AABBBox = Box;
            Depth = +1;
            //NTriangles = Triangles.Count;
        }

        // constructor to spilt the node
        public Boolean Split()
        {
            if (LeftChildren != null || RightChildren != null) // this node is already spilt
            {
                return false;
            }

            // select the spilt axis
            Boolean SplitAxisx = false;
            Boolean SplitAxisy = false;
            Boolean SplitAxisz = false;
            double Axisx = AABBBox.xmax - AABBBox.xmin;
            double Axisy = AABBBox.ymax - AABBBox.ymin;
            double Axisz = AABBBox.ymin - AABBBox.zmin;

            if (Axisx > Axisy)
            {
                if (Axisx > Axisz)
                {
                    SplitAxisx = true;
                } else
                {
                    SplitAxisz = true;
                }
            } else
            {
                if (Axisz > Axisy)
                {
                    SplitAxisz = true;
                } else
                {
                    SplitAxisy = true;
                }
            }

            // create the left and right children 
            // left--> smaller; right --> bigger
            if (SplitAxisx)
            {
                BoundingBox3D LeftBox = new BoundingBox3D();
                LeftBox.xmax = (AABBBox.xmax + AABBBox.xmin)/2;
                LeftBox.xmin = AABBBox.xmin;
                LeftBox.ymax = AABBBox.ymax;
                LeftBox.ymin = AABBBox.ymin;
                LeftBox.zmax = AABBBox.zmax;
                LeftBox.zmin = AABBBox.zmin;
                LeftChildren = new AABB_triangle3D_TreeNode(LeftBox);

                BoundingBox3D RightBox = new BoundingBox3D();
                RightBox.xmax = AABBBox.xmax;
                RightBox.xmin = (AABBBox.xmax + AABBBox.xmin) / 2;
                RightBox.ymax = AABBBox.ymax;
                RightBox.ymin = AABBBox.ymin;
                RightBox.zmax = AABBBox.zmax;
                RightBox.zmin = AABBBox.zmin;
                RightChildren = new AABB_triangle3D_TreeNode(RightBox);
            };

            if (SplitAxisy)
            {
                BoundingBox3D LeftBox = new BoundingBox3D();
                LeftBox.xmax = AABBBox.xmax;
                LeftBox.xmin = AABBBox.xmin;
                LeftBox.ymax = (AABBBox.ymax + AABBBox.ymin) / 2;
                LeftBox.ymin = AABBBox.ymin;
                LeftBox.zmax = AABBBox.zmax;
                LeftBox.zmin = AABBBox.zmin;
                LeftChildren = new AABB_triangle3D_TreeNode(LeftBox);

                BoundingBox3D RightBox = new BoundingBox3D();
                RightBox.xmax = AABBBox.xmax;
                RightBox.xmin = AABBBox.xmin;
                RightBox.ymax = AABBBox.ymax;
                RightBox.ymin = (AABBBox.ymax + AABBBox.ymin) / 2;
                RightBox.zmax = AABBBox.zmax;
                RightBox.zmin = AABBBox.zmin;
                RightChildren = new AABB_triangle3D_TreeNode(RightBox);
            };

            if (SplitAxisz)
            {
                BoundingBox3D LeftBox = new BoundingBox3D();
                LeftBox.xmax = AABBBox.xmax;
                LeftBox.xmin = AABBBox.xmin;
                LeftBox.ymax = AABBBox.ymax;
                LeftBox.ymin = AABBBox.ymin;
                LeftBox.zmax = (AABBBox.zmax + AABBBox.zmin) / 2;
                LeftBox.zmin = AABBBox.zmin;
                LeftChildren = new AABB_triangle3D_TreeNode(LeftBox);

                BoundingBox3D RightBox = new BoundingBox3D();
                RightBox.xmax = AABBBox.xmax;
                RightBox.xmin = AABBBox.xmin;
                RightBox.ymax = AABBBox.ymax;
                RightBox.ymin = AABBBox.ymin;
                RightBox.zmax = AABBBox.zmax;
                RightBox.zmin = (AABBBox.zmax + AABBBox.zmin) / 2;
                RightChildren = new AABB_triangle3D_TreeNode(RightBox);
            }        
            return true;  // spilt successfully 
        }

        // assign original triangles to relevant leaf nodes
        public void AssignTriangles()
        {
            if (LeftChildren != null || RightChildren != null)
            {
                if (LeftChildren != null)
                {
                    LeftChildren.AssignTriangles();
                }
                if (RightChildren != null)
                {
                    RightChildren.AssignTriangles();
                }
            }
            else  // until the leaf notes
            {
                List<Triangle3D> temp = Triangles; // copy the original triangles to a temporary list;
                Triangles = new List<Triangle3D>(); // clean out the original triangles
                bool Relationship = false;
                BoundingBox_Triangle_do_intersect Box_Triangle = new BoundingBox_Triangle_do_intersect();
                for (int i = 0; i < temp.Count; i++)
                {
                    Relationship = Box_Triangle.Test(AABBBox, temp[i]);
                    if (Relationship)
                    {
                        Triangles.Add(temp[i]);
                    }
                }

            }
        }

    }

    // building a tree: make it more robust---- input 
    public class AABB_triangle3D_Tree
    {
        public List<AABB_triangle3D_TreeNode> TreeNodes;
        // building the bounding box for each tree node
        // note that there is no triangle in the leaf nodes
        public AABB_triangle3D_Tree(List<Triangle3D> triangles)
        {
            // using the depth as the terminal condition: the tree depth should be not more than 4; 
            // or we can use the number of triangles in the leaf node as the terminal condition --- think which is more reasonable???
            const int MaxDepth = 4;
            //const int MaxNTriangles = 2; 
                        
            // create a root node
            BoundingBox3D RootBox = new BoundingBox3D (triangles);
            AABB_triangle3D_TreeNode RootNode = new AABB_triangle3D_TreeNode(RootBox);
            RootNode.Triangles = triangles;  // the original triangles MUST be assigned to the root node!!!
            TreeNodes.Add(RootNode);

            // add the children node          
            Boolean DoSpilt = true;
            while (DoSpilt)
            {
                DoSpilt = false;
                foreach (AABB_triangle3D_TreeNode TreeNode in TreeNodes)
                {
                    if (TreeNode.LeftChildren == null && TreeNode.LeftChildren == null)
                    {
                        if (TreeNode.Depth <= MaxDepth)  // use the tree depth as the terminal condition
                        {
                            if (TreeNode.Split())  // spilt this tree node
                            {
                                TreeNode.LeftChildren.Triangles = triangles;  // copy the original triangles to each node; 
                                TreeNode.RightChildren.Triangles = triangles; // the purpose is that they can be passed to the leaf notes
                                TreeNodes.Add(TreeNode.LeftChildren);
                                TreeNodes.Add(TreeNode.RightChildren);
                                DoSpilt = true;
                            }
                        }
                    }
                }
            }
        }
      
    }

}
