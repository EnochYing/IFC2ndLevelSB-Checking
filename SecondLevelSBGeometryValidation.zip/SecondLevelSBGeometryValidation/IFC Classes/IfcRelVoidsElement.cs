﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;

namespace SecondLevelSBValidation
{
    public class IfcRelVoidsElement
    {
        public Int64 Pointer;
        public string GlobalID;
        public Int64 RelatingBuildingElement;
        public Int64 RelatedOpeningElement;
        public Int64 InstanceInOriginalModel = 0;

        public List<IfcRelVoidsElement> ExtractIfcRelVoidsElement(Int64 IfcModel)
        {
            List<IfcRelVoidsElement> IfcRelVoidsElements = new List<IfcRelVoidsElement>();

            Int64 IfcRelVoidsElementInstances = IfcEngine.sdaiGetEntityExtentBN(IfcModel, "IfcRelVoidsElement");
            Int64 NumIfcRelVoidsElementInstances = IfcEngine.sdaiGetMemberCount(IfcRelVoidsElementInstances);
            if (NumIfcRelVoidsElementInstances != 0)
            {
                for (Int64 i = 0; i < NumIfcRelVoidsElementInstances; i++)
                {
                    IfcRelVoidsElement _IfcRelVoidsElement = new IfcRelVoidsElement();
                    Int64 IfcRelVoidsElementInstance = 0;
                    IfcEngine.engiGetAggrElement(IfcRelVoidsElementInstances, i, IfcEngine.sdaiINSTANCE, out IfcRelVoidsElementInstance);
                    _IfcRelVoidsElement.Pointer = IfcRelVoidsElementInstance;

                    // extract the GlobalID
                    IntPtr GlobalIdPtr = IntPtr.Zero;
                    IfcEngine.sdaiGetAttrBN(IfcRelVoidsElementInstance, "GlobalId", IfcEngine.sdaiUNICODE, out GlobalIdPtr);
                    _IfcRelVoidsElement.GlobalID = Marshal.PtrToStringUni(GlobalIdPtr);

                    // RelatingBuildingElement
                    Int64 IfcBuildingElementInstance = 0;
                    IfcEngine.sdaiGetAttrBN(IfcRelVoidsElementInstance, "RelatingBuildingElement", IfcEngine.sdaiINSTANCE, out IfcBuildingElementInstance);
                    _IfcRelVoidsElement.RelatingBuildingElement = IfcBuildingElementInstance;

                    // RelatedOpeningElement	
                    Int64 IfcOpeningElementInstance = 0;
                    IfcEngine.sdaiGetAttrBN(IfcRelVoidsElementInstance, "RelatedOpeningElement", IfcEngine.sdaiINSTANCE, out IfcOpeningElementInstance);
                    _IfcRelVoidsElement.RelatedOpeningElement = IfcOpeningElementInstance;

                    IfcRelVoidsElements.Add(_IfcRelVoidsElement);
                }
            }
            return IfcRelVoidsElements;
        }
    }
}
