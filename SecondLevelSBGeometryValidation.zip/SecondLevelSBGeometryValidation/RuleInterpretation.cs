﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using ClipperLib_WithoutStatic;
using EarClipperLib;
using NetTopologySuite.Algorithm;
using GeoAPI.Geometries;

namespace SecondLevelSBValidation
{
    using Path = List<IntPoint>;
    using Paths = List<List<IntPoint>>;

    #region SR: Syntactic and Semantic Validation Rules

    // SR.0: IfcCartesianPoint.Cooridnates checking    
    // SR.0.1: The Coordinates attribute of an IfcRelSpaceBoundary2ndLevel./…/.IfcAxis2Placement3D.Location.IfcCartesianPoint instance shall have three values 
    public class SR_0_1_RuleChecking
    {
        public string errorReporting = "SR.0.1: The Coordinates of the following IfcCartesianPoint instances do not have three values: ";
        public List<string> IfcCartesianPoint_SB = new List<string>();
        public bool hasErrors = false;
        public List<string> failingSBs_instanceNames = new List<string>();

        public SR_0_1_RuleChecking(List<IfcRelSpaceBoundary> SBs)
        {
            foreach (var sb in SBs)
            {
                if (sb.Axis2Placement3D.LCSLocation_Dim != 3)
                {
                    hasErrors = true;
                    this.IfcCartesianPoint_SB.Add("#" + sb.Axis2Placement3D.LCSLocation_Instance + " IfcCartesianPoint" +  "(" + sb.InstanceName + " IfcRelSpaceBoundary2ndLevel" + ")" );
                    failingSBs_instanceNames.Add(sb.InstanceName);
                }
            }
        }
    }

    // SR.0.2: The Coordinates attribute of an IfcRelSpaceBoundary2ndLevel./…/.IfcPolyline.Points.IfcCartesianPoint instance shall have two values 
    public class SR_0_2_RuleChecking
    {
        public string errorReporting = "SR.0.2: The Coordinates of the following IfcCartesianPoint instances do not have two values: ";
        public List<string> IfcCartesianPoint_SB = new List<string>();
        public bool hasErrors = false;
        public List<string> failingSBs_instanceNames = new List<string>();

        public SR_0_2_RuleChecking(List<IfcRelSpaceBoundary> SBs)
        {
            foreach (var sb in SBs)
            {
                if (sb.polyline.IFCCartesianPointInstances_Not2D.Count != 0)
                {
                    foreach (var cartesianPoint in sb.polyline.IFCCartesianPointInstances_Not2D)
                    {
                        hasErrors = true;
                        this.IfcCartesianPoint_SB.Add("#" + cartesianPoint + " IfcCartesianPoint" + "(" + sb.InstanceName + " IfcRelSpaceBoundary2ndLevel" + ")");
                        failingSBs_instanceNames.Add(sb.InstanceName);
                    }
                }
            }
        }
    }


    // SR.1: Syntactic and semantic checking of IfcRelSpaceBoundary2ndLevel attribute
    // SR.1.1: IF RelatedBuildingElement ∈ {IfcDoor, IfcWindow, IfcOpeningElement, IfcShadingDevice}, 
    //         THEN the value of ParentBoundary must be an IfcRelSpaceBoundary2ndLevel instance
    public class SR_1_1_RuleChecking
    {
        public string errorReporting = "SR.1.1: The ParentBoundary of the following SBs should reference an IfcRelSpaceBoundary2ndLevel instance: ";
        public List<string> failingSBs = new List<string>();
        public List<string> failingSBs_instanceNames = new List<string>();
        public bool hasErrors = false;

        public SR_1_1_RuleChecking(List<IfcRelSpaceBoundary> SBs)
        {
            foreach (var sb in SBs)
            {
                switch (sb.RelatedBuildingElementType)
                {
                    case BuildingElementType.IfcDoorStandardCase:
                        if (sb.ParenBoundaryInstance == 0)
                        {
                            hasErrors = true;
                            this.failingSBs.Add(sb.InstanceName + " IfcRelSpaceBoundary2ndLevel");
                            failingSBs_instanceNames.Add(sb.InstanceName);
                        }                   
                        break;
                    //case BuildingElementType.IfcShadingDevice:
                    //    if (sb.ParenBoundaryInstance == 0)
                    //    {
                    //        hasErrors = true;
                    //        this.failingSBs.Add(sb.InstanceName + " IfcRelSpaceBoundary2ndLevel");
                    //    }
                    //    break;
                    case BuildingElementType.IfcOpeningStandardCase:
                        if (sb.ParenBoundaryInstance == 0)
                        {
                            hasErrors = true;
                            this.failingSBs.Add(sb.InstanceName + " IfcRelSpaceBoundary2ndLevel");
                            failingSBs_instanceNames.Add(sb.InstanceName);
                        }
                        break;
                    case BuildingElementType.IfcWindowStandardCase:
                        if (sb.ParenBoundaryInstance == 0)
                        {
                            hasErrors = true;
                            this.failingSBs.Add(sb.InstanceName + " IfcRelSpaceBoundary2ndLevel");
                            failingSBs_instanceNames.Add(sb.InstanceName);
                        }
                        break;
                }
            }
        }
    }

    // SR.1.2: For IfcRelSpaceBoundary2ndLevel./.../.IfcAxis2Placement3D, either both Axis and RefDirection are not given and therefore defaulted, 
    //         or both shall be given and not be parallel or anti-parallel
    public class SR_1_2_RuleChecking
    {
        public string errorReporting_1 = "SR.1.2: The RefDirection of the following IfcAxis2Placement3D instances should be given as a 3D vector";
        public List<string> failingSBs_eR1 = new List<string>();

        public string errorReporting_2 = "SR.1.2: The Axis of the following IfcAxis2Placement3D instances should be given as a 3D vector";
        public List<string> failingSBs_eR2 = new List<string>();    

        public string errorReporting_3 = "SR.1.2: The Axis and RefDirection of the following IfcAxis2Placement3D instances should not be parallel";
        public List<string> failingSBs_eR3 = new List<string>();

        public bool hasErrors = false;
        public List<string> failingSBs_instanceNames = new List<string>();

        public SR_1_2_RuleChecking(List<IfcRelSpaceBoundary> SBs)
        {
            foreach (var sb in SBs)
            {
                if (sb.Axis2Placement3D.LCSxAxis_Instance == 0)  // RefDirection
                {
                    if (sb.Axis2Placement3D.LCSzAxis_Instance != 0)  // Axis
                    {
                        hasErrors = true;
                        failingSBs_eR1.Add(sb.InstanceName + " IfcRelSpaceBoundary2ndLevel");
                        failingSBs_instanceNames.Add(sb.InstanceName);
                    } 
                } else
                {
                    if (sb.Axis2Placement3D.LCSzAxis_Instance == 0)
                    {
                        hasErrors = true;
                        failingSBs_eR2.Add(sb.InstanceName + " IfcRelSpaceBoundary2ndLevel");
                        failingSBs_instanceNames.Add(sb.InstanceName);
                    } else
                    {
                        if (sb.Axis2Placement3D.LCSxAxis_Dim == 2)
                        {
                            hasErrors = true;
                            failingSBs_eR1.Add(sb.InstanceName + " IfcRelSpaceBoundary2ndLevel");
                            failingSBs_instanceNames.Add(sb.InstanceName);
                        }

                        if (sb.Axis2Placement3D.LCSzAxis_Dim == 2)
                        {
                            hasErrors = true;
                            failingSBs_eR2.Add(sb.InstanceName + " IfcRelSpaceBoundary2ndLevel");
                            failingSBs_instanceNames.Add(sb.InstanceName);
                        }

                        if (sb.Axis2Placement3D.LCSxAxis_Dim == 3 && sb.Axis2Placement3D.LCSzAxis_Dim == 3)
                        {
                            Vector3D v = new Vector3D();
                            Vector3D LCSxAxis_unit = v.UnitVector(sb.Axis2Placement3D.LCSxAxis);
                            Vector3D LCSzAxis_unit = v.UnitVector(sb.Axis2Placement3D.LCSzAxis);
                            double ang = Math.Abs(v.DotProduct(LCSxAxis_unit, LCSzAxis_unit) - 1);
                            if (ang < 0.0001)
                            {
                                hasErrors = true;
                                failingSBs_eR3.Add(sb.InstanceName + " IfcRelSpaceBoundary2ndLevel");
                                failingSBs_instanceNames.Add(sb.InstanceName);
                            }
                        }                     
                    }
                }
            }
        }
    }

    // SR.2: Checking of SBs’ existence 
    // SR.2.1: The following architecture elements if available shall probably have SBs: 
    //         Walls (IfcWall) / curtain walls (IfcCurtainWall), slabs (IfcSlab), roofs (IfcRoof), columns (IfcColumn), windows (IfcWindow), doors (IfcDoor), openings (IfcOpeningElement), virtual elements (i.e., space separators; IfcVirtualElement).
    // !!!: The element belonging to an aggragat element or an opening element (IfcOpeningElement) filling windows/doors should be excluded
    // !!!: Have overlap with SR.3 and SR.4
    public class SR_2_1_RuleChecking
    {
        public string errorReporting = "SR.2.1: The following building element instances should probably provide SBs: ";
        public List<string> failingBuildingElements = new List<string>();
        public bool hasErrors = false;

        public SR_2_1_RuleChecking(Int64 IfcModel)
        {
            string[] interestingElements = {"IfcWall", "IfcWallStandardCase", "IfcWallElementedCase", "IfcCurtainWall", "IfcSlab", "IfcSlabStandardCase", "IfcSlabElementedCase", "IfcBeam", "IfcBeamStandardCase",
                "IfcRoof", "IfcColumn", "IfcColumnStandardCase", "IfcWindow", "IfcWindowStandardCase", "IfcDoor", "IfcDoorStandardCase", "IfcOpeningElement", "IfcOpeningStandardCase", "IfcVirtualElement"};
            foreach (var e in interestingElements)
            {
                Int64 eInstances = IfcEngine.sdaiGetEntityExtentBN(IfcModel, e);
                Int64 Num = IfcEngine.sdaiGetMemberCount(eInstances);
                if (Num != 0)
                {
                    for (int i = 0; i < Num; i++)
                    {
                        Int64 eInstance = 0;
                        IfcEngine.engiGetAggrElement(eInstances, i, IfcEngine.sdaiINSTANCE, out eInstance);
                        IfcBuildingElement elementInstance = new IfcBuildingElement(IfcModel, eInstance);

                        if (IfcEngine.sdaiGetMemberCount(elementInstance.HasFillings) == 0 && IfcEngine.sdaiGetMemberCount(elementInstance.Decomposes) == 0)
                        {
                            if (IfcEngine.sdaiGetMemberCount(elementInstance.SBIntanceSet) == 0)
                            {
                                hasErrors = true;
                                failingBuildingElements.Add(elementInstance.instanceName + " " + e);
                            }                             
                        }
                    }
                }

            }
        }
    }

    // SR.2.2: The following architecture elements if available shall probably not have SBs: 
    //         Beams (IfcBeam), stairs (IfcStair), ramps (IfcRamp), and building element proxies (IfcBuildingElementProxy)
    public class SR_2_2_RuleChecking
    {
        public string errorReporting = "SR.2.2: The following building element instances should not provide SBs: ";
        public List<string> failingBuildingElements = new List<string>();
        public bool hasErrors = false;

        public SR_2_2_RuleChecking(Int64 IfcModel)
        {
            string[] interestingElements = {"IfcStair", "IfcRamp"};
            foreach (var e in interestingElements)
            {
                Int64 eInstances = IfcEngine.sdaiGetEntityExtentBN(IfcModel, e);
                Int64 Num = IfcEngine.sdaiGetMemberCount(eInstances);
                if (Num != 0)
                {
                    for (int i = 0; i < Num; i++)
                    {
                        Int64 eInstance = 0;
                        IfcEngine.engiGetAggrElement(eInstances, i, IfcEngine.sdaiINSTANCE, out eInstance);
                        IfcBuildingElement elementInstance = new IfcBuildingElement(IfcModel, eInstance);

                        if (IfcEngine.sdaiGetMemberCount(elementInstance.SBIntanceSet) != 0)
                        {
                            hasErrors = true;
                            failingBuildingElements.Add(elementInstance.instanceName + " " + e);
                        }                     
                    }
                }
            }
        }
    }

    // SR.3: Checking of openings’ SBs
    // SR.3.1: SBs of windows and doors shall be directly linked to corresponding IfcWindow and IfcDoor instances 
    //         rather than the IfcOpeningElement instances
    public class SR_3_1_RuleChecking
    {
        public string errorReporting = "SR.3.1: The RelatedBuildingElement of the following SBs should directly reference corresponding IfcWindow or IfcDoor instances: ";
        public Dictionary<string, string> SB_CorrespondingOpening = new Dictionary<string, string>(); // SB should reference CorrespondingOpening
        public bool hasErrors = false;
        public List<string> failingSBs_instanceNames = new List<string>();       

        public SR_3_1_RuleChecking(Int64 IfcModel, List<IfcRelSpaceBoundary> SBs)
        {
            foreach (var sb in SBs)
            {
                if (sb.RelatedBuildingElementType == BuildingElementType.IfcOpeningStandardCase)
                {
                    IfcBuildingElement element = new IfcBuildingElement(IfcModel, sb.RelatedBuildingElementInstance);
                    if (IfcEngine.sdaiGetMemberCount(element.HasFillings) != 0)
                    {
                        Int64 RelFillsElement = 0;  // !!!: We assume only one IfcRelFillsElement per opening void
                        IfcEngine.engiGetAggrElement(element.HasFillings, 0, IfcEngine.sdaiINSTANCE, out RelFillsElement);
                        Int64 windowDoor = 0;
                        IfcEngine.sdaiGetAttrBN(RelFillsElement, "RelatedBuildingElement", IfcEngine.sdaiINSTANCE, out windowDoor);
                        IfcBuildingElement windowdoorelement = new IfcBuildingElement(IfcModel, windowDoor);
                        hasErrors = true;
                        this.SB_CorrespondingOpening.Add(sb.InstanceName + " " + "IfcRelSpaceBoundary2ndLevel", windowdoorelement.instanceName + " " + windowdoorelement.entityName);
                        failingSBs_instanceNames.Add(sb.InstanceName);
                    }
                }
            }
        }    
    }

    // SR.4: Checking of container/assessble elements’ SBs
    // SR.4.1: SB instances of container elements including curtain walls and roofs shall be directly linked to corresponding container element instances (i.e., IfcCurtanWall and IfcRoof) rather than their component instances
    public class SR_4_1_RuleChecking
    {
        public string errorReporting = "SR.4.1: The RelatedBuildingElement of the following SBs should directly reference corresponding aggregrate element instances: ";
        public Dictionary<string, string> SB_AggregrateContainerElement = new Dictionary<string, string>(); // SB should reference AggregrateContainerElement
        public bool hasErrors = false;
        public List<string> failingSBs_instanceNames = new List<string>();

        public SR_4_1_RuleChecking(Int64 IfcModel)
        {
            Int64 roofInstances = IfcEngine.sdaiGetEntityExtentBN(IfcModel, "IfcRoof");
            Int64 Num_Roofs = IfcEngine.sdaiGetMemberCount(roofInstances);
            if (Num_Roofs != 0)
            {
                for (int i = 0; i < Num_Roofs; i++)
                {
                    Int64 roofInstance = 0;
                    IfcEngine.engiGetAggrElement(roofInstances, i, IfcEngine.sdaiINSTANCE, out roofInstance);

                    Int64 roofInstanceName = IfcEngine.internalGetP21Line(roofInstance);

                    Int64 RelAggregates = 0;
                    IfcEngine.sdaiGetAttrBN(roofInstance, "IsDecomposedBy", IfcEngine.sdaiAGGR, out RelAggregates);

                    if (RelAggregates != 0)
                    {
                        Int64 RelAggregate = 0;
                        IfcEngine.engiGetAggrElement(RelAggregates, 0, IfcEngine.sdaiINSTANCE, out RelAggregate); // we assume one relAggregates 

                        Int64 RelatedObjects = 0;
                        IfcEngine.sdaiGetAttrBN(RelAggregate, "RelatedObjects", IfcEngine.sdaiAGGR, out RelatedObjects);

                        Int64 Num_RelatedObjects = IfcEngine.sdaiGetMemberCount(RelatedObjects);
                        if (Num_RelatedObjects != 0)
                        {
                            for (int j = 0; j < Num_RelatedObjects; j++)
                            {
                                Int64 Object = 0;
                                IfcEngine.engiGetAggrElement(RelatedObjects, j, IfcEngine.sdaiINSTANCE, out Object);

                                Int64 SBs = 0;
                                IfcEngine.sdaiGetAttrBN(Object, "ProvidesBoundaries", IfcEngine.sdaiAGGR, out SBs);
                                Int64 NumSBs = IfcEngine.sdaiGetMemberCount(SBs);
                                if (NumSBs != 0)
                                {
                                    for (int k = 0; k < NumSBs; k++)
                                    {
                                        Int64 SBInstance = 0;
                                        IfcEngine.engiGetAggrElement(SBs, k, IfcEngine.sdaiINSTANCE, out SBInstance);
                                        Int64 instanceName = IfcEngine.internalGetP21Line(SBInstance);
                                        this.SB_AggregrateContainerElement.Add("#" + instanceName.ToString() + " " + "IfcRelSpaceBoundary2ndLevel",
                                             "#" + roofInstanceName + " " + "IfcRoof");
                                        hasErrors = true;
                                        failingSBs_instanceNames.Add("#" + instanceName.ToString());
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    #endregion


    #region GR: Geometric Validation Rules

    // GR.1: SB geometric representation checking
    // GR.1.1: The geometry of each SB shall be a simple polygon
    public class GR_1_1_RuleChecking
    {
        public string errorReporting = "GR.1.1: The geometry of the following SBs is not a valid simple polygon: ";
        public List<string> failingSBs_eR = new List<string>();
        public bool hasErrors = false;
        public List<string> failingSBs_instanceNames = new List<string>();

        public GR_1_1_RuleChecking()
        {

        }

        public GR_1_1_RuleChecking(ref List<IfcRelSpaceBoundary> SBs)
        {
            Point2D p = new Point2D();
            foreach (var sb in SBs)
            {
                //if (sb.InstanceName == "#964303")
                //{
                    bool hasErrors_local = false;
                    if (sb.Polygon2D_OwnLCS.Vertices.Count >= 3) // Condition 1 (as SB extraction function has removed the repeated vertex)
                    {
                        // Condition 2: All edges of the polygon is valid 
                        List<LineSegment> edges = new List<LineSegment>();
                        int num = sb.Polygon2D_OwnLCS.Vertices.Count;
                        for (int i = 0; i < num - 1; i++)
                        {
                            if (p.SamePoint(sb.Polygon2D_OwnLCS.Vertices[i], sb.Polygon2D_OwnLCS.Vertices[i + 1]))
                            {
                                hasErrors_local = true;
                                hasErrors = true;
                                failingSBs_eR.Add(sb.InstanceName + " IfcRelSpaceBoundary2ndLevel");
                                sb.isValidPolygon = false;
                                failingSBs_instanceNames.Add(sb.InstanceName);
                                break;
                            }
                            else
                                edges.Add(new LineSegment(sb.Polygon2D_OwnLCS.Vertices[i], sb.Polygon2D_OwnLCS.Vertices[i + 1]));
                        }

                        if (!hasErrors_local)
                        {
                            if (p.SamePoint(sb.Polygon2D_OwnLCS.Vertices[num - 1], sb.Polygon2D_OwnLCS.Vertices[0]))
                            {
                                hasErrors_local = true;
                                hasErrors = true;
                                failingSBs_eR.Add(sb.InstanceName + " IfcRelSpaceBoundary2ndLevel");
                                sb.isValidPolygon = false;
                                failingSBs_instanceNames.Add(sb.InstanceName);
                            }
                            else
                                edges.Add(new LineSegment(sb.Polygon2D_OwnLCS.Vertices[num - 1], sb.Polygon2D_OwnLCS.Vertices[0]));
                        }

                        if (!hasErrors_local)  // Condition 3: All edges of the polygon do not have self-intersection
                        {
                            GeometricOperations GO = new GeometricOperations();
                            for (int i = 0; i < edges.Count; i++)
                            {
                                List<LineSegment> updatedEdges = UpdatedEdges(i, edges);
                                if (GO.LS_LSsIntersection(edges[i], updatedEdges))
                                {
                                    hasErrors_local = true;
                                    hasErrors = true;
                                    sb.isValidPolygon = false;
                                    failingSBs_eR.Add(sb.InstanceName + " IfcRelSpaceBoundary2ndLevel");
                                    failingSBs_instanceNames.Add(sb.InstanceName);
                                    break;
                                }
                            }
                        }

                        if (!hasErrors_local)
                        {
                        // !!!: Triangulate the SB if possible; otherwise set sb.isValidPolygon = false
                        // ???: For some invalid polygons, SBTriangulationSpaceLCSAndWCS() can still sucessfully run
                        sb.SBTriangulationSpaceLCSAndWCS(); // This must be conducted
                        //sb.SBTriangulation();
                            if (!sb.isValidPolygon)
                            {
                                hasErrors_local = true;
                                hasErrors = true;
                                failingSBs_eR.Add(sb.InstanceName + " IfcRelSpaceBoundary2ndLevel");
                                failingSBs_instanceNames.Add(sb.InstanceName);
                            }
                        }
                    }
                    else
                    {
                        hasErrors_local = true;
                        hasErrors = true;
                        sb.isValidPolygon = false;
                        failingSBs_eR.Add(sb.InstanceName + " IfcRelSpaceBoundary2ndLevel");
                        failingSBs_instanceNames.Add(sb.InstanceName);
                    }
                //}             
            }
        }

        private List<LineSegment> UpdatedEdges(int i, List<LineSegment> edges)
        {
            List<LineSegment> result = new List<LineSegment>();
            for (int j = 0; j < edges.Count; j++)
            {
                if (j != i)
                    result.Add(edges[j]);
            }
            return result;
        }
    }

    // GR.1.2: The geometry of each SB shall be defined with a normal pointing outward the relating space (for non-shading SBs) or outward the related building element (for shading SBs)
    public class GR_1_2_RuleChecking
    {
        public string errorReporting_1 = "GR.1.2: The normal of the following non-shading SBs points inward their relating space: ";
        public List<string> failingSBs_eR1 = new List<string>();
        public string errorReporting_2 = "GR.1.2: The normal of the following shading SBs points inward their related element: ";
        public List<string> failingSBs_eR2 = new List<string>();
        public bool hasErrors = false;
        public List<string> failingSBs_instanceNames = new List<string>();
        public List<IfcRelSpaceBoundary> DefectiveSBs = new List<IfcRelSpaceBoundary>();

        public GR_1_2_RuleChecking()
        {

        }
        public GR_1_2_RuleChecking(Int64 IfcModel, List<IfcRelSpaceBoundary> SBs_SSV_GRC1_1, double dimensionalScale, List<IfcSpace> spaces, List<IfcBuildingElement> elements2019)
        {
            GeometricOperations GO = new GeometricOperations();
            foreach (var sb in SBs_SSV_GRC1_1)
            {
                Point3D centre = new Point3D();
                centre.x = (sb.TriangulatedSB_WCS[0].Vertex1.x + sb.TriangulatedSB_WCS[0].Vertex2.x + sb.TriangulatedSB_WCS[0].Vertex3.x) / 3.0;
                centre.y = (sb.TriangulatedSB_WCS[0].Vertex1.y + sb.TriangulatedSB_WCS[0].Vertex2.y + sb.TriangulatedSB_WCS[0].Vertex3.y) / 3.0;
                centre.z = (sb.TriangulatedSB_WCS[0].Vertex1.z + sb.TriangulatedSB_WCS[0].Vertex2.z + sb.TriangulatedSB_WCS[0].Vertex3.z) / 3.0;

                centre = GO.OffsetPoint(centre, 20.0/ dimensionalScale, sb.Polygon3D_WCS.SurfaceNormal);

                if (sb.RelatingSpaceType == SpaceType.IfcSpace)
                {
                    IfcSpace space = FindSpace(sb.RelatingSpaceGlobalID, spaces);
                    if (GO.PointInFacetedBrep(centre, sb.Polygon3D_WCS.SurfaceNormal, space.FactedBrep))
                    {
                        hasErrors = true;
                        failingSBs_eR1.Add(sb.InstanceName + " IfcRelSpaceBoundary2ndLevel");
                        failingSBs_instanceNames.Add(sb.InstanceName);
                        this.DefectiveSBs.Add(sb);
                    }
                } else  // shading SBs
                {
                    IfcBuildingElement element = FindElement(sb.RelatedBuildingElementGlobalID, elements2019);
                    if (GO.PointInFacetedBrep(centre, sb.Polygon3D_WCS.SurfaceNormal, element.FacetedBrep))
                    {
                        hasErrors = true;
                        failingSBs_eR2.Add(sb.InstanceName + " IfcRelSpaceBoundary2ndLevel");
                        failingSBs_instanceNames.Add(sb.InstanceName);
                        this.DefectiveSBs.Add(sb);
                    }
                }               
            }
        }

        private IfcSpace FindSpace(string spaceGlobalID, List<IfcSpace> spaces)
        {
            IfcSpace result = new IfcSpace();
            foreach (var s in spaces)
            {
                if (s.GlobalID == spaceGlobalID)
                {
                    result = s;
                    break;
                }
            }

            return result;
        }

        private IfcBuildingElement FindElement(string elementGlobalID, List<IfcBuildingElement> elements)
        {
            IfcBuildingElement result = new IfcBuildingElement();
            foreach (var e in elements)
            {
                if (e.GlobalID == elementGlobalID)
                {
                    result = e;
                    break;
                }
            }

            return result;
        }
    }

    // GR.2: Space airtightness checking
    // GR.2.1: Any sets of SBs that are relating to a common space shall correctly and airtightly bound the space without gaps and overlaps.
    public class GR_2_RuleChecking
    {
        public string errorReporting = "GR.2: The following spaces have not been airtightly enclosed by their SBs: ";
        public Dictionary<string, string> failingSpaces_error = new Dictionary<string, string>();
        public Dictionary<Ray3D, defectiveSpace> ray_defectSpace = new Dictionary<Ray3D, defectiveSpace>(); // non-opening SBs
        public bool hasErrors = false;

        public GR_2_RuleChecking()
        {

        }
        public GR_2_RuleChecking(List<IfcSpace> spaces, int MaxDepth, int NumRay, float dimensionalScale)
        {
            foreach (var space in spaces)
            {
                int NumTriSB = space.RelatedNonOpeningTSBs_InSpace.Count;
                if (NumTriSB != 0)
                {
                    #region Approach 1: pure ray tracing 
                    if (MaxDepth == 0)
                    {
                        for (int iTriSB = 0; iTriSB < NumTriSB; iTriSB++)
                        {
                            bool isfinished = false;
                            // 1. create a ray set for the triangulated SB
                            Ray3D ray = new Ray3D();
                            List<Ray3D> RaySet = ray.Rays_Triangle_MonteCarlo(NumRay, space.RelatedNonOpeningTSBs_InSpace[iTriSB].TriangulatedSBSpace);
                            string Ray_SBGlobalID = space.RelatedNonOpeningTSBs_InSpace[iTriSB].SBGlobalID;

                            for (int iRay = 0; iRay < NumRay; iRay++)
                            {
                                // 2. conduct ray-triangulatedSBs intersection test            
                                ValidIntersection test = Ray_TSBS_IntersectionTest(RaySet[iRay], Ray_SBGlobalID, space.RelatedNonOpeningTSBs_InSpace[iTriSB], space.RelatedNonOpeningTSBs_InSpace, space.RelatedSBs, dimensionalScale);
                                if (!test.result)
                                {
                                    this.failingSpaces_error.Add(space.InstanceName + " IfcSpace", test.explanation);
                                    hasErrors = true;
                                    isfinished = true;
                                    break;
                                }
                            }
                            if (isfinished)
                                break;
                        }
                    }
                    #endregion

                    #region Approach 2: ray tracing using AABB tree indexing
                    if (MaxDepth > 0)
                    {
                        // 1. AABB tree construction
                        AABB_TriangulatedSB_Tree Tree = new AABB_TriangulatedSB_Tree(space.RelatedNonOpeningTSBs_InSpace, MaxDepth);
                        for (int iTriSB = 0; iTriSB < NumTriSB; iTriSB++)
                        {
                            bool isfinished = false;
                            // 2. create the ray set for the triangulated SB
                            Ray3D ray = new Ray3D();
                            List<Ray3D> RaySet = ray.Rays_Triangle_MonteCarlo
                                (NumRay, space.RelatedNonOpeningTSBs_InSpace[iTriSB].TriangulatedSBSpace);
                            string Ray_SBGlobalID = space.RelatedNonOpeningTSBs_InSpace[iTriSB].SBGlobalID;

                            for (int iRay = 0; iRay < NumRay; iRay++)
                            {
                                // 3. traverse AABB tree to find candinates
                                List<TriangulatedSpaceBoundary> CandinateSBs = FindCandinateTriangulatedSBs(RaySet[iRay], Tree);

                                // 4. conduct ray-triangulatedSBs intersection test            
                                ValidIntersection test = Ray_TSBS_IntersectionTest(RaySet[iRay], Ray_SBGlobalID, space.RelatedNonOpeningTSBs_InSpace[iTriSB], CandinateSBs, space.RelatedSBs, dimensionalScale);
                                if (!test.result)
                                {
                                    this.failingSpaces_error.Add(space.InstanceName + " IfcSpace", test.explanation);
                                    defectiveSpace ds = new defectiveSpace();
                                    ds.spaceInstanceName = space.InstanceName;
                                    ds.nonopeningSBs = space.RelatedNonOpeningSBs;
                                    this.ray_defectSpace.Add(RaySet[iRay], ds);
                                    hasErrors = true;
                                    isfinished = true;
                                    break;
                                }
                            }
                            if (isfinished)
                                break;
                        }
                    }
                    #endregion
                }
            }
        }

        private List<TriangulatedSpaceBoundary> FindCandinateTriangulatedSBs(Ray3D ray, AABB_TriangulatedSB_Tree tree)
        {
            List<TriangulatedSpaceBoundary> Candinates = new List<TriangulatedSpaceBoundary>();

            List<AABB_TriangulatedSB_TreeNode> LeafNodes = tree.RootNode.AABBTreeTraversing(ray);
            foreach (var node in LeafNodes)
            {
                foreach (var TSB in node.TriangulatedSBs)
                {
                    Candinates.Add(TSB);
                }
            }

            return Candinates;
        }

        private ValidIntersection Ray_TSBS_IntersectionTest(Ray3D ray, string ray_SBGlobalID, TriangulatedSpaceBoundary RayTSB, List<TriangulatedSpaceBoundary> TSBs, List<IfcRelSpaceBoundary> SBS, float dimensionalScale)
        {
            ValidIntersection testResult = new ValidIntersection();
            Vector3D vector = new Vector3D();

            // 1. detect all intersections 
            List<RayTSBIntersection> Intersections = new List<RayTSBIntersection>();
            List<double> Distances = new List<double>();
            for (int i = 0; i < TSBs.Count; i++)
            {
                if (TSBs[i].SBGlobalID != ray_SBGlobalID)
                {
                    Ray3D_Triangle3D_do_Intersection ray_triangle_test = new Ray3D_Triangle3D_do_Intersection(ray, TSBs[i].TriangulatedSBSpace);
                    if (ray_triangle_test.Intersection)
                    {
                        RayTSBIntersection intersection = new RayTSBIntersection();
                        intersection.SBGlobalID = TSBs[i].SBGlobalID;
                        intersection.SBInstanceName = TSBs[i].SBInstanceName;
                        intersection.SBSurfaceNormal = TSBs[i].TriangulatedSBSpace.NormalVector;
                        intersection.IntersectionPoint = ray_triangle_test.IntersectionPoint;
                        intersection.Distance = vector.VectorLength(vector.VectorConstructor(ray.StartPoint, intersection.IntersectionPoint));
                        Intersections.Add(intersection);
                        Distances.Add(intersection.Distance);
                    }
                }
            }

            if (Distances.Count == 0)
            {
                testResult.result = false;
                testResult.explanation = "Ray emitted from " + RayTSB.SBInstanceName + " IfcRelSpaceBoundary2ndLevel " + "has no intersection";
            }

            if (Distances.Count != 0)
            {
                // 2. find nearest intersections
                double mini = Distances.Min();
                List<RayTSBIntersection> N_Intersections = new List<RayTSBIntersection>();
                for (int i = 0; i < Intersections.Count; i++)
                {
                    if (Math.Abs(Intersections[i].Distance - mini) < (0.00001/dimensionalScale))  // tolerance: 10^-5 mm (Notice the unit)
                        N_Intersections.Add(Intersections[i]);
                }

                if (N_Intersections.Count > 0)
                {
                    // 3. find the back side intersection
                    List<RayTSBIntersection> NB_Intersections = new List<RayTSBIntersection>();
                    for (int j = 0; j < N_Intersections.Count; j++)
                    {
                        if (vector.DotProduct(ray.Direction, N_Intersections[j].SBSurfaceNormal) < 0)
                        {
                            testResult.result = false;
                            testResult.explanation = "Ray emitted from " + RayTSB.SBInstanceName + " IfcRelSpaceBoundary2ndLevel " + "has front-side intersection on " + N_Intersections[j].SBInstanceName + " IfcRelSpaceBoundary2ndLevel";
                            return testResult;
                        }
                        else
                            NB_Intersections.Add(N_Intersections[j]);
                    }

                    if (NB_Intersections.Count == 1)
                        testResult.result = true;
                    if (NB_Intersections.Count > 1)
                    {
                        // 4. check whether the intersection point locates in the interior of a SB
                        List<String> SBGlobalIDs = FindAllSBs(NB_Intersections); // find all involved SBs
                        if (SBGlobalIDs.Count == 1)
                            testResult.result = true;
                        if (SBGlobalIDs.Count > 1)
                        {
                            List<IfcRelSpaceBoundary> OverlapSBs = new List<IfcRelSpaceBoundary>();
                            string overlaps = null;
                            foreach (var GlobalID_A in SBGlobalIDs)
                            {
                                IfcRelSpaceBoundary SB_A = FindSB(GlobalID_A, SBS);
                                OverlapSBs.Add(SB_A);
                                overlaps += SB_A.InstanceName + " IfcRelSpaceBoundary2ndLevel ";
                            }

                            foreach (var sb in OverlapSBs)
                            {
                                if (IntersectionOccurInSB(NB_Intersections[0], sb))
                                {
                                    testResult.result = false;
                                    testResult.explanation = "Ray emitted from " + RayTSB.SBInstanceName + " IfcRelSpaceBoundary2ndLevel" +
                                        " hits the overlap between " + overlaps;
                                    return testResult;
                                }
                            }
                            testResult.result = true;
                        }
                    }
                }
            }
            return testResult;
        }

        //"The Point in Polygon Problem for Arbitrary Polygons" by Hormann & Agathos
        //http://citeseerx.ist.psu.edu/viewdoc/download?doi=10.1.1.88.5498&rep=rep1&type=pdf
        private bool IntersectionOccurInSB(RayTSBIntersection intersection, IfcRelSpaceBoundary SB)
        {
            bool result = false;

            Vector3D vector = new Vector3D();
            Vector3D xAxis = vector.VectorConstructor(SB.Polygon3D_InSpace.Vertices[0], SB.Polygon3D_InSpace.Vertices[1]);
            xAxis = vector.UnitVector(xAxis);
            AffineTR affine = new AffineTR();
            double[,] TMmatrix = affine.TRMatrix(SB.Polygon3D_InSpace.Vertices[0], xAxis, SB.Polygon3D_InSpace.SurfaceNormal);
            InverseMatrix IM = new InverseMatrix();
            double[,] ITMatrix = IM.IMatrix_Matrix(TMmatrix);

            PointCoordTransf pointTransf = new PointCoordTransf();
            Point3D p = pointTransf.PointTransf3D(intersection.IntersectionPoint, ITMatrix);
            IntPoint intersectionPoint2D = new IntPoint((Int64)(p.x * 1000000000), (Int64)(p.y * 1000000000));

            Path SBPolygon = new Path();
            for (int i = 0; i < SB.Polygon3D_InSpace.Vertices.Count; i++)
            {
                Point3D p3D = pointTransf.PointTransf3D(SB.Polygon3D_InSpace.Vertices[i], ITMatrix);
                SBPolygon.Add(new IntPoint((Int64)(p3D.x * 1000000000), (Int64)(p3D.y * 1000000000)));
            }

            Clipper clip = new Clipper();
            int test = clip.PointInPolygon(intersectionPoint2D, SBPolygon); // returns 0 if false, +1 if true, -1 if pt ON polygon boundary
            if (test == 1)
                result = true;

            return result;
        }

        private List<String> FindAllSBs(List<RayTSBIntersection> intersections)
        {
            List<String> SBGlobalIDs = new List<string>();

            foreach (var intersection in intersections)
            {
                if (SBGlobalIDs.Count == 0)
                {
                    SBGlobalIDs.Add(intersection.SBGlobalID);
                }
                else
                {
                    bool duplicate = false;
                    foreach (var GlobalID in SBGlobalIDs)
                    {
                        if (intersection.SBGlobalID == GlobalID)
                        {
                            duplicate = true;
                            break;
                        }
                    }
                    if (!duplicate)
                        SBGlobalIDs.Add(intersection.SBGlobalID);
                }
            }
            return SBGlobalIDs;
        }

        private IfcRelSpaceBoundary FindSB(string GlobalID, List<IfcRelSpaceBoundary> SBs)
        {
            IfcRelSpaceBoundary result = null;
            foreach (var SB in SBs)
            {
                if (SB.GlobalID == GlobalID)
                {
                    result = SB;
                    break;
                }
            }
            return result;
        }
    }

    public class defectiveSpace
    {
        public string spaceInstanceName;
        public List<IfcRelSpaceBoundary> nonopeningSBs = new List<IfcRelSpaceBoundary>();
    }

    #endregion


    #region CR: Consistency Validation Rules

    // CR.1: IfcRelSpaceBoundary2ndLevel.Description/InternalOrExternalBoundary consistency checking
    // CR.1.1: IF the value of Description is “2a” AND the value of InternalOrExternalBoundary is “INTERNAL”, THEN the object on the other side of the SB’s RelatedBuildingElement must be a space
    // CR.1.2: IF the value of Description is “2a” AND the value of InternalOrExternalBoundary is “EXTERNAL”, THEN the object on the other side of the SB’s RelatedBuildingElement must be the outdoor environment
    // CR.1.3: IF the value of Description is “2a” AND the value of InternalOrExternalBoundary is “EXTERNAL_EARTH”, THEN the object on the other side of the SB’s RelatedBuildingElement must be a site object
    // CR.1.4: IF the value of Description is “2b”, THEN the object on the other side of the SB’s RelatedBuildingElement must be a non-shading element
    // CR.1.5: IF the value of Description is “Shading”, THEN the SB’s RelatedBuildingElement must be a shading element
    public class CR_1_RuleChecking
    {
        public string errorReporting_1 = "CR.1.1: The status on the other side of the related element of the following SBs is not a space. There should be errors in their Description and/or InternalOrExternalBoundary: ";
        public List<string> failingSBs_eR1 = new List<string>();

        public string errorReporting_2 = "CR.1.2: The status on the other side of the related element of the following SBs is not the outdoor environment. There should be errors in their Description and/or InternalOrExternalBoundary: ";
        public List<string> failingSBs_eR2 = new List<string>();

        public string errorReporting_3 = "CR.1.3: The status on the other side of the related element of the following SBs is not a site object. There should be errors in their Description and/or InternalOrExternalBoundary: ";
        public List<string> failingSBs_eR3 = new List<string>();

        public string errorReporting_4 = "CR.1.4: The status on the other side of the related element of the following SBs is not a non-shading element. Their Description should be '2a' or 'Shading' rather than '2b':";
        public List<string> failingSBs_eR4 = new List<string>();

        public string errorReporting_5 = "CR.1.5: The following SBs play a role in bounding an interior space. Their Description should not be 'Shading': ";
        public List<string> failingSBs_eR5 = new List<string>();

        public bool hasErrors = false;
        public List<string> failingSBs_instanceNames = new List<string>();


        #region IMPORTANT!!!
        //The offset distance is important.
        // If we follow the heat transfer principle, we should set 800mm, but which can still have degenerate issues for very slim spaces;
        // If we follow early version SB generation algorithm, we should consider that once the other side is an object not a space, it should be 2b. then we should use varying distance slightly larger the related building element's thickness.  
        // Currently, we use the second strategy. For different Ifc files, we may accoridngly change the strategy.
        #endregion
        public CR_1_RuleChecking(List<IfcRelSpaceBoundary> SBs_SSV_GR1_1, List<IfcRelSpaceBoundary> SBs_SSV_GR1_1_GR1_2, List<IfcSpace> Spaces, List<IfcBuildingElement> Elements2019, List<IfcSite> Sites, float dimensionalScale)
        {
            GeometricOperations OS = new GeometricOperations();

            // A “Shading” SB should not bound any interior spaces.
            foreach (var sb in SBs_SSV_GR1_1)
            {
                if (sb.Description == "Shading")
                {
                    bool connection = false;
                    foreach (var space in Spaces)
                    {
                        foreach (var face in space.FactedBrep.FacetedBrep_Polygon)
                        {
                            if (OS.isIncludedBy(sb.Polygon3D_WCS, face, 0.99, dimensionalScale))
                            {
                                connection = true;
                                break;
                            }
                        }
                        if (connection)
                            break;
                    }

                    if (connection)
                    {
                        hasErrors = true;
                        failingSBs_eR5.Add(sb.InstanceName + " IfcRelSpaceBoundary2ndLevel");
                        failingSBs_instanceNames.Add(sb.InstanceName);
                    }
                }            
            }

            foreach (var sb in SBs_SSV_GR1_1_GR1_2)
            {
                Point3D centre = new Point3D();

                // Comput centroid                
                centre.x = (sb.TriangulatedSB_WCS[0].Vertex1.x + sb.TriangulatedSB_WCS[0].Vertex2.x + sb.TriangulatedSB_WCS[0].Vertex3.x) / 3.0;
                centre.y = (sb.TriangulatedSB_WCS[0].Vertex1.y + sb.TriangulatedSB_WCS[0].Vertex2.y + sb.TriangulatedSB_WCS[0].Vertex3.y) / 3.0;
                centre.z = (sb.TriangulatedSB_WCS[0].Vertex1.z + sb.TriangulatedSB_WCS[0].Vertex2.z + sb.TriangulatedSB_WCS[0].Vertex3.z) / 3.0;

                // Offset centroid along the normal direction by a distance that is slightly than building element's thickness: thickness + 200mm
                IfcBuildingElement element = FindExactElement(sb.RelatedBuildingElementGlobalID, Elements2019);
                double thick = 0;
                if (element.thickness != 0)
                    thick = element.thickness + 200;
                else
                    thick = 350;
                               
                centre = OS.OffsetPoint(centre, thick, sb.Polygon3D_WCS.SurfaceNormal);

                #region Description = 2a

                if (sb.Description == "2a")
                {
                    if (sb.InternalOrExternalBoundary == InternalOrExternal.INTERNAL)
                    {
                        bool existIn = false;
                        foreach (var space in Spaces)
                        {
                            if (OS.PointInFacetedBrep(centre, sb.Polygon3D_WCS.SurfaceNormal, space.FactedBrep))
                            {
                                existIn = true;
                                break;
                            }
                        }
                        if (!existIn)
                        {
                            hasErrors = true;
                            failingSBs_eR1.Add(sb.InstanceName + " IfcRelSpaceBoundary2ndLevel");
                            failingSBs_instanceNames.Add(sb.InstanceName);
                        }
                    }

                    if (sb.InternalOrExternalBoundary == InternalOrExternal.EXTERNAL)
                    {                     
                        bool correct = false;
                        bool inSpace = false;
                        foreach (var space in Spaces)
                        {
                            if (OS.PointInFacetedBrep(centre, sb.Polygon3D_WCS.SurfaceNormal, space.FactedBrep))
                            {
                                inSpace = true;
                                break;
                            }
                        }

                        if (!inSpace)
                        {
                            bool inSite = false;
                            foreach (var site in Sites)
                            {
                                if (OS.PointInFacetedBrep(centre, sb.Polygon3D_WCS.SurfaceNormal, site.GlobalBrep))
                                {
                                    inSite = true;
                                    break;
                                }
                            }
                            if (!inSite)
                            {
                                bool inNonShadingElement = false;
                                foreach (var e in Elements2019)
                                {
                                    if (OS.PointInFacetedBrep(centre, sb.Polygon3D_WCS.SurfaceNormal, e.FacetedBrep))
                                    {
                                        if (isNotShadingElement(e, Spaces, dimensionalScale))
                                        {
                                            inNonShadingElement = true;
                                            break;
                                        }
                                    }
                                }
                                if (!inNonShadingElement)
                                    correct = true;
                            }
                        }
                        if (!correct)
                        {
                            hasErrors = true;
                            failingSBs_eR2.Add(sb.InstanceName + " IfcRelSpaceBoundary2ndLevel");
                            failingSBs_instanceNames.Add(sb.InstanceName);
                        }
                    }

                    if (sb.InternalOrExternalBoundary == InternalOrExternal.EXTERNAL_EARTH)
                    {
                        bool existIn = false;
                        foreach (var site in Sites)
                        {
                            if (OS.PointInFacetedBrep(centre, sb.Polygon3D_WCS.SurfaceNormal, site.GlobalBrep))
                            {
                                existIn = true;
                                break;
                            }
                        }
                        if (!existIn)
                        {
                            hasErrors = true;
                            failingSBs_eR3.Add(sb.InstanceName + " IfcRelSpaceBoundary2ndLevel");
                            failingSBs_instanceNames.Add(sb.InstanceName);
                        }
                    }
                }

                #endregion

                #region Description = 2b

                // !!!: a pairwise SBs that bound a same space is also defined as "2b" and the centre point will be located in its own space rather than an element
                if (sb.Description == "2b")
                {
                    bool inRelatingSpace = false;
                    if (sb.RelatingSpaceType == SpaceType.IfcSpace)
                    {
                        IfcSpace space = FindExactSpace(sb.RelatingSpaceGlobalID, Spaces);
                        if (OS.PointInFacetedBrep(centre, sb.Polygon3D_WCS.SurfaceNormal, space.FactedBrep))
                            inRelatingSpace = true;
                    }

                    if (!inRelatingSpace)
                    {
                        bool inSpaceWhenInternal = false;
                        if (sb.InternalOrExternalBoundary == InternalOrExternal.INTERNAL && sb.CorrespondingBoundaryInstance ==0)
                        {
                            foreach (var s in Spaces)
                            {
                                if (OS.PointInFacetedBrep(centre, sb.Polygon3D_WCS.SurfaceNormal, s.FactedBrep))
                                {
                                    inSpaceWhenInternal = true;
                                    break;
                                }
                            }
                        }

                        if (!inSpaceWhenInternal)
                        {
                            bool inElement = false;
                            foreach (var e in Elements2019)
                            {
                                if (OS.PointInFacetedBrep(centre, sb.Polygon3D_WCS.SurfaceNormal, e.FacetedBrep))
                                {
                                    inElement = true;
                                    break;
                                }
                            }
                            if (!inElement)
                            {
                                hasErrors = true;
                                failingSBs_eR4.Add(sb.InstanceName + " IfcRelSpaceBoundary2ndLevel");
                                failingSBs_instanceNames.Add(sb.InstanceName);
                            }
                        }                    
                    }                
                }
                #endregion
            }
        }

        private bool isNotShadingElement(IfcBuildingElement e, List<IfcSpace> Spaces, float dimensionalScale)
        {
            bool result = false;
            GeometricOperations GO = new GeometricOperations();

            foreach (var Space in Spaces)
            {
                if (GO.AABB_AABB_IntersectionTest(Space.FactedBrep.AABB, e.FacetedBrep.AABB))
                {
                    foreach (var faceSpace in Space.FactedBrep.FacetedBrep_Polygon)
                    {
                        // 1. Set a LCS for both surfaces
                        // Note: This is only for CB extraction and different from CommonBoundary for SB instance creation
                        double[,] TM_LCS_GCS = new double[4, 4];
                        double[,] TM_GCS_LCS = new double[4, 4];
                        GO.LCSSetting(faceSpace, ref TM_LCS_GCS, ref TM_GCS_LCS);

                        // 2. Trasnform faces into the LCS and project in XY plane of the LCS
                        Polyline3D faceSpaceLCS = new Polyline3D();
                        PointCoordTransf pointTransf = new PointCoordTransf();
                        foreach (var vertex in faceSpace.Vertices)
                        {
                            Point3D p3D = pointTransf.PointTransf3D(vertex, TM_GCS_LCS);
                            faceSpaceLCS.Vertices.Add(p3D);
                        }
                        Path polygonSpace = GO.CreatePath(faceSpaceLCS, 100000000);

                        foreach (var faceB in e.FacetedBrep.FacetedBrep_Polygon)
                        {
                            if (GO.isCoplanar(faceSpace, faceB, 0.00001, 2.0/ dimensionalScale))
                            {
                                Polyline3D faceBLCS = new Polyline3D();
                                foreach (var vertex in faceB.Vertices)
                                {
                                    Point3D p3D = pointTransf.PointTransf3D(vertex, TM_GCS_LCS);
                                    faceBLCS.Vertices.Add(p3D);
                                }
                                Path polygonfaceB = GO.CreatePath(faceBLCS, 100000000);

                                // 3. Compute the common boundaries
                                Paths solution_com = new Paths();
                                Clipper c = new Clipper();
                                c.AddPath(polygonSpace, PolyType.ptSubject, true);
                                c.AddPath(polygonfaceB, PolyType.ptClip, true);
                                c.Execute(ClipType.ctIntersection, solution_com, PolyFillType.pftEvenOdd, PolyFillType.pftEvenOdd);

                                // 4. Receate the common boundaries into GCS
                                // !!! The Intersection result of two simple polygons will always result in a simple polygon
                                if (solution_com.Count != 0)
                                {
                                    result = true;
                                    return result;
                                }
                            }
                        }
                    }
                }
            }

            return result;
        }

        // !!!! MUST use GLOBALID, as element is extracted by using IFCEngine2019. While SB is extracted using IfcEngine
        private IfcBuildingElement FindExactElement(string GlobalID, List<IfcBuildingElement> Elements)
        {
            IfcBuildingElement result = new IfcBuildingElement();
            foreach (var e in Elements)
            {
                if (e.GlobalID == GlobalID)
                {
                    result = e;
                    break;
                }
            }
            return result;
        }

        private IfcSpace FindExactSpace(string spaceGlobalID, List<IfcSpace> Spaces)
        {
            IfcSpace result = new IfcSpace();
            foreach (var s in Spaces)
            {
                if (s.GlobalID== spaceGlobalID)
                {
                    result = s;
                    break;
                }
            }
            return result;
        }
    }


    // CR.1.6: IF the value of Description is “2a” AND the value of InternalOrExternalBoudary is “INTERNAL”, 
    //         THEN the value of CorrespondingBoundary must be an IfcRelSpaceBoundary2ndLevel instance
    public class CR_1_6_RuleChecking
    {
        public string errorReporting = "CR.1.6: The CorrespondingBoundary of the following SBs should reference a SB instance according to their Description and InternalOrExternalBoudary: ";
        public List<string> failingSBs = new List<string>();
        public bool hasErrors = false;
        public List<string> failingSBs_instanceNames = new List<string>();

        public CR_1_6_RuleChecking(List<IfcRelSpaceBoundary> SBs)
        {
            foreach (var sb in SBs)
            {
                if (sb.Description == "2a" && sb.InternalOrExternalBoundary == InternalOrExternal.INTERNAL)
                    if (sb.CorrespondingBoundaryInstance == 0)
                    {
                        hasErrors = true; 
                        this.failingSBs.Add(sb.InstanceName + " IfcRelSpaceBoundary2ndLevel");
                        failingSBs_instanceNames.Add(sb.InstanceName);
                    }
            }
        }
    }


    // CR.2: IfcRelSpaceBoundary2ndLevel.RelatingSpace/RelatedBuildingElement consistency checking
    // CR.2.1: IF the related element of a SB is not a shading element, THEN the SB must overlap relevant surface of its relating space.
    // CR.2.2: IF the related element of a SB is not a virtual element, THEN the SB must overlap relevant surface of the related element.
    public class CR_2_RuleChecking
    {
        public string errorReporting_1 = "CR.2.1: The following SBs do not connect their relating spaces: ";
        public List<string> failingSBs_eR1 = new List<string>();

        public string errorReporting_2 = "CR.2.2: The following SBs do not connect their related buiding elements: ";
        public List<string> failingSBs_eR2 = new List<string>();

        public bool hasErrors = false;
        public List<string> failingSBs_instanceNames = new List<string>();
        public Dictionary<IfcRelSpaceBoundary, IfcBuildingElement> SB_RelatedElement = new Dictionary<IfcRelSpaceBoundary, IfcBuildingElement>();
        public Dictionary<IfcRelSpaceBoundary, IfcSpace> SB_RelatingSpace = new Dictionary<IfcRelSpaceBoundary, IfcSpace>();


        public CR_2_RuleChecking(Int64 IfcModel, List<IfcRelSpaceBoundary> SBs_SSV_GR1_1, List<IfcBuildingElement> Elements2019, List<IfcSpace> Spaces, float dimensionalScale)
        {
            GeometricOperations GO = new GeometricOperations();
            foreach (var sb in SBs_SSV_GR1_1)
            {
                if (sb.RelatingSpaceType == SpaceType.IfcSpace)  
                {
                    IfcSpace Space = FindSpace(sb.RelatingSpaceGlobalID, Spaces);
                    bool included = false;
                    foreach (var face in Space.FactedBrep.FacetedBrep_Polygon)
                    {
                        if (GO.isIncludedBy(sb.Polygon3D_WCS, face, 0.99, dimensionalScale)/*GO.isOverlapTo(sb.Polygon3D_WCS, face)*/)
                        {
                            included = true;
                            break;
                        }
                    }
                    if (!included)
                    {
                        hasErrors = true;
                        failingSBs_eR1.Add(sb.InstanceName + " IfcRelSpaceBoundary2ndLevel");
                        failingSBs_instanceNames.Add(sb.InstanceName);
                        SB_RelatingSpace.Add(sb, Space);
                    }
                }
                if (sb.RelatedBuildingElementType != BuildingElementType.IfcVirtualElement)
                {
                    //if (sb.InstanceName == "#1000524")
                    //{
                        bool included = false;
                        IfcBuildingElement Element = FindExactElement(sb.RelatedBuildingElementGlobalID, Elements2019);
                        if (Element != null)
                        {
                            foreach (var face in Element.FacetedBrep.FacetedBrep_Polygon)
                            {
                                if (GO.isIncludedBy(sb.Polygon3D_WCS, face, 0.99, dimensionalScale)/*GO.isOverlapTo(sb.Polygon3D_WCS, face)*/)
                                {
                                    included = true;
                                    break;
                                }
                            }
                        }
                        if (!included)
                        {
                            hasErrors = true;
                            failingSBs_eR2.Add(sb.InstanceName + " IfcRelSpaceBoundary2ndLevel");
                            failingSBs_instanceNames.Add(sb.InstanceName);
                            SB_RelatedElement.Add(sb, Element);
                        }
                    //}        
                }
            }
        }

        // !!!! MUST use GLOBALID, as element is extracted by using IFCEngine2019. While SB is extracted using IfcEngine
        private IfcBuildingElement FindExactElement(string id, List<IfcBuildingElement> Elements)
        {
            IfcBuildingElement result = new IfcBuildingElement();
            foreach (var e in Elements)
            {
                if (id == e.GlobalID || id == e.windowdoor_OpeningGlobalID)
                {
                    result = e;
                    break;
                }
            }
            return result;
        }

        private IfcSpace FindSpace(string spaceGlobalID, List<IfcSpace> spaces)
        {
            IfcSpace result = new IfcSpace();
            foreach (var s in spaces)
            {
                if (s.GlobalID == spaceGlobalID)
                {
                    result = s;
                    break;
                }
            }

            return result;
        }
    }


    // CR.3: IfcRelSpaceBoundary2ndLevel.PhysicalOrVirtualBoundary consistency checking
    // CR.3.1: IF the value is “PHYSICAL”, THEN IfcRelSpaceBoundary2ndLevel.RelatedBuildingElement ∉ {IfcVirtualElement, IfcOpeningElement}
    // CR.3.2: IF the value is “VIRTUAL”, THEN IfcRelSpaceBoundary2ndLevel.RelatedBuildingElement ∈ {IfcVirtualElement, IfcOpeningElement}
    public class CR_3_RuleChecking
    {
        public string errorReporting_1 = "CR.3.1: The PhysicalOrVirtualBoundary of the following SBs should be 'VIRTUAL' rather than 'PHYSICAL': ";
        public List<string> failingSBs_eR1 = new List<string>();

        public string errorReporting_2 = "CR.3.2: The PhysicalOrVirtualBoundary of the following SBs should be 'PHYSICAL' rather than 'VIRTUAL': ";
        public List<string> failingSBs_eR2 = new List<string>();

        public bool hasErrors = false;
        public List<string> failingSBs_instanceNames = new List<string>();

        public CR_3_RuleChecking(List<IfcRelSpaceBoundary> SBs)
        {
            foreach (var sb in SBs)
            {
                if (sb.PhysicalOrVirtualBoundary == PhysicalOrVirtual.PHYSICAL)
                {
                    if (sb.RelatedBuildingElementType == BuildingElementType.IfcVirtualElement ||
                        sb.RelatedBuildingElementType == BuildingElementType.IfcOpeningStandardCase)
                    {
                        hasErrors = true;
                        failingSBs_eR1.Add(sb.InstanceName + " IfcRelSpaceBoundary2ndLevel");
                        failingSBs_instanceNames.Add(sb.InstanceName);
                    }
                }
                else
                {
                    if (sb.RelatedBuildingElementType != BuildingElementType.IfcVirtualElement &&
                       sb.RelatedBuildingElementType != BuildingElementType.IfcOpeningStandardCase)
                    {
                        hasErrors = true;
                        failingSBs_eR2.Add(sb.InstanceName + " IfcRelSpaceBoundary2ndLevel");
                        failingSBs_instanceNames.Add(sb.InstanceName);
                    }                      
                }
            }
        }
    }


    // CR.4: IfcRelSpaceBoundary2ndLevel.ParentBoundary consistency checking
    // CR.4.1: IF the value is an SB instance AND IfcRelSpaceBoundary2ndLevel.Description != “Shading”, THEN the SB must be geometrically included by the that SB instance
    // CR.4.2: IF the value is an SB instance AND IfcRelSpaceBoundary2ndLevel.Description = “Shading”, THEN the SB must connect the parent SB instance
    public class CR_4_RuleChecking
    {
        public string errorReporting_1 = "CR.4.1: The following opening SBs are not included by their parent SBs: ";
        public List<string> failingSBs_eR1 = new List<string>();

        public string errorReporting_2 = "CR.4.2: The following shading SBs do not connect their base SBs: ";
        public List<string> failingSBs_eR2 = new List<string>();

        public bool hasErrors = false;
        public List<string> failingSBs_instanceNames = new List<string>();

        public CR_4_RuleChecking(Int64 IfcModel, List<IfcRelSpaceBoundary> SBs_SSV_GR1_1, Dictionary<BuildingElementType, List<Int64>> ElementTypes, List<IfcBuildingElement> Elements_IfcModel2019,  float dimensionalScale)
        {
            GeometricOperations GO = new GeometricOperations();
            Dictionary<IfcRelSpaceBoundary, List<IfcRelSpaceBoundary>> parentSB_shadingSBs = new Dictionary<IfcRelSpaceBoundary, List<IfcRelSpaceBoundary>>();

            // CR.4.1
            foreach (var sb in SBs_SSV_GR1_1)
            {
                if (sb.ParenBoundaryInstance != 0)
                {
                    IfcRelSpaceBoundary parentSB = new IfcRelSpaceBoundary(IfcModel, sb.ParenBoundaryInstance, ElementTypes);
                    if (sb.Description != "Shading")
                    {
                        if (!GO.isIncludedBy(sb.Polygon3D_WCS, parentSB.Polygon3D_WCS, 0.99, dimensionalScale) /*!GO.isOverlapTo(sb.Polygon3D_WCS, parentSB.Polygon3D_WCS)*/)
                        {
                            hasErrors = true;
                            failingSBs_eR1.Add(sb.InstanceName + " IfcRelSpaceBoundary2ndLevel");
                            failingSBs_instanceNames.Add(sb.InstanceName);
                        }
                    }
                    else
                    {
                        IfcRelSpaceBoundary SB = FindExactSB(SBs_SSV_GR1_1, sb.ParenBoundaryInstance);
                        if (parentSB_shadingSBs.ContainsKey(SB))
                        {
                            parentSB_shadingSBs[SB].Add(sb);
                        } else
                        {
                            List<IfcRelSpaceBoundary> set = new List<IfcRelSpaceBoundary>();
                            set.Add(sb);
                            parentSB_shadingSBs.Add(SB, set);
                        }
                    }                      
                }
            }

            // CR.4.2
            foreach (var item in parentSB_shadingSBs)
            {
                if (item.Key.Polygon3D_WCS.Vertices.Count != 0)
                {
                    Point3D A = item.Key.Polygon3D_WCS.Vertices[0];
                    List<Point3D> points = new List<Point3D>();
                    foreach (var sb in item.Value)
                        points.AddRange(sb.Polygon3D_WCS.Vertices);

                    double distmin = 100000000;
                    foreach (var p in points)
                    {
                        Vector3D v = new Vector3D();
                        v = v.VectorConstructor(A, p);
                        double dist = Math.Abs(v.DotProduct(v, item.Key.Polygon3D_WCS.SurfaceNormal));
                        if (distmin > dist)
                            distmin = dist;
                    }

                    IfcBuildingElement element = FindExactElement(item.Key.RelatedBuildingElementGlobalID, Elements_IfcModel2019);
                    double element_thickness = 0;
                    if (element.thickness != 0)
                        element_thickness = element.thickness;
                    else
                        element_thickness = 500;

                    element_thickness = element.thickness / dimensionalScale;
                    if (distmin > element_thickness)
                    {
                        hasErrors = true;
                        foreach (var sb in item.Value)
                        {
                            failingSBs_eR2.Add(sb.InstanceName + " IfcRelSpaceBoundary2ndLevel");
                            failingSBs_instanceNames.Add(sb.InstanceName);
                        }
                    }
                }            
            }          
        }


        // !!!! MUST use GLOBALID, as element is extracted by using IFCEngine2019. While SB is extracted using IfcEngine
        private IfcBuildingElement FindExactElement(string GlobalID, List<IfcBuildingElement> Elements)
        {
            IfcBuildingElement result = new IfcBuildingElement();
            foreach (var e in Elements)
            {
                if (e.GlobalID == GlobalID)
                {
                    result = e;
                    break;
                }
            }
            return result;
        }

        private IfcRelSpaceBoundary FindExactSB (List<IfcRelSpaceBoundary> SBs, Int64 instance)
        {
            IfcRelSpaceBoundary SB = new IfcRelSpaceBoundary();
            foreach (var sb in SBs)
            {
                if (sb.Instance == instance)
                    return sb;                
            }
            return SB;
        }
    }


    // CR.5: IfcRelSpaceBoundary2ndLevel.CorrespondingBoundary consistency checking
    // CR.5.1: IF the value is an SB instance, THEN the SB must correspond to that SB instance
    public class CR_5_RuleChecking
    {
        public string errorReporting = "CR.5: The following pairwsie SBs do not correctly correspond to each other: ";
        public Dictionary<string, string> failingCorrespondingSBs = new Dictionary<string,string>();
        public bool hasErrors = false;
        public List<string> failingSBs_instanceNames = new List<string>();

        public CR_5_RuleChecking(Int64 IfcModel, List<IfcRelSpaceBoundary> SBs_SSV_GR1_1, Dictionary<BuildingElementType, List<Int64>> ElementTypes)
        {
            Dictionary<IfcRelSpaceBoundary, IfcRelSpaceBoundary> PairwiseSBs = new Dictionary<IfcRelSpaceBoundary, IfcRelSpaceBoundary>();
            List<Int64> checkedSBs = new List<Int64>();
            foreach (var sb in SBs_SSV_GR1_1)
            {
                if (sb.CorrespondingBoundaryInstance != 0)
                {
                    if (!exist(sb.Instance, checkedSBs))
                    {
                        IfcRelSpaceBoundary CorrespondingSB = FindSB(sb.CorrespondingBoundaryInstance, SBs_SSV_GR1_1);
                        if (CorrespondingSB != null)  // This condition checking is necessary as the corresponding SB may not exist in SBs_SSV_GR1_1 due to the failing of SSV rules and GR1.1
                        {
                            PairwiseSBs.Add(sb, CorrespondingSB);
                            checkedSBs.Add(sb.Instance);
                            checkedSBs.Add(sb.CorrespondingBoundaryInstance);
                        }                 
                    }
                }                    
            }

            GeometricOperations GO = new GeometricOperations();
            foreach (var item in PairwiseSBs)
            {
                if (!GO.correspondTo(item.Key.Polygon3D_WCS, item.Value.Polygon3D_WCS, 0.9999))
                {
                    hasErrors = true;
                    failingCorrespondingSBs.Add(item.Key.InstanceName + " IfcRelSpaceBoundary2ndLevel", item.Value.InstanceName + " IfcRelSpaceBoundary2ndLevel");
                    failingSBs_instanceNames.Add(item.Key.InstanceName);
                    failingSBs_instanceNames.Add(item.Value.InstanceName);
                }
            }          
        }

        private bool exist (Int64 sb, List<Int64> SBs)
        {
            bool result = false;
            foreach (var item in SBs)
            {
                if (item == sb)
                {
                    result = true;
                    break;
                }
            }
            return result;
        }

        private IfcRelSpaceBoundary FindSB(Int64 instance, List<IfcRelSpaceBoundary> SBs)
        {
            IfcRelSpaceBoundary sb = null;

            foreach (var item in SBs)
            {
                if (item.Instance == instance)
                {
                    sb = item;
                    break;
                }
            }
            return sb;
        }
    }

    #endregion


    #region  Geometric operations

    public class GeometricOperations
    {
        public Point3D OffsetPoint(Point3D p, double offset, Vector3D direction)
        {
            Point3D result = new Point3D();
            result.x = p.x + offset * direction.x;
            result.y = p.y + offset * direction.y;
            result.z = p.z + offset * direction.z;

            return result;
        }

        public bool isParallelOrCoplanar(Polyline3D surfaceA, Polyline3D surfaceB, double ang)
        {
            bool test = false;

            Vector3D vector = new Vector3D();
            Vector3D SA = surfaceA.SurfaceNormal;
            Vector3D SB = surfaceB.SurfaceNormal;

            double d = vector.DotProduct(SA, SB);
            double d1 = Math.Abs(Math.Abs(d) - 1);
            if (d1 < ang) // Coplanar or parallal         
            {
                Point3D p = new Point3D();
                Vector3D AB = new Vector3D();
                test = true;
            }
            return test;
        }

        public bool isParallel(Polyline3D surfaceA, Polyline3D surfaceB, double ang, double dist_mm)
        {
            bool test = false;

            Vector3D vector = new Vector3D();
            Vector3D SA = surfaceA.SurfaceNormal;
            Vector3D SB = surfaceB.SurfaceNormal;

            double d = vector.DotProduct(SA, SB);
            double d1 = Math.Abs(Math.Abs(d) - 1);
            if (d1 < ang) // Coplanar or parallal         
            {
                Point3D p = new Point3D();
                Vector3D AB = new Vector3D();

                if (!p.IsSamePoint(surfaceA.Vertices[0], surfaceB.Vertices[0], 10))
                    AB = vector.VectorConstructor(surfaceA.Vertices[0], surfaceB.Vertices[0]);
                else
                    AB = vector.VectorConstructor(surfaceA.Vertices[0], surfaceB.Vertices[1]);

                double d2 = vector.DotProduct(AB, SA);
                if (Math.Abs(d2) > dist_mm)  // Parallel: 2mm (for two prallal surfaces only)
                    test = true;
            }
            return test;
        }

        // !!!: Tolerance setting: 0.00001/2
        // !!!: The correctness of the normal direction does not affect the result
        public bool isCoplanar(Polyline3D surfaceA, Polyline3D surfaceB, double ang, double dist_mm)
        {
            bool test = false;

            Vector3D vector = new Vector3D();
            Vector3D SA = surfaceA.SurfaceNormal;
            Vector3D SB = surfaceB.SurfaceNormal;

            double d = vector.DotProduct(SA, SB);
            double d1 = Math.Abs(Math.Abs(d) - 1);
            if (d1 < ang) // Coplanar or parallal         
            {
                Point3D p = new Point3D();
                Vector3D AB = new Vector3D();

                if (!p.IsSamePoint(surfaceA.Vertices[0], surfaceB.Vertices[0], 10))
                    AB = vector.VectorConstructor(surfaceA.Vertices[0], surfaceB.Vertices[0]);
                else
                    AB = vector.VectorConstructor(surfaceA.Vertices[0], surfaceB.Vertices[1]);

                double d2 = vector.DotProduct(AB, SA);
                if (Math.Abs(d2) < dist_mm)  // coplanar: 2mm (for two prallal surfaces only)
                    test = true;
            }
            return test;
        }

        // Set LCS for a face
        // Origin: the first vertex of the face
        // X: the first vertex -> the second vertex of the face
        // Z: the surface normal of the face
        //public void LCSSetting(Polyline3D face, ref double[,] TM_LCS_GCS, ref double[,] TM_GCS_LCS)
        //{
        //    Vector3D vector = new Vector3D();
        //    Vector3D xAxis = vector.VectorConstructor(face.Vertices[0], face.Vertices[1]);
        //    xAxis = vector.UnitVector(xAxis);
        //    TM_LCS_GCS = Affine_Matrix(face.Vertices[0], xAxis, face.SurfaceNormal);

        //    InverseMatrix IM = new InverseMatrix();
        //    TM_GCS_LCS = IM.IMatrix_Matrix(TM_LCS_GCS);
        //}

        public void LCSSetting(Polyline3D face, ref double[,] TM_LCS_GCS, ref double[,] TM_GCS_LCS)
        {
            Vector3D vector = new Vector3D();

            Vector3D xAxis = new Vector3D();
            Vector3D zAxis = new Vector3D();
            if (vector.VectorLength(face.SurfaceNormal) == 0)
            {
                face.SurfaceNormal = new Vector3D();
                face.SurfaceNormal = ExtractSurfaceNormal(face);
            }

            if (face.SurfaceNormal.z == 1 || face.SurfaceNormal.z == -1) // directly use GCS
            {
                Point3D origin = new Point3D(0, 0, 0);
                xAxis = vector.NewVector(1, 0, 0);
                zAxis = vector.NewVector(0, 0, 1);
                TM_LCS_GCS = Affine_Matrix(origin, xAxis, zAxis);
            }
            else
            {
                xAxis = vector.UnitVector(vector.VectorConstructor(face.Vertices[0], face.Vertices[1]));
                TM_LCS_GCS = Affine_Matrix(face.Vertices[0], xAxis, face.SurfaceNormal);
            }

            InverseMatrix IM = new InverseMatrix();
            TM_GCS_LCS = IM.IMatrix_Matrix(TM_LCS_GCS);
        }

        private Vector3D ExtractSurfaceNormal(Polyline3D surface)
        {
            Vector3D vector = new Vector3D();

            for (int i = 0; i < surface.Vertices.Count; i++)
            {
                Point3D CP = surface.Vertices[i];
                Point3D NP = surface.Vertices[(i + 1) % surface.Vertices.Count];

                vector.x = vector.x + (CP.y - NP.y) * (CP.z + NP.z);
                vector.y = vector.y + (CP.z - NP.z) * (CP.x + NP.x);
                vector.z = vector.z + (CP.x - NP.x) * (CP.y + NP.y);
            }

            vector = vector.UnitVector(vector);
            return vector;
        }

        // 10^8
        public Path CreatePath(Polyline3D polyline, double scale_point_to_IntPoint)
        {
            Path p = new Path();
            for (int i = 0; i < polyline.Vertices.Count; i++)
            {
                // !!!: (Int64)(x) will directly keep the integer part and ignore the decimal part
                // !!!: We check the third decimal digits: >5 then seond decimal digit +1 and then * 100
                double X = polyline.Vertices[i].x * scale_point_to_IntPoint;
                double Y = polyline.Vertices[i].y * scale_point_to_IntPoint;

                p.Add(new IntPoint((Int64)(X), (Int64)(Y)));
            }
            return p;
        }

        // Create polyline3D from path 
        public Polyline3D CreatePolyline(Path path, double Z, double scale_point_to_IntPoint)
        {
            Polyline3D polyline = new Polyline3D();
            for (int i = 0; i < path.Count; i++)
            {
                Point3D p = new Point3D();
                p.x = path[i].X / scale_point_to_IntPoint;
                p.y = path[i].Y / scale_point_to_IntPoint;
                p.z = Z;
                polyline.Vertices.Add(p);
            }
            return polyline;
        }

        public Coordinate[] CreateRing(Polyline3D poly)
        {
            Coordinate[] result = new Coordinate[poly.Vertices.Count()+1];
            for (int i = 0; i < poly.Vertices.Count; i++)
            {
                Coordinate c = new Coordinate(poly.Vertices[i].x, poly.Vertices[i].y);
                result[i] = c;
            }
            result[poly.Vertices.Count()] = new Coordinate(poly.Vertices[0].x, poly.Vertices[0].y);
            return result;
        }

        public double[,] Affine_Matrix(Point3D Origin, Vector3D _xAxis, Vector3D _zAxis)
        {
            double[,] Rotat_Matrix = Rot_Matrix(_xAxis, _zAxis); // 4* 4
            Rotat_Matrix[0, 3] = Origin.x;
            Rotat_Matrix[1, 3] = Origin.y;
            Rotat_Matrix[2, 3] = Origin.z;

            return Rotat_Matrix;
        }

        // Construct a 4X4 matrix --- for rotation
        public double[,] Rot_Matrix(Vector3D _xAxis, Vector3D _zAxis)
        {
            double[,] Matrix2 = new double[4, 4];
            Matrix2[0, 0] = _xAxis.x;
            Matrix2[1, 0] = _xAxis.y;
            Matrix2[2, 0] = _xAxis.z;
            Matrix2[3, 0] = 0;
            Matrix2[0, 1] = yAxis(_xAxis, _zAxis).x;
            Matrix2[1, 1] = yAxis(_xAxis, _zAxis).y;
            Matrix2[2, 1] = yAxis(_xAxis, _zAxis).z;
            Matrix2[3, 1] = 0;
            Matrix2[0, 2] = _zAxis.x;
            Matrix2[1, 2] = _zAxis.y;
            Matrix2[2, 2] = _zAxis.z;
            Matrix2[3, 2] = 0;
            Matrix2[0, 3] = 0;
            Matrix2[1, 3] = 0;
            Matrix2[2, 3] = 0;
            Matrix2[3, 3] = 1;
            return Matrix2;
        }

        public Vector3D yAxis(Vector3D _xAxis, Vector3D _zAxis)
        {
            Vector3D _yAxis = new Vector3D();

            _yAxis.x = _zAxis.y * _xAxis.z - _xAxis.y * _zAxis.z;
            _yAxis.y = (-1) * (_zAxis.x * _xAxis.z - _xAxis.x * _zAxis.z);
            _yAxis.z = _zAxis.x * _xAxis.y - _xAxis.x * _zAxis.y;

            return _yAxis.UnitVector(_yAxis);
        }

        // include in or located on the boundary
        public bool PointInPolygon(Point3D p, Polyline3D polygon)
        {
            bool result = false;

            Vector3D vector = new Vector3D();

            Point3D p0 = new Point3D();
            if (!p0.IsSamePoint(polygon.Vertices[0], p, 10))
                p0 = polygon.Vertices[0];
            else
                p0 = polygon.Vertices[1];

            Vector3D v = vector.VectorConstructor(p0, p);
            if (Math.Abs(vector.DotProduct(v, polygon.SurfaceNormal)) < 0.00001)
            {
                // 1. Set a LCS for both surfaces
                // Note: This is only for CB extraction and different from CommonBoundary for SB instance creation
                double[,] TM_LCS_GCS = new double[4, 4];
                double[,] TM_GCS_LCS = new double[4, 4];
                LCSSetting(polygon, ref TM_LCS_GCS, ref TM_GCS_LCS);

                // 2. Trasnform polygons into the LCS and project in XY plane of the LCS
                Polyline3D LCS = new Polyline3D();
                PointCoordTransf pointTransf = new PointCoordTransf();
                foreach (var vertex in polygon.Vertices)
                {
                    Point3D p3D = pointTransf.PointTransf3D(vertex, TM_GCS_LCS);
                    LCS.Vertices.Add(p3D);
                }
                Path A = CreatePath(LCS, 100000000);

                Point3D pt = pointTransf.PointTransf3D(p, TM_GCS_LCS);
                IntPoint ptt = new IntPoint((Int64)(Math.Round(pt.x, 2) * 100), (Int64)(Math.Round(pt.y, 2) * 100));
                //IntPoint ptt = new IntPoint((Int64)(pt.x * 100), (Int64)(pt.y * 100));

                Clipper clip = new Clipper();
                int test = clip.PointInPolygon(ptt, A); // returns 0 if false, +1 if true, -1 if pt ON polygon boundary
                if (test == 1 || test == -1)
                    result = true;
            }

            return result;
        }

        // Check whether one 3D polygon is included by the other
        public bool isIncludedBy(Polyline3D surfaceA, Polyline3D surfaceB, double areaDiff, float dimensionalScale)
        {
            bool test = false;
            double dist_mm = 0.00001 / dimensionalScale;
            if (isCoplanar(surfaceA, surfaceB, 0.00001, dist_mm)) 
            {
                // 1. Set a LCS for both surfaces
                // Note: This is only for CB extraction and different from CommonBoundary for SB instance creation
                double[,] TM_LCS_GCS = new double[4, 4];
                double[,] TM_GCS_LCS = new double[4, 4];
                LCSSetting(surfaceB, ref TM_LCS_GCS, ref TM_GCS_LCS);

                // 2. Trasnform polygons into the LCS and project in XY plane of the LCS
                Polyline3D ALCS = new Polyline3D();
                PointCoordTransf pointTransf = new PointCoordTransf();
                foreach (var vertex in surfaceA.Vertices)
                {
                    Point3D p3D = pointTransf.PointTransf3D(vertex, TM_GCS_LCS);
                    ALCS.Vertices.Add(p3D);
                }
                Path A = CreatePath(ALCS, 100000000);
                Coordinate[] ringA = CreateRing(ALCS);
                double areaA = Area.OfRing(ringA);

                Polyline3D BLCS = new Polyline3D();
                foreach (var vertex in surfaceB.Vertices)
                {
                    Point3D p3D = pointTransf.PointTransf3D(vertex, TM_GCS_LCS);
                    BLCS.Vertices.Add(p3D);
                }
                Path B = CreatePath(BLCS, 100000000);

                // 3. Compute the common boundaries
                Paths solution_com = new Paths();
                Clipper c = new Clipper();
                c.AddPath(A, PolyType.ptSubject, true);
                c.AddPath(B, PolyType.ptClip, true);
                c.Execute(ClipType.ctIntersection, solution_com, PolyFillType.pftEvenOdd, PolyFillType.pftEvenOdd);

                if (solution_com.Count != 0)
                {
                    Polyline3D comPoly = CreatePolyline(solution_com[0], 0, 100000000.0); // same to the SB. Math.Round(5)
                    Coordinate[] ringCom = CreateRing(comPoly);
                    double areaCom = Area.OfRing(ringCom);

                    double ratio_com_A = areaCom / areaA;

                    if (ratio_com_A >= areaDiff)
                        test = true;
                }           
            }

            return test;
        }

        // Check whether one 3D polygon is included by the other
        public bool isOverlapTo(Polyline3D surfaceA, Polyline3D surfaceB)
        {
            bool test = false;

            if (isCoplanar(surfaceA, surfaceB, 0.00001, 2))
            {
                // 1. Set a LCS for both surfaces
                // Note: This is only for CB extraction and different from CommonBoundary for SB instance creation
                double[,] TM_LCS_GCS = new double[4, 4];
                double[,] TM_GCS_LCS = new double[4, 4];
                LCSSetting(surfaceB, ref TM_LCS_GCS, ref TM_GCS_LCS);

                // 2. Trasnform polygons into the LCS and project in XY plane of the LCS
                Polyline3D ALCS = new Polyline3D();
                PointCoordTransf pointTransf = new PointCoordTransf();
                foreach (var vertex in surfaceA.Vertices)
                {
                    Point3D p3D = pointTransf.PointTransf3D(vertex, TM_GCS_LCS);
                    ALCS.Vertices.Add(p3D);
                }
                Path A = CreatePath(ALCS, 100000000);  // same to the SB. Math.Round(5)

                Polyline3D BLCS = new Polyline3D();
                foreach (var vertex in surfaceB.Vertices)
                {
                    Point3D p3D = pointTransf.PointTransf3D(vertex, TM_GCS_LCS);
                    BLCS.Vertices.Add(p3D);
                }
                Path B = CreatePath(BLCS, 100000000);

                // 3. Compute the common boundaries
                Paths solution_com = new Paths();
                Clipper c = new Clipper();
                c.AddPath(A, PolyType.ptSubject, true);
                c.AddPath(B, PolyType.ptClip, true);
                c.Execute(ClipType.ctIntersection, solution_com, PolyFillType.pftEvenOdd, PolyFillType.pftEvenOdd);

                if (solution_com.Count != 0)
                    test = true;
            }

            return test;
        }

        // Check whether one 3D polygon is connected to the other
        public bool isConnectedTo(Polyline3D surfaceA, Polyline3D surfaceB)
        {
            bool test = false;
            List<LineSegment3D> edges = new List<LineSegment3D>();
            int num = surfaceA.Vertices.Count();
            for (int i = 0; i < num - 1; i++)
                edges.Add(new LineSegment3D(surfaceA.Vertices[i], surfaceA.Vertices[i + 1]));

            edges.Add(new LineSegment3D(surfaceA.Vertices[num - 1], surfaceA.Vertices[0]));

            foreach (var edge in edges)
            {
                if (PointInPolygon(edge.StartPoint, surfaceB) && PointInPolygon(edge.EndPoint, surfaceB))
                {
                    test = true;
                    break;
                }
            }
            return test;
        }

        // Check whether one polygon can fully overlap with the other after projection
        public bool correspondTo(Polyline3D surfaceA, Polyline3D surfaceB, double areaDiff)
        {
            bool test = false;
           
            // Note: two corresponding SBs can be parallel (physical SBs) or coplanar (virtual SBs)
            // Here either Parallel Or Coplanar is fine as the overlap checking of related building element of each SB will cover the parallel checking 
            if (isParallelOrCoplanar(surfaceA, surfaceB, 0.0001))
            {
                // 1. Set a LCS for both surfaces
                // Note: This is only for CB extraction and different from CommonBoundary for SB instance creation
                double[,] TM_LCS_GCS = new double[4, 4];
                double[,] TM_GCS_LCS = new double[4, 4];
                LCSSetting(surfaceA, ref TM_LCS_GCS, ref TM_GCS_LCS);

                // 2. Trasnform polygons into the LCS and project in XY plane of the LCS
                Polyline3D ALCS = new Polyline3D();
                PointCoordTransf pointTransf = new PointCoordTransf();
                foreach (var vertex in surfaceA.Vertices)
                {
                    Point3D p3D = pointTransf.PointTransf3D(vertex, TM_GCS_LCS);
                    ALCS.Vertices.Add(p3D);
                }
                Path A = CreatePath(ALCS, 100000000);
                Coordinate[] ringA = CreateRing(ALCS);
                double areaA = Area.OfRing(ringA);

                Polyline3D BLCS = new Polyline3D();
                foreach (var vertex in surfaceB.Vertices)
                {
                    Point3D p3D = pointTransf.PointTransf3D(vertex, TM_GCS_LCS);
                    BLCS.Vertices.Add(p3D);
                }
                Path B = CreatePath(BLCS, 100000000);
                Coordinate[] ringB = CreateRing(BLCS);
                double areaB = Area.OfRing(ringB);

                // 3. Compute the common boundaries
                Paths solution_com = new Paths();
                Clipper c = new Clipper();
                c.AddPath(A, PolyType.ptSubject, true);
                c.AddPath(B, PolyType.ptClip, true);
                c.Execute(ClipType.ctIntersection, solution_com, PolyFillType.pftEvenOdd, PolyFillType.pftEvenOdd);
                if (solution_com.Count != 0)
                {
                    Polyline3D comPoly = CreatePolyline(solution_com[0], 0, 100000000.0);
                    Coordinate[] ringCom = CreateRing(comPoly);
                    double areaCom = Area.OfRing(ringCom);

                    double ratio_com_A = areaCom / areaA;
                    double ratio_com_B = areaCom / areaB;

                    if (ratio_com_A >= areaDiff && ratio_com_B >= areaDiff)
                        test = true;
                }
                    
                #region Old implementation that cannot consider tolerance

                //Paths solution_com1 = new Paths();
                //Clipper c1 = new Clipper();
                //c1.AddPath(A, PolyType.ptSubject, true);
                //c1.AddPaths(solution_com, PolyType.ptClip, true);
                //c1.Execute(ClipType.ctDifference, solution_com1, PolyFillType.pftEvenOdd, PolyFillType.pftEvenOdd);

                //Paths solution_com2 = new Paths();
                //Clipper c2 = new Clipper();
                //c2.AddPath(B, PolyType.ptSubject, true);
                //c2.AddPaths(solution_com, PolyType.ptClip, true);
                //c2.Execute(ClipType.ctDifference, solution_com2, PolyFillType.pftEvenOdd, PolyFillType.pftEvenOdd);

                //if (solution_com1.Count == 0 && solution_com2.Count == 0)
                //    test = true;

                #endregion
            }
                   
            return test;
        }
  
        public bool PointInAABBTest(Point3D p, BoundingBox3D AABB)
        {
            bool result = false;

            if (p.x <= AABB.xmax && p.x >= AABB.xmin)
            {
                if (p.y <= AABB.ymax && p.y >= AABB.ymin)
                {
                    if (p.z <= AABB.zmax && p.z >= AABB.zmin)
                    {
                        result = true;
                    }
                }
            }

            return result;
        }

        // Ray-casting point-in-polyhedron test algorithm: Odd-even rule: Based on Jordan curve theorem     
        public bool PointInPolyhedronTest(Point3D point, Vector3D direction, List<List<Triangle3D>> Polyhedron)
        {
            bool Result = false;

            // Intersection points are located on the edges shared by two triangle surfaces: Remove same intersection points
            List<Point3D> points = new List<Point3D>();
            foreach (var face in Polyhedron)
            {
                foreach (var triangle in face)
                {
                    Ray3D ray = new Ray3D();
                    ray.StartPoint = point;
                    ray.Direction = direction;
                    Ray3D_Triangle3D_do_Intersection test = new Ray3D_Triangle3D_do_Intersection(ray, triangle);
                    if (test.Intersection)
                    {
                        if (points.Count == 0)
                            points.Add(test.IntersectionPoint);
                        else
                        {
                            bool repeat = false;
                            for (int j = 0; j < points.Count; j++)
                            {
                                Point3D p = new Point3D();
                                if (p.IsSamePoint(points[j], test.IntersectionPoint, 10))
                                {
                                    repeat = true;
                                    break;
                                }
                            }
                            if (!repeat)
                                points.Add(test.IntersectionPoint);
                        }
                        break;
                    }
                }
            }

            if (points.Count % 2 == 1)
                Result = true;

            return Result;
        }

        public bool PointInFacetedBrep (Point3D p, Vector3D direction, IfcFacetedBrep Brep)
        {
            bool result = false;

            if (PointInAABBTest(p, Brep.AABB))
            {
                if (PointInPolyhedronTest(p, direction, Brep.FacetedBrep_TriangleGroupedbyFace))
                    result = true;
            }

            return result;
        }

        public bool Polyhedron_Polyhedron_ConnectionTest(IfcFacetedBrep Brep_A, IfcFacetedBrep Brep_B)
        {
            bool result = false;
            bool test = AABB_AABB_IntersectionTest(Brep_A.AABB,Brep_B.AABB);
            if (test)
            {
                foreach (var faceA in Brep_A.FacetedBrep_Polygon)
                {
                    // 1. Set a LCS for both surfaces
                    // Note: This is only for CB extraction and different from CommonBoundary for SB instance creation
                    double[,] TM_LCS_GCS = new double[4, 4];
                    double[,] TM_GCS_LCS = new double[4, 4];
                    LCSSetting(faceA, ref TM_LCS_GCS, ref TM_GCS_LCS);

                    // 2. Trasnform faces into the LCS and project in XY plane of the LCS
                    Polyline3D LCSA = new Polyline3D();
                    PointCoordTransf pointTransf = new PointCoordTransf();
                    foreach (var vertex in faceA.Vertices)
                    {
                        Point3D p3D = pointTransf.PointTransf3D(vertex, TM_GCS_LCS);
                        LCSA.Vertices.Add(p3D);
                    }

                    Path polygonA = CreatePath(LCSA, 100000000);
                    double z_LCS = LCSA.Vertices[0].z;

                    foreach (var faceB in Brep_B.FacetedBrep_Polygon)
                    {
                        if (isCoplanar(faceA, faceB, 0.00001, 2))
                        {
                            Polyline3D faceBLCS = new Polyline3D();
                            foreach (var vertex in faceB.Vertices)
                            {
                                Point3D p3D = pointTransf.PointTransf3D(vertex, TM_GCS_LCS);
                                faceBLCS.Vertices.Add(p3D);
                            }
                            Path polygonfaceB = CreatePath(faceBLCS, 100000000);

                            // 3. Compute the common boundaries
                            Paths solution_com = new Paths();
                            Clipper c = new Clipper();
                            c.AddPath(polygonA, PolyType.ptSubject, true);
                            c.AddPath(polygonfaceB, PolyType.ptClip, true);
                            c.Execute(ClipType.ctIntersection, solution_com, PolyFillType.pftEvenOdd, PolyFillType.pftEvenOdd);

                            if (solution_com.Count != 0)
                            {
                                result = true;
                                return result;
                            }
                        }
                    }
                }
            }
            return result;                 
        }

        public bool AABB_AABB_IntersectionTest(BoundingBox3D A, BoundingBox3D B)
        {
            if (A.xmax <= B.xmin || A.xmin >= B.xmax)
                return false;
            if (A.ymax <= B.ymin || A.ymin >= B.ymax)
                return false;
            if (A.zmax <= B.zmin || A.zmin >= B.zmax)
                return false;
            return true;
        }

        // !!! Intersections accur at the vertex/ednpoint of the edges are ignored
        public bool LS_LSsIntersection(LineSegment edge, List<LineSegment> edges)
        {
            bool result = false;
            foreach (var item in edges)
            {
                Vector p = new Vector();
                Vector p2 = new Vector();
                p.X = edge.StartPoint.x;
                p.Y = edge.StartPoint.y;
                p2.X = edge.EndPoint.x;
                p2.Y = edge.EndPoint.y;

                Vector q = new Vector();
                Vector q2= new Vector();
                q.X = item.StartPoint.x;
                q.Y = item.StartPoint.y;
                q2.X = item.EndPoint.x;
                q2.Y = item.EndPoint.y;

                Point2D intersection = new Point2D();
                bool CollinearIntersect;
                bool intersect = LineSegmentIntersect(p, p2, q, q2, out intersection, out CollinearIntersect);
                if (intersect)   
                {    
                    if (CollinearIntersect) // further check whether there exist on intersection occurs at the endpoints of relevant LSs
                    {
                        if (Math.Abs(edge.StartPoint.x-edge.EndPoint.x) > 0.00001)
                        {
                            double edge_xmin = edge.StartPoint.x;
                            double edge_xmax = edge.StartPoint.x;
                            if (edge_xmin > edge.EndPoint.x)
                                edge_xmin = edge.EndPoint.x;
                            else
                                edge_xmax = edge.EndPoint.x;

                            double item_xmin = item.StartPoint.x;
                            double item_xmax = item.StartPoint.x;
                            if (item_xmin > item.EndPoint.x)
                                item_xmin = item.EndPoint.x;
                            else
                                item_xmax = item.EndPoint.x;

                            if (Math.Abs(edge_xmin - item_xmax) > 0.00001 && Math.Abs(item_xmin - edge_xmax) > 0.00001)
                            {
                                result = true;
                                break;
                            }
                        }
                        else
                        {
                            double edge_ymin = edge.StartPoint.y;
                            double edge_ymax = edge.StartPoint.y;
                            if (edge_ymin > edge.EndPoint.y)
                                edge_ymin = edge.EndPoint.y;
                            else
                                edge_ymax = edge.EndPoint.y;

                            double item_ymin = item.StartPoint.y;
                            double item_ymax = item.StartPoint.y;
                            if (item_ymin > item.EndPoint.y)
                                item_ymin = item.EndPoint.y;
                            else
                                item_ymax = item.EndPoint.y;

                            if (Math.Abs(edge_ymin - item_ymax) > 0.00001 && Math.Abs(item_ymin - edge_ymax) > 0.00001)
                            {
                                result = true;
                                break;
                            }
                        }

                    }
                    else  // further check whether the intersection occurs at the endpoints of relevant LSs
                    {
                        if (!intersection.SamePoint(intersection, edge.StartPoint) &&
                            !intersection.SamePoint(intersection, edge.EndPoint) &&
                            !intersection.SamePoint(intersection, item.StartPoint) &&
                            !intersection.SamePoint(intersection, item.EndPoint))
                        {
                            result = true;
                            break;
                        }
                    }                  
                }
            }
            return result;
        }

        /// Test whether two line segments intersect. If so, calculate the intersection point.
        /// Code from https://www.codeproject.com/Tips/862988/Find-the-Intersection-Point-of-Two-Line-Segments    
        public bool LineSegmentIntersect(Vector p, Vector p2, Vector q, Vector q2, out Point2D intersection, out bool CollinearIntersect, bool considerCollinearOverlapAsIntersect = true)
        {
            intersection = new Point2D();
            CollinearIntersect = false;

            var r = p2 - p;
            var s = q2 - q;
            var rxs = r.Cross(s);
            var qpxr = (q - p).Cross(r);

            // If r x s = 0 and (q - p) x r = 0, then the two lines are collinear.
            if (rxs.IsZero() && qpxr.IsZero())
            {
                // 1. If either  0 <= (q - p) * r <= r * r or 0 <= (p - q) * s <= * s
                // then the two lines are overlapping,
                if (considerCollinearOverlapAsIntersect)
                    if ((0 <= (q - p) * r && (q - p) * r <= r * r) || (0 <= (p - q) * s && (p - q) * s <= s * s))
                    {
                        CollinearIntersect = true;
                        return true;
                    }

                // 2. If neither 0 <= (q - p) * r = r * r nor 0 <= (p - q) * s <= s * s
                // then the two lines are collinear but disjoint.
                // No need to implement this expression, as it follows from the expression above.
                return false;
            }

            // 3. If r x s = 0 and (q - p) x r != 0, then the two lines are parallel and non-intersecting.
            if (rxs.IsZero() && !qpxr.IsZero())
                return false;

            // t = (q - p) x s / (r x s)
            var t = (q - p).Cross(s) / rxs;

            // u = (q - p) x r / (r x s)

            var u = (q - p).Cross(r) / rxs;

            // 4. If r x s != 0 and 0 <= t <= 1 and 0 <= u <= 1
            // the two line segments meet at the point p + t r = q + u s.
            if (!rxs.IsZero() && (0 <= t && t <= 1) && (0 <= u && u <= 1))
            {
                // We can calculate the intersection point using either t or u.
                Vector IP = p + t * r;

                intersection.x = IP.X;
                intersection.y = IP.Y;

                // An intersection was found.
                return true;
            }

            // 5. Otherwise, the two line segments are not parallel but do not intersect.
            return false;
        }
    }


    public class Vector
    {
        public double X;
        public double Y;

        // Constructors.
        public Vector(double x, double y) { X = x; Y = y; }
        public Vector() : this(double.NaN, double.NaN) { }

        public static Vector operator -(Vector v, Vector w)
        {
            return new Vector(v.X - w.X, v.Y - w.Y);
        }

        public static Vector operator +(Vector v, Vector w)
        {
            return new Vector(v.X + w.X, v.Y + w.Y);
        }

        public static double operator *(Vector v, Vector w)
        {
            return v.X * w.X + v.Y * w.Y;
        }

        public static Vector operator *(Vector v, double mult)
        {
            return new Vector(v.X * mult, v.Y * mult);
        }

        public static Vector operator *(double mult, Vector v)
        {
            return new Vector(v.X * mult, v.Y * mult);
        }

        public double Cross(Vector v)
        {
            return X * v.Y - Y * v.X;
        }

        public override bool Equals(object obj)
        {
            var v = (Vector)obj;
            return (X - v.X).IsZero() && (Y - v.Y).IsZero();
        }
    }

    public static class Extensions
    {
        private const double Epsilon = 1e-10;

        public static bool IsZero(this double d)
        {
            return Math.Abs(d) < Epsilon;
        }
    }

    public class ValidIntersection
    {
        public bool result = false;
        public string explanation;
    }

    public class RayTSBIntersection
    {
        public string SBGlobalID;
        public string SBInstanceName;
        public Vector3D SBSurfaceNormal = new Vector3D();
        public Point3D IntersectionPoint = new Point3D();
        public double Distance = 0;
    }

    public class AABB_TriangulatedSB_Tree
    {
        public AABB_TriangulatedSB_TreeNode RootNode = new AABB_TriangulatedSB_TreeNode();

        public AABB_TriangulatedSB_Tree(List<TriangulatedSpaceBoundary> TriangulatedSBs, int MaxDepth)
        {
            // 1. create root node
            List<Triangle3D> triangles = new List<Triangle3D>();
            foreach (TriangulatedSpaceBoundary TSB in TriangulatedSBs)
                triangles.Add(TSB.TriangulatedSBSpace);
            BoundingBox3D RootBox = new BoundingBox3D(triangles);

            List<AABB_TriangulatedSB_TreeNode> TreeNodes = new List<AABB_TriangulatedSB_TreeNode>();
            RootNode.AABB = RootBox;
            RootNode.Depth = 1;
            RootNode.TriangulatedSBs = TriangulatedSBs; // This will be reset to null when it is spilt 
            TreeNodes.Add(RootNode);

            // 2. add the children node          
            bool DoSpilt = true;
            while (DoSpilt)
            {
                DoSpilt = false;
                for (int i = 0; i < TreeNodes.Count; i++) // Cannot use foreach as TreeNodes is dynamic
                {
                    if (TreeNodes[i].LeftChildren == null && TreeNodes[i].RightChildren == null) // MUS be kept
                    {
                        if (TreeNodes[i].Depth < MaxDepth)  // Terminal condition 1
                        {
                            if (TreeNodes[i].TriangulatedSBs.Count > 2) // Terminal condition 2 (after spilt, the TriangulatedSBs is set to null) (when NUM == 2 this node is not necessary to be spilt as they probaly come from a common SB which means they actually will be not spilt in spilt.())
                            {
                                if (TreeNodes[i].Split())
                                {
                                    if (TreeNodes[i].LeftChildren != null)
                                        TreeNodes.Add(TreeNodes[i].LeftChildren);
                                    if (TreeNodes[i].RightChildren != null)
                                        TreeNodes.Add(TreeNodes[i].RightChildren);
                                    DoSpilt = true;
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    public class AABB_TriangulatedSB_TreeNode
    {
        public BoundingBox3D AABB = null;
        public List<TriangulatedSpaceBoundary> TriangulatedSBs = new List<TriangulatedSpaceBoundary>(); // for leaf nodes only
        public int Depth = 0;
        public AABB_TriangulatedSB_TreeNode LeftChildren = null;
        public AABB_TriangulatedSB_TreeNode RightChildren = null;

        public bool Split()
        {
            if (this.LeftChildren != null || this.RightChildren != null)
                return false;

            // select the spilt axis
            spiltPlane spilt = new spiltPlane();
            double Axisx = AABB.xmax - AABB.xmin;
            double Axisy = AABB.ymax - AABB.ymin;
            double Axisz = AABB.zmax - AABB.zmin;

            if (Axisx > Axisy)
            {
                if (Axisx > Axisz)
                    spilt = spiltPlane.xAxis;
                else
                    spilt = spiltPlane.zAxis;
            }
            else
            {
                if (Axisz > Axisy)
                    spilt = spiltPlane.zAxis;
                else
                    spilt = spiltPlane.yAxis;
            }

            // create the left and right children: left--> smaller; right --> bigger
            List<TriangulatedSpaceBoundary> TriangulatedSBs_Left = new List<TriangulatedSpaceBoundary>();
            List<TriangulatedSpaceBoundary> TriangulatedSBs_Right = new List<TriangulatedSpaceBoundary>();
            if (spilt == spiltPlane.xAxis)
            {
                double spiltlocation = Axisx / 2.0 + AABB.xmin;
                ClassifyTriangulatedSBs(this.TriangulatedSBs, spilt, spiltlocation, ref TriangulatedSBs_Left, ref TriangulatedSBs_Right);
            }
            if (spilt == spiltPlane.yAxis)
            {
                double spiltlocation = Axisy / 2.0 + AABB.ymin;
                ClassifyTriangulatedSBs(this.TriangulatedSBs, spilt, spiltlocation, ref TriangulatedSBs_Left, ref TriangulatedSBs_Right);
            }

            if (spilt == spiltPlane.zAxis)
            {
                double spiltlocation = Axisz / 2.0 + AABB.zmin;
                ClassifyTriangulatedSBs(this.TriangulatedSBs, spilt, spiltlocation, ref TriangulatedSBs_Left, ref TriangulatedSBs_Right);
            }

            if (TriangulatedSBs_Left.Count == 0 || TriangulatedSBs_Right.Count == 0) // !!! if any children node is empty, this mode MUST not be spilt as the child is same to the parent. 
                return false;
            else
            {
                this.LeftChildren = new AABB_TriangulatedSB_TreeNode(); // Null-->Initilaization 
                this.LeftChildren.AABB = CreateAABB(TriangulatedSBs_Left);
                this.LeftChildren.Depth = this.Depth + 1;
                this.LeftChildren.TriangulatedSBs = TriangulatedSBs_Left;

                this.RightChildren = new AABB_TriangulatedSB_TreeNode(); // Null-->Initilaization 
                this.RightChildren.AABB = CreateAABB(TriangulatedSBs_Right);
                this.RightChildren.Depth = this.Depth + 1;
                this.RightChildren.TriangulatedSBs = TriangulatedSBs_Right;

                this.TriangulatedSBs = null; // only leaf nodes reserve the TSBs (once spilt, set empty)
                return true;  // spilt successfully 
            }
        }

        // left--> smaller; right --> bigger
        private void ClassifyTriangulatedSBs(List<TriangulatedSpaceBoundary> TSBs, spiltPlane spilt, double spiltlocation, ref List<TriangulatedSpaceBoundary> TSBs_left, ref List<TriangulatedSpaceBoundary> TSBs_right)
        {
            if (TSBs.Count != 0)
            {
                foreach (var TSB in TSBs)
                {
                    double mid = 0;
                    switch (spilt)
                    {
                        case spiltPlane.xAxis:
                            mid = MiddleLocation(TSB.TriangulatedSBSpace.Vertex1.x, TSB.TriangulatedSBSpace.Vertex2.x, TSB.TriangulatedSBSpace.Vertex3.x);
                            if (mid < spiltlocation)
                                TSBs_left.Add(TSB);
                            else
                                TSBs_right.Add(TSB);
                            break;
                        case spiltPlane.yAxis:
                            mid = MiddleLocation(TSB.TriangulatedSBSpace.Vertex1.y, TSB.TriangulatedSBSpace.Vertex2.y, TSB.TriangulatedSBSpace.Vertex3.y);
                            if (mid < spiltlocation)
                                TSBs_left.Add(TSB);
                            else
                                TSBs_right.Add(TSB);
                            break;
                        case spiltPlane.zAxis:
                            mid = MiddleLocation(TSB.TriangulatedSBSpace.Vertex1.z, TSB.TriangulatedSBSpace.Vertex2.z, TSB.TriangulatedSBSpace.Vertex3.z);
                            if (mid < spiltlocation)
                                TSBs_left.Add(TSB);
                            else
                                TSBs_right.Add(TSB);
                            break;
                    }
                }
            }
        }

        private double MiddleLocation(double a, double b, double c)
        {
            List<double> list = new List<double>();
            list.Add(a);
            list.Add(b);
            list.Add(c);

            double max = list.Max();
            double min = list.Min();
            double Mid = min + (max - min) / 2.0;

            return Mid;
        }

        private BoundingBox3D CreateAABB(List<TriangulatedSpaceBoundary> TSBs)
        {
            List<Triangle3D> triangles = new List<Triangle3D>();
            foreach (TriangulatedSpaceBoundary TSB in TSBs)
                triangles.Add(TSB.TriangulatedSBSpace);

            BoundingBox3D AABB = new BoundingBox3D(triangles);
            return AABB;
        }

        public List<AABB_TriangulatedSB_TreeNode> AABBTreeTraversing(Ray3D ray)
        {
            List<AABB_TriangulatedSB_TreeNode> LeafNodes = new List<AABB_TriangulatedSB_TreeNode>();

            Ray3D_AABB_do_Intersection Ray_AABB_Intersect = new Ray3D_AABB_do_Intersection();
            bool Intersection = Ray_AABB_Intersect.Test(ray, this.AABB);

            if (Intersection)
            {
                if ((this.LeftChildren == null) && (this.RightChildren == null))
                    LeafNodes.Add(this);
                else
                {
                    if (this.LeftChildren != null)
                    {
                        List<AABB_TriangulatedSB_TreeNode> LeftNodes = this.LeftChildren.AABBTreeTraversing(ray);
                        for (int i = 0; i < LeftNodes.Count; i++)
                            LeafNodes.Add(LeftNodes[i]);
                    }
                    if (this.RightChildren != null)
                    {
                        List<AABB_TriangulatedSB_TreeNode> RightNodes = this.RightChildren.AABBTreeTraversing(ray);
                        for (int j = 0; j < RightNodes.Count; j++)
                            LeafNodes.Add(RightNodes[j]);
                    }
                }
            }
            return LeafNodes;
        }
    }

    enum spiltPlane
    {
        xAxis,
        yAxis,
        zAxis
    }

    #endregion
}
