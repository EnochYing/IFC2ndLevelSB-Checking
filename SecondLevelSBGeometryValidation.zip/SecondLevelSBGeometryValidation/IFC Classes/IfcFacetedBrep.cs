﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecondLevelSBValidation
{
    public class IfcFacetedBrep
    {
        public List<List<Triangle3D>> FacetedBrep_TriangleGroupedbyFace = new List<List<Triangle3D>>(); // Note: !!! The extact surface normal (this is correct!!!) may be not consistent with the orders of the vertices of triangles

        public List<Triangle3D> FacetedBrep_Triangles = new List<Triangle3D>();
        public List<Polyline3D> FacetedBrep_Polygon = new List<Polyline3D>();
        public double[,] TM_GCS_LCS = new double[4, 4];  // Generated in specific element/spaces that need this attributes
        public BoundingBox3D AABB = new BoundingBox3D();  // for spatial indexing use

        // !!!: IFCEngine will take into consideration of the openings (directly create holes) when processing wall's geometry
        // !!!: Extract opening instances first; then delete for geometry extraction; finally rewrite for downstream processing
        public IfcFacetedBrep(Int64 IfcModel, Int64 ObjectInstance)
        {
            SetFormat(IfcModel);
            Int64 noVertices = 0;   // Number of the vertices
            Int64 noIndices = 0;    // Number of the indices

            Vector3D V = new Vector3D();

            IfcEngine.initializeModellingInstance(IfcModel, ref noVertices, ref noIndices, 0, ObjectInstance);
            if ((noVertices == 0) || (noIndices == 0))
                return;

            float[] vertexArray = new float[noVertices * 6];  //  array used for storing real vertices coordinates + surface normal

            // !!! each value represent the index of a vertex in vertexArray; three consecutive values represent three vertices of a triangle. 
            // As long as the strat index for a triangle is konwn the triangle is known. 
            // To define a face consisting several triangles, as along as the start index and the number of indexes for the face(Num_triangle = its value/3 ) are known, all triangles of the face can be inferred.
            Int32[] indexArray = new Int32[noIndices];

            IfcEngine.finalizeModelling(IfcModel, vertexArray, indexArray, 0);    // fill the actual data into relevant array

            Int64 iFacesCount = IfcEngine.getConceptualFaceCnt(ObjectInstance); //planar surfaces; not the triangulated surfaces
            if (iFacesCount != 0)
            {
                for (Int64 iFace = 0; iFace < iFacesCount; iFace++)
                {
                    Int64 iStartIndexTriangles = 0;  // start index of the triangles of the face
                    Int64 iIndicesCountTriangles = 0; // number of index of triangles of the face
                    Int64 iStartIndexFacesPolygons = 0;
                    Int64 iIndicesCountFacesPolygons = 0;

                    //Int64 iStartIndexLines = 0;
                    //Int64 iIndicesCountLines = 0;
                    //Int64 iStartIndexPoints = 0;
                    //Int64 iIndicesCountPoints = 0;
                    //Int64 startIndexConceptualFacePolygons = 0;
                    //Int64 noIndicesConceptualFacePolygons = 0;

                    // Note: Must ensure that relevant setting for relevant information is open in SetFormat 
                    Int64 iValue = 0;
                    IfcEngine.getConceptualFaceEx(ObjectInstance,
                        iFace,
                        ref iStartIndexTriangles,    // triangle
                        ref iIndicesCountTriangles,  // triangle
                        ref iValue,  //line: iStartIndexLines 
                        ref iValue,  //line: iIndicesCountLines
                        ref iValue,  //point: iStartIndexPoints
                        ref iValue, // point: iIndicesCountPoints
                        ref iStartIndexFacesPolygons,  // start index face polygon
                        ref iIndicesCountFacesPolygons, // number of index face polygon
                        ref iValue,  // (startIndexConceptualFacePolygons) start index conceptual face polygon --- approximation 
                        ref iValue); // (noIndicesConceptualFacePolygons) number of index conceptual face polygon --- approximation 

                    #region FacetedBrep_TriangleGroupedbyFace && FacetedBrep_Triangles

                    List<int> lsTriangleFaceIndices = new List<int>(); // indices of vertices of triangles belonging to a face
                    for (Int64 iIndexTriangles = iStartIndexTriangles; iIndexTriangles < iStartIndexTriangles + iIndicesCountTriangles; iIndexTriangles++)
                    {
                        lsTriangleFaceIndices.Add(indexArray[iIndexTriangles]);
                    }

                    List<Triangle3D> FaceTriangles = new List<Triangle3D>();
                    Int64 NumTriangles_Face = lsTriangleFaceIndices.Count / 3;
                    for (int itriangle = 0; itriangle < NumTriangles_Face; itriangle++)
                    {
                        Triangle3D triangle = new Triangle3D();
                        // vertex 1
                        triangle.Vertex1.x = vertexArray[lsTriangleFaceIndices[itriangle * 3 + 0] * 6 + 0];
                        triangle.Vertex1.y = vertexArray[lsTriangleFaceIndices[itriangle * 3 + 0] * 6 + 1];
                        triangle.Vertex1.z = vertexArray[lsTriangleFaceIndices[itriangle * 3 + 0] * 6 + 2];

                        // vertex 2
                        triangle.Vertex2.x = vertexArray[lsTriangleFaceIndices[itriangle * 3 + 1] * 6 + 0];
                        triangle.Vertex2.y = vertexArray[lsTriangleFaceIndices[itriangle * 3 + 1] * 6 + 1];
                        triangle.Vertex2.z = vertexArray[lsTriangleFaceIndices[itriangle * 3 + 1] * 6 + 2];

                        // vertex 3
                        triangle.Vertex3.x = vertexArray[lsTriangleFaceIndices[itriangle * 3 + 2] * 6 + 0];
                        triangle.Vertex3.y = vertexArray[lsTriangleFaceIndices[itriangle * 3 + 2] * 6 + 1];
                        triangle.Vertex3.z = vertexArray[lsTriangleFaceIndices[itriangle * 3 + 2] * 6 + 2];

                        // normal 
                        // Be careful: the surface nomal produced by IfcEngine is correct for the 3D solid (pointing outside) 
                        // but is not consistent to that computed based on the produced triangle using right-hand rule
                        triangle.NormalVector.x = vertexArray[lsTriangleFaceIndices[itriangle * 3 + 0] * 6 + 3];
                        triangle.NormalVector.y = vertexArray[lsTriangleFaceIndices[itriangle * 3 + 0] * 6 + 4];
                        triangle.NormalVector.z = vertexArray[lsTriangleFaceIndices[itriangle * 3 + 0] * 6 + 5];
                        triangle.NormalVector = V.UnitVector(triangle.NormalVector);

                        FaceTriangles.Add(triangle);
                        this.FacetedBrep_Triangles.Add(triangle);
                    }
                    this.FacetedBrep_TriangleGroupedbyFace.Add(FaceTriangles);

                    #endregion

                    #region FacetedBrep_Polygon
                    // Note: ??? how the indexes are origanized???
                    int iIndexWireframes = 0;
                    int iLastIndex = -1;
                    List<int> lsWireframesIndices = new List<int>(); // indexes of vertices of lines belonging to this face: a rectangle have 4 lines including 8 vertices(0-1;1-2;2-3;3-0) 
                    while (iIndexWireframes < iIndicesCountFacesPolygons)
                    {
                        if ((iLastIndex >= 0) && (indexArray[iStartIndexFacesPolygons + iIndexWireframes] >= 0))
                        {
                            lsWireframesIndices.Add(iLastIndex);
                            lsWireframesIndices.Add(indexArray[iStartIndexFacesPolygons + iIndexWireframes]);
                        }
                        iLastIndex = indexArray[iStartIndexFacesPolygons + iIndexWireframes];
                        iIndexWireframes++;
                    }

                    // ??? How about a face with holes ???
                    // !!! The following represents a face without holes
                    int noLines = lsWireframesIndices.Count / 2;
                    Polyline3D FacePolygon = new Polyline3D();
                    FacePolygon.SurfaceNormal.x = vertexArray[lsWireframesIndices[0] * 6 + 3];
                    FacePolygon.SurfaceNormal.y = vertexArray[lsWireframesIndices[0] * 6 + 4];
                    FacePolygon.SurfaceNormal.z = vertexArray[lsWireframesIndices[0] * 6 + 5];
                    FacePolygon.SurfaceNormal = V.UnitVector(FacePolygon.SurfaceNormal);
                    for (int iLine = 0; iLine < noLines; iLine++)
                    {
                        Point3D Vertex = new Point3D();
                        Vertex.x = vertexArray[lsWireframesIndices[iLine * 2] * 6 + 0];
                        Vertex.y = vertexArray[lsWireframesIndices[iLine * 2] * 6 + 1];
                        Vertex.z = vertexArray[lsWireframesIndices[iLine * 2] * 6 + 2];
                        FacePolygon.Vertices.Add(Vertex);
                    }
                    this.FacetedBrep_Polygon.Add(FacePolygon);
                    #endregion
                }
            }

            #region AABB

            if (this.FacetedBrep_Polygon.Count != 0)
                this.AABB = new BoundingBox3D().BoundingBox3D_Polygons_Create(this.FacetedBrep_Polygon);

            #endregion
        }

        public IfcFacetedBrep(Int64 IfcModel, Int64 ObjectInstance, string ifcengine2019)
        {
            SetFormat(IfcModel, ifcengine2019);
            Int64 noVertices = 0;   // Number of the vertices
            Int64 noIndices = 0;    // Number of the indices

            Vector3D V = new Vector3D();

            IfcEngine2019.initializeModellingInstance(IfcModel, ref noVertices, ref noIndices, 0, ObjectInstance);
            if ((noVertices == 0) || (noIndices == 0))
                return;

            float[] vertexArray = new float[noVertices * 6];  //  array used for storing real vertices coordinates + surface normal

            // !!! each value represent the index of a vertex in vertexArray; three consecutive values represent three vertices of a triangle. 
            // As long as the strat index for a triangle is konwn the triangle is known. 
            // To define a face consisting several triangles, as along as the start index and the number of indexes for the face(Num_triangle = its value/3 ) are known, all triangles of the face can be inferred.
            Int32[] indexArray = new Int32[noIndices];

            IfcEngine2019.finalizeModelling(IfcModel, vertexArray, indexArray, 0);    // fill the actual data into relevant array

            Int64 iFacesCount = IfcEngine2019.getConceptualFaceCnt(ObjectInstance); //planar surfaces; not the triangulated surfaces
            if (iFacesCount != 0)
            {
                for (Int64 iFace = 0; iFace < iFacesCount; iFace++)
                {
                    Int64 iStartIndexTriangles = 0;  // start index of the triangles of the face
                    Int64 iIndicesCountTriangles = 0; // number of index of triangles of the face
                    Int64 iStartIndexFacesPolygons = 0;
                    Int64 iIndicesCountFacesPolygons = 0;

                    //Int64 iStartIndexLines = 0;
                    //Int64 iIndicesCountLines = 0;
                    //Int64 iStartIndexPoints = 0;
                    //Int64 iIndicesCountPoints = 0;
                    //Int64 startIndexConceptualFacePolygons = 0;
                    //Int64 noIndicesConceptualFacePolygons = 0;

                    // Note: Must ensure that relevant setting for relevant information is open in SetFormat 
                    Int64 iValue = 0;
                    IfcEngine2019.getConceptualFaceEx(ObjectInstance,
                        iFace,
                        ref iStartIndexTriangles,    // triangle
                        ref iIndicesCountTriangles,  // triangle
                        ref iValue,  //line: iStartIndexLines 
                        ref iValue,  //line: iIndicesCountLines
                        ref iValue,  //point: iStartIndexPoints
                        ref iValue, // point: iIndicesCountPoints
                        ref iStartIndexFacesPolygons,  // start index face polygon
                        ref iIndicesCountFacesPolygons, // number of index face polygon
                        ref iValue,  // (startIndexConceptualFacePolygons) start index conceptual face polygon --- approximation 
                        ref iValue); // (noIndicesConceptualFacePolygons) number of index conceptual face polygon --- approximation 

                    #region FacetedBrep_TriangleGroupedbyFace && FacetedBrep_Triangles

                    List<int> lsTriangleFaceIndices = new List<int>(); // indices of vertices of triangles belonging to a face
                    for (Int64 iIndexTriangles = iStartIndexTriangles; iIndexTriangles < iStartIndexTriangles + iIndicesCountTriangles; iIndexTriangles++)
                    {
                        lsTriangleFaceIndices.Add(indexArray[iIndexTriangles]);
                    }

                    List<Triangle3D> FaceTriangles = new List<Triangle3D>();
                    Int64 NumTriangles_Face = lsTriangleFaceIndices.Count / 3;
                    for (int itriangle = 0; itriangle < NumTriangles_Face; itriangle++)
                    {
                        Triangle3D triangle = new Triangle3D();
                        // vertex 1
                        triangle.Vertex1.x = vertexArray[lsTriangleFaceIndices[itriangle * 3 + 0] * 6 + 0];
                        triangle.Vertex1.y = vertexArray[lsTriangleFaceIndices[itriangle * 3 + 0] * 6 + 1];
                        triangle.Vertex1.z = vertexArray[lsTriangleFaceIndices[itriangle * 3 + 0] * 6 + 2];

                        // vertex 2
                        triangle.Vertex2.x = vertexArray[lsTriangleFaceIndices[itriangle * 3 + 1] * 6 + 0];
                        triangle.Vertex2.y = vertexArray[lsTriangleFaceIndices[itriangle * 3 + 1] * 6 + 1];
                        triangle.Vertex2.z = vertexArray[lsTriangleFaceIndices[itriangle * 3 + 1] * 6 + 2];

                        // vertex 3
                        triangle.Vertex3.x = vertexArray[lsTriangleFaceIndices[itriangle * 3 + 2] * 6 + 0];
                        triangle.Vertex3.y = vertexArray[lsTriangleFaceIndices[itriangle * 3 + 2] * 6 + 1];
                        triangle.Vertex3.z = vertexArray[lsTriangleFaceIndices[itriangle * 3 + 2] * 6 + 2];

                        // normal 
                        // Be careful: the surface nomal produced by IfcEngine is correct for the 3D solid (pointing outside) 
                        // but is not consistent to that computed based on the produced triangle using right-hand rule
                        triangle.NormalVector.x = vertexArray[lsTriangleFaceIndices[itriangle * 3 + 0] * 6 + 3];
                        triangle.NormalVector.y = vertexArray[lsTriangleFaceIndices[itriangle * 3 + 0] * 6 + 4];
                        triangle.NormalVector.z = vertexArray[lsTriangleFaceIndices[itriangle * 3 + 0] * 6 + 5];
                        triangle.NormalVector = V.UnitVector(triangle.NormalVector);

                        FaceTriangles.Add(triangle);
                        this.FacetedBrep_Triangles.Add(triangle);
                    }
                    this.FacetedBrep_TriangleGroupedbyFace.Add(FaceTriangles);

                    #endregion

                    #region FacetedBrep_Polygon
                    // Note: ??? how the indexes are origanized???
                    int iIndexWireframes = 0;
                    int iLastIndex = -1;
                    List<int> lsWireframesIndices = new List<int>(); // indexes of vertices of lines belonging to this face: a rectangle have 4 lines including 8 vertices(0-1;1-2;2-3;3-0) 
                    while (iIndexWireframes < iIndicesCountFacesPolygons)
                    {
                        if ((iLastIndex >= 0) && (indexArray[iStartIndexFacesPolygons + iIndexWireframes] >= 0))
                        {
                            lsWireframesIndices.Add(iLastIndex);
                            lsWireframesIndices.Add(indexArray[iStartIndexFacesPolygons + iIndexWireframes]);
                        }
                        iLastIndex = indexArray[iStartIndexFacesPolygons + iIndexWireframes];
                        iIndexWireframes++;
                    }

                    // ??? How about a face with holes ???
                    // !!! The following represents a face without holes
                    int noLines = lsWireframesIndices.Count / 2;
                    Polyline3D FacePolygon = new Polyline3D();
                    FacePolygon.SurfaceNormal.x = vertexArray[lsWireframesIndices[0] * 6 + 3];
                    FacePolygon.SurfaceNormal.y = vertexArray[lsWireframesIndices[0] * 6 + 4];
                    FacePolygon.SurfaceNormal.z = vertexArray[lsWireframesIndices[0] * 6 + 5];
                    FacePolygon.SurfaceNormal = V.UnitVector(FacePolygon.SurfaceNormal);
                    for (int iLine = 0; iLine < noLines; iLine++)
                    {
                        Point3D Vertex = new Point3D();
                        Vertex.x = vertexArray[lsWireframesIndices[iLine * 2] * 6 + 0];
                        Vertex.y = vertexArray[lsWireframesIndices[iLine * 2] * 6 + 1];
                        Vertex.z = vertexArray[lsWireframesIndices[iLine * 2] * 6 + 2];
                        FacePolygon.Vertices.Add(Vertex);
                    }
                    this.FacetedBrep_Polygon.Add(FacePolygon);
                    #endregion
                }
            }

            #region AABB

            if (this.FacetedBrep_Polygon.Count != 0)
                this.AABB = new BoundingBox3D().BoundingBox3D_Polygons_Create(this.FacetedBrep_Polygon);

            #endregion
        }

        public IfcFacetedBrep()
        {

        }

        private void SetFormat(Int64 IfcModel)
        {
            Int64 setting = 0, mask = 0;
            mask += IfcEngine.flagbit2;          //    PRECISION (32/64 bit)
            mask += IfcEngine.flagbit3;          //    INDEX ARRAY (32/64 bit)
            mask += IfcEngine.flagbit5;          //    NORMALS
            mask += IfcEngine.flagbit8;          //    TRIANGLES
            mask += IfcEngine.flagbit12;         //    WIREFRAME

            setting += 0;                        //    SINGLE PRECISION (float)
            setting += 0;                        //    32 BIT INDEX ARRAY (Int32)
            setting += IfcEngine.flagbit5;       //    NORMALS ON
            setting += IfcEngine.flagbit8;       //    TRIANGLES ON
            //setting += IfcEngine2019.flagbit9;       //    LINES ON
            //setting += IfcEngine2019.flagbit10;      //    POINTS ON
            setting += IfcEngine.flagbit12;      //    WIREFRAME ON --- for face polygon use

            IfcEngine.setFormat(IfcModel, setting, mask);
        }

        private void SetFormat(Int64 IfcModel, string ifcengine2019)
        {
            Int64 setting = 0, mask = 0;
            mask += IfcEngine2019.flagbit2;          //    PRECISION (32/64 bit)
            mask += IfcEngine2019.flagbit3;          //    INDEX ARRAY (32/64 bit)
            mask += IfcEngine2019.flagbit5;          //    NORMALS
            mask += IfcEngine2019.flagbit8;          //    TRIANGLES
            mask += IfcEngine2019.flagbit12;         //    WIREFRAME

            setting += 0;                        //    SINGLE PRECISION (float)
            setting += 0;                        //    32 BIT INDEX ARRAY (Int32)
            setting += IfcEngine2019.flagbit5;       //    NORMALS ON
            setting += IfcEngine2019.flagbit8;       //    TRIANGLES ON
            //setting += IfcEngine2019.flagbit9;       //    LINES ON
            //setting += IfcEngine2019.flagbit10;      //    POINTS ON
            setting += IfcEngine2019.flagbit12;      //    WIREFRAME ON --- for face polygon use

            IfcEngine2019.setFormat(IfcModel, setting, mask);
        }
    }
}
