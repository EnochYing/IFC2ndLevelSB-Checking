﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MathNet.Numerics.LinearAlgebra.Double;
using MathNet.Numerics.LinearAlgebra;

namespace SecondLevelSBValidation
{
    public class AffineTranslation
    {
        // construct a 4X4 matrix --- for translation --- matrix multiplication
        public double[,] TMatrix(Point3D _Location)
        {
            double[,] Matrix1 = new double[4, 4];
            Matrix1[0, 0] = 1;
            Matrix1[1, 0] = 0;
            Matrix1[2, 0] = 0;
            Matrix1[3, 0] = 0;
            Matrix1[0, 1] = 0;
            Matrix1[1, 1] = 1;
            Matrix1[2, 1] = 0;
            Matrix1[3, 1] = 0;
            Matrix1[0, 2] = 0;
            Matrix1[1, 2] = 0;
            Matrix1[2, 2] = 1;
            Matrix1[3, 2] = 0;
            Matrix1[0, 3] = _Location.x;
            Matrix1[1, 3] = _Location.y;
            Matrix1[2, 3] = _Location.z;
            Matrix1[3, 3] = 1;
            return Matrix1;
        }

    }

    public class AffineRotation
    {
        // construct a 4X4 matrix --- for rotation
        public double[,] RMatrix(Vector3D _xAxis, Vector3D _zAxis)
        {
            double[,] Matrix2 = new double[4, 4];
            Matrix2[0, 0] = _xAxis.x;
            Matrix2[1, 0] = _xAxis.y;
            Matrix2[2, 0] = _xAxis.z;
            Matrix2[3, 0] = 0;
            Matrix2[0, 1] = yAxis(_xAxis, _zAxis).x;
            Matrix2[1, 1] = yAxis(_xAxis, _zAxis).y;
            Matrix2[2, 1] = yAxis(_xAxis, _zAxis).z;
            Matrix2[3, 1] = 0;
            Matrix2[0, 2] = _zAxis.x;
            Matrix2[1, 2] = _zAxis.y;
            Matrix2[2, 2] = _zAxis.z;
            Matrix2[3, 2] = 0;
            Matrix2[0, 3] = 0;
            Matrix2[1, 3] = 0;
            Matrix2[2, 3] = 0;
            Matrix2[3, 3] = 1;
            return Matrix2;
        }

        // calculate the unit vector that represents the direction of yAxis
        // calculate a unit vector that is perpendicular to two existing vectors according to right hand rule using cross product 
        public Vector3D yAxis(Vector3D _xAxis, Vector3D _zAxis)
        {
            Vector3D _yAxis = new Vector3D();
            double x = 0;
            double y = 0;
            double z = 0;
            double d = 0;
            // when computing the cross product(k * i = |k| X |i| X sina X j)-- is not Dot Product, the z axis should be the second row. This ensures that the output of yaxis comply the right hand rule.
            x = _zAxis.y * _xAxis.z - _xAxis.y * _zAxis.z;
            y = (-1) * (_zAxis.x * _xAxis.z - _xAxis.x * _zAxis.z);
            z = _zAxis.x * _xAxis.y - _xAxis.x * _zAxis.y;
            d = Math.Sqrt(x * x + y * y + z * z);
            _yAxis.x = x / d;
            _yAxis.y = y / d;
            _yAxis.z = z / d;
            return _yAxis;
        }
    }

    public class AffineTR
    {
        // Transformation matrix calculation using Axis2Placement3D directly
        public double[,] TRMatrix(Point3D _Location, Vector3D _xAxis, Vector3D _zAxis)
        {
            AffineRotation B = new AffineRotation();
            double[,] RM = B.RMatrix(_xAxis, _zAxis);
            RM[0, 3] = _Location.x;
            RM[1, 3] = _Location.y;
            RM[2, 3] = _Location.z;

            return RM;

            #region Time consuming
            //double[,] TM = new double[4, 4];
            //double[,] RM = new double[4, 4];
            //double[,] Matrix3 = new double[4, 4];
            //AffineTranslation A = new AffineTranslation();
            //AffineRotation B = new AffineRotation();
            //TM = A.TMatrix(_Location);
            //RM = B.RMatrix(_xAxis, _zAxis);

            //for (int i = 0; i < 4; i++)
            //{
            //    for (int j = 0; j < 4; j++)
            //    {
            //        for (int k = 0; k < 4; k++)
            //        {
            //            Matrix3[i, j] = Matrix3[i, j] + TM[i, k] * RM[k, j];
            //        }
            //    }
            //}

            //return Matrix3;
            #endregion
        }
    }

    public class AffineTR2
    {
        // Transformation matrix calculation using T*R
        public double[,] TRMatrix(double[,] A, double[,] B)
        {      
            double[,] MatrixC = new double[4, 4];

            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    for (int k = 0; k < 4; k++)
                    {
                        MatrixC[i, j] = MatrixC[i, j] + A[i, k] * B[k, j];
                    }
                }
            }

            return MatrixC;
        }
    }

    public class InverseMatrix
    {
        public double[,] IMatrix_Matrix(double[,] input)
        {
            Matrix<double> A = DenseMatrix.OfArray(input);
            Matrix<double> Inverse_A = A.Inverse();

            double[,] output = Inverse_A.ToArray();

            return output;
        }

        // Not robust
        public double[,] IMatrix(double[,] MatrixC)
        {
            int row = MatrixC.GetLength(0);
            int rank = MatrixC.GetLength(1);
            if (row != rank)    // MatrixC must be a squar matrix
            {
                return null;
            }

            double[,] Matrix4 = new double[row, rank];
            double[,] Matrixa = new double[row, rank];

            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < rank; j++)
                {
                    Matrixa[i, j] = MatrixC[i, j];
                }
            }

            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < rank; j++)
                {
                    if (i == j) { Matrix4[i, j] = 1; }
                    else { Matrix4[i, j] = 0; }
                }
            }

            for (int j = 0; j < rank; j++)
            {
                bool flag = false;
                for (int i = j; i < row; i++)
                {
                    if (Matrixa[i, j] != 0)
                    {
                        flag = true;
                        double temp;
                        if (i != j)
                        {
                            for (int k = 0; k < row; k++)
                            {
                                temp = Matrixa[j, k];
                                Matrixa[j, k] = Matrixa[i, k];
                                Matrixa[i, k] = temp;

                                temp = Matrix4[j, k];
                                Matrix4[j, k] = Matrix4[i, k];
                                Matrix4[i, k] = temp;
                            }
                        }
                        double d = Matrixa[j, j];
                        for (int k = 0; k < row; k++)
                        {
                            Matrixa[j, k] = Matrixa[j, k] / d;
                            Matrix4[j, k] = Matrix4[j, k] / d;
                        }
                        d = Matrixa[j, j];
                        for (int k = 0; k < row; k++)
                        {
                            if (k != j)
                            {
                                double t = Matrixa[k, j];
                                for (int n = 0; n < row; n++)
                                {
                                    Matrixa[k, n] -= (t / d) * Matrixa[j, n];
                                    Matrix4[k, n] -= (t / d) * Matrix4[j, n];
                                }
                            }
                        }
                    }

                }
                if (!flag) return null;
            }
            return Matrix4;
        }
    }

    public class PointCoordTransf
    {
        // calculate the cartesian point coordinates after transformation
        public Point3D PointTransf3D(Point3D _Point3D, double[,] TRMatrix)
        {
            Point3D PointAfterTransf = new Point3D ();
            PointAfterTransf.x = TRMatrix[0, 0] * _Point3D.x + TRMatrix[0, 1] * _Point3D.y + TRMatrix[0, 2] * _Point3D.z + TRMatrix[0, 3];
            PointAfterTransf.y = TRMatrix[1, 0] * _Point3D.x + TRMatrix[1, 1] * _Point3D.y + TRMatrix[1, 2] * _Point3D.z + TRMatrix[1, 3];
            PointAfterTransf.z = TRMatrix[2, 0] * _Point3D.x + TRMatrix[2, 1] * _Point3D.y + TRMatrix[2, 2] * _Point3D.z + TRMatrix[2, 3];
            return PointAfterTransf;
        }

        public Point3D PointTransf2D(Point2D _Point2D, double[,] TRMatrix)
        {
            Point3D PointAfterTransf = new Point3D();
            PointAfterTransf.x = TRMatrix[0, 0] * _Point2D.x + TRMatrix[0, 1] * _Point2D.y + TRMatrix[0, 3];
            PointAfterTransf.y = TRMatrix[1, 0] * _Point2D.x + TRMatrix[1, 1] * _Point2D.y + TRMatrix[1, 3];
            PointAfterTransf.z = TRMatrix[2, 0] * _Point2D.x + TRMatrix[2, 1] * _Point2D.y + TRMatrix[2, 3];
            return PointAfterTransf;
        }    
    }

    public class SurfaceNormalTransfer
    {
        public Vector3D SurfaceNormalTransf(Vector3D SurfaceNormal, double[,] TRMatrix)
        {
        Vector3D _Vector3D = new Vector3D();
        Point3D LCSOrigin = new Point3D();
        LCSOrigin.x = 0;
        LCSOrigin.y = 0;
        LCSOrigin.z = 0;

        Point3D _SurfaceNormal = new Point3D();
        _SurfaceNormal.x = SurfaceNormal.x;
        _SurfaceNormal.y = SurfaceNormal.y;
        _SurfaceNormal.z = SurfaceNormal.z;

        PointCoordTransf _PointTransfer = new PointCoordTransf();
        Point3D LCSOriginTransfer = new Point3D();
        Point3D _SurfaceNormalTransfer = new Point3D();
        LCSOriginTransfer = _PointTransfer.PointTransf3D(LCSOrigin, TRMatrix);
        _SurfaceNormalTransfer = _PointTransfer.PointTransf3D(_SurfaceNormal, TRMatrix);

        _Vector3D.x = _SurfaceNormalTransfer.x - LCSOriginTransfer.x;
        _Vector3D.y = _SurfaceNormalTransfer.y - LCSOriginTransfer.y;
        _Vector3D.z = _SurfaceNormalTransfer.z - LCSOriginTransfer.z;

        _Vector3D = _Vector3D.UnitVector(_Vector3D);
        return _Vector3D;
        }
    }
    
}
