﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using ClipperLib_WithoutStatic;

namespace SecondLevelSBValidation
{
    public class IfcSpace
    {
        public Int64 Instance = 0;
        public string InstanceName;
        public string GlobalID;
        public string Name;

        public IfcFacetedBrep FactedBrep = null;  // Not the original representation form (for polyhedron, this reflects actual geometry); 
                                                                // for curved geometry, this is approximated representation: the underlying triangulation method need to be analyzed and how the curved geometry is processed.
        public List<IfcRelSpaceBoundary> RelatedSBs = new List<IfcRelSpaceBoundary>(); // All relevant SBs
        public List<TriangulatedSpaceBoundary> RelatedNonOpeningTSBs_InSpace = new List<TriangulatedSpaceBoundary>(); // Exclude SBs of openings 
        public List<IfcRelSpaceBoundary> RelatedNonOpeningSBs = new List<IfcRelSpaceBoundary>();

        public IfcSpace()
        {

        }
        public IfcSpace(Int64 IfcModel, Int64 spaceInstance, Dictionary<string, List<IfcRelSpaceBoundary>> space_SBs)
        {
            this.Instance = spaceInstance;

            Int64 instanceName = IfcEngine.internalGetP21Line(spaceInstance);
            this.InstanceName = "#" + instanceName.ToString();

            // GlobalID 
            IntPtr GlobalIdPtr = IntPtr.Zero;
            IfcEngine.sdaiGetAttrBN(spaceInstance, "GlobalId", IfcEngine.sdaiUNICODE, out GlobalIdPtr);
            this.GlobalID = Marshal.PtrToStringUni(GlobalIdPtr);

            // Name
            IntPtr NamePtr = IntPtr.Zero;
            IfcEngine.sdaiGetAttrBN(spaceInstance, "Name", IfcEngine.sdaiUNICODE, out NamePtr);
            this.Name = Marshal.PtrToStringUni(NamePtr);

            // Brep 
            this.FactedBrep = new IfcFacetedBrep(IfcModel, spaceInstance);

            // Related SBs/triangulated SBs in the LCS of Space
            this.RelatedSBs = space_SBs[this.GlobalID];

            foreach (var sb in this.RelatedSBs)
            {
                if (sb.RelatedBuildingElementType != BuildingElementType.IfcWindowStandardCase && sb.RelatedBuildingElementType != BuildingElementType.IfcDoorStandardCase
                    && sb.RelatedBuildingElementType != BuildingElementType.IfcOpeningStandardCase)
                {
                    foreach (var tsb in sb.TriangulatedSB_InSpace)
                    {
                        TriangulatedSpaceBoundary TSB = new TriangulatedSpaceBoundary();
                        TSB.SBGlobalID = sb.GlobalID;
                        TSB.SBInstanceName = sb.InstanceName;
                        TSB.TriangulatedSBSpace = tsb;
                        this.RelatedNonOpeningTSBs_InSpace.Add(TSB);
                    }
                    this.RelatedNonOpeningSBs.Add(sb);
                }           
            }
        }

        public IfcSpace(Int64 IfcModel, Int64 spaceInstance)
        {
            this.Instance = spaceInstance;

            Int64 instanceName = IfcEngine.internalGetP21Line(spaceInstance);
            this.InstanceName = "#" + instanceName.ToString();

            // GlobalID 
            IntPtr GlobalIdPtr = IntPtr.Zero;
            IfcEngine.sdaiGetAttrBN(spaceInstance, "GlobalId", IfcEngine.sdaiUNICODE, out GlobalIdPtr);
            this.GlobalID = Marshal.PtrToStringUni(GlobalIdPtr);

            // Name
            IntPtr NamePtr = IntPtr.Zero;
            IfcEngine.sdaiGetAttrBN(spaceInstance, "Name", IfcEngine.sdaiUNICODE, out NamePtr);
            this.Name = Marshal.PtrToStringUni(NamePtr);

            // Brep 
            this.FactedBrep = new IfcFacetedBrep(IfcModel, spaceInstance);
         
            foreach (var sb in this.RelatedSBs)
            {
                if (sb.RelatedBuildingElementType != BuildingElementType.IfcWindowStandardCase && sb.RelatedBuildingElementType != BuildingElementType.IfcDoorStandardCase
                    && sb.RelatedBuildingElementType != BuildingElementType.IfcOpeningStandardCase)
                {
                    foreach (var tsb in sb.TriangulatedSB_InSpace)
                    {
                        TriangulatedSpaceBoundary TSB = new TriangulatedSpaceBoundary();
                        TSB.SBGlobalID = sb.GlobalID;
                        TSB.SBInstanceName = sb.InstanceName;
                        TSB.TriangulatedSBSpace = tsb;
                        this.RelatedNonOpeningTSBs_InSpace.Add(TSB);
                    }
                }
            }
        }
    }

    public class TriangulatedSpaceBoundary
    {
        public string SBGlobalID;
        public string SBInstanceName;
        public Triangle3D TriangulatedSBSpace = new Triangle3D();
    }

}
