﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecondLevelSBValidation
{ 
    public class Coplanar_Triangle_Triangle_do_Intersection
    {
        public bool Result = false;

        //// Coplanar case ca be treated as 2D   
        //public Coplanar_Triangle_Triangle_do_Intersection(Triangle3D triA, Triangle3D triB)
        //{        
        //    List<Point3D> VerticesA = new List<Point3D>();
        //    VerticesA.Add(triA.Vertex1);
        //    VerticesA.Add(triA.Vertex2);
        //    VerticesA.Add(triA.Vertex3);

        //    // 1. check if vertices of triange A is located in triangle B
        //    for (int i = 0; i < VerticesA.Count; i++ )
        //    {
        //        Coplanar_Point_In_Triangle PTtest = new Coplanar_Point_In_Triangle(VerticesA[i], triB);
        //        if (PTtest.Result)
        //        {
        //            Result = true;
        //            return;
        //        }
        //    }

        //    // 2. check if vertices of triange B is located in triangle A
        //    List<Point3D> VerticesB = new List<Point3D>();
        //    VerticesB.Add(triB.Vertex1);
        //    VerticesB.Add(triB.Vertex2);
        //    VerticesB.Add(triB.Vertex3);

        //    for (int i = 0; i < VerticesB.Count; i++)
        //    {
        //        Coplanar_Point_In_Triangle PTtest = new Coplanar_Point_In_Triangle(VerticesB[i], triA);
        //        if (PTtest.Result)
        //        {
        //            Result = true;
        //            return;
        //        }
        //    }

        //    // 3. check if a edge of a triangle intersect any edge of the other triangle 

        //}
    }
}
