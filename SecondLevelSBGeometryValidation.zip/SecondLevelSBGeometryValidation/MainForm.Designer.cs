﻿namespace SecondLevelSBValidation
{
    partial class SecondLevelSBValidation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SecondLevelSBValidation));
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("-> SR.0: IfcCartesianPoint checking ");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("-> SR.1: SB attribute value checking ");
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("-> SR.2: SB existence checking ");
            System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode("-> SR.3: Openings\' SBs checking");
            System.Windows.Forms.TreeNode treeNode5 = new System.Windows.Forms.TreeNode("-> SR.4: Aggregate elements\' SBs checking");
            System.Windows.Forms.TreeNode treeNode6 = new System.Windows.Forms.TreeNode("-> SR: Syntactic and semantic rules", new System.Windows.Forms.TreeNode[] {
            treeNode1,
            treeNode2,
            treeNode3,
            treeNode4,
            treeNode5});
            System.Windows.Forms.TreeNode treeNode7 = new System.Windows.Forms.TreeNode("-> GR.1: SB geometric representation checking");
            System.Windows.Forms.TreeNode treeNode8 = new System.Windows.Forms.TreeNode("-> GR.2: Space airtightness checking");
            System.Windows.Forms.TreeNode treeNode9 = new System.Windows.Forms.TreeNode("-> GR: Geometric rules", new System.Windows.Forms.TreeNode[] {
            treeNode7,
            treeNode8});
            System.Windows.Forms.TreeNode treeNode10 = new System.Windows.Forms.TreeNode("-> CR.1: Description/InternalOrExternalBoundary chekcing ");
            System.Windows.Forms.TreeNode treeNode11 = new System.Windows.Forms.TreeNode("-> CR.2: RelatingSpace/RelatedBuildingElement checking");
            System.Windows.Forms.TreeNode treeNode12 = new System.Windows.Forms.TreeNode("-> CR.3: PhysicalOrVirtualBoundary checking");
            System.Windows.Forms.TreeNode treeNode13 = new System.Windows.Forms.TreeNode("-> CR.4: ParentBoundary checking ");
            System.Windows.Forms.TreeNode treeNode14 = new System.Windows.Forms.TreeNode("-> CR.5: CorrespondingBoundary checking ");
            System.Windows.Forms.TreeNode treeNode15 = new System.Windows.Forms.TreeNode("-> CR: Consistency rules", new System.Windows.Forms.TreeNode[] {
            treeNode10,
            treeNode11,
            treeNode12,
            treeNode13,
            treeNode14});
            System.Windows.Forms.TreeNode treeNode16 = new System.Windows.Forms.TreeNode("->Validation rules", new System.Windows.Forms.TreeNode[] {
            treeNode6,
            treeNode9,
            treeNode15});
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.checkingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sSVToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gVToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cVToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.wireframeModelToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.surfaceModelToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.resetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.splitContainer_Visualization = new System.Windows.Forms.SplitContainer();
            this.splitContainer_IfcTree = new System.Windows.Forms.SplitContainer();
            this.IfcSBTree = new System.Windows.Forms.TreeView();
            this.treeIcons = new System.Windows.Forms.ImageList(this.components);
            this.splitContainer_Checking = new System.Windows.Forms.SplitContainer();
            this.treeView_CheckingRules = new System.Windows.Forms.TreeView();
            this.splitContainer_ResultReporting = new System.Windows.Forms.SplitContainer();
            this.textBox_RuleDescription = new System.Windows.Forms.TextBox();
            this.treeView_ResultReporting = new System.Windows.Forms.TreeView();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer_Visualization)).BeginInit();
            this.splitContainer_Visualization.Panel1.SuspendLayout();
            this.splitContainer_Visualization.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer_IfcTree)).BeginInit();
            this.splitContainer_IfcTree.Panel1.SuspendLayout();
            this.splitContainer_IfcTree.Panel2.SuspendLayout();
            this.splitContainer_IfcTree.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer_Checking)).BeginInit();
            this.splitContainer_Checking.Panel1.SuspendLayout();
            this.splitContainer_Checking.Panel2.SuspendLayout();
            this.splitContainer_Checking.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer_ResultReporting)).BeginInit();
            this.splitContainer_ResultReporting.Panel1.SuspendLayout();
            this.splitContainer_ResultReporting.Panel2.SuspendLayout();
            this.splitContainer_ResultReporting.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.checkingToolStripMenuItem,
            this.viewToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1114, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripMenuItem,
            this.exiToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(44, 24);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(120, 26);
            this.openToolStripMenuItem.Text = "Open";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
            // 
            // exiToolStripMenuItem
            // 
            this.exiToolStripMenuItem.Name = "exiToolStripMenuItem";
            this.exiToolStripMenuItem.Size = new System.Drawing.Size(120, 26);
            this.exiToolStripMenuItem.Text = "Exit";
            this.exiToolStripMenuItem.Click += new System.EventHandler(this.exiToolStripMenuItem_Click);
            // 
            // checkingToolStripMenuItem
            // 
            this.checkingToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sSVToolStripMenuItem,
            this.gVToolStripMenuItem,
            this.cVToolStripMenuItem});
            this.checkingToolStripMenuItem.Name = "checkingToolStripMenuItem";
            this.checkingToolStripMenuItem.Size = new System.Drawing.Size(88, 24);
            this.checkingToolStripMenuItem.Text = "Validation";
            // 
            // sSVToolStripMenuItem
            // 
            this.sSVToolStripMenuItem.Name = "sSVToolStripMenuItem";
            this.sSVToolStripMenuItem.Size = new System.Drawing.Size(305, 26);
            this.sSVToolStripMenuItem.Text = "Syntactic and semantic validation";
            this.sSVToolStripMenuItem.Click += new System.EventHandler(this.sSVToolStripMenuItem_Click);
            // 
            // gVToolStripMenuItem
            // 
            this.gVToolStripMenuItem.Name = "gVToolStripMenuItem";
            this.gVToolStripMenuItem.Size = new System.Drawing.Size(305, 26);
            this.gVToolStripMenuItem.Text = "Geometric validation";
            this.gVToolStripMenuItem.Click += new System.EventHandler(this.gVToolStripMenuItem_Click);
            // 
            // cVToolStripMenuItem
            // 
            this.cVToolStripMenuItem.Name = "cVToolStripMenuItem";
            this.cVToolStripMenuItem.Size = new System.Drawing.Size(305, 26);
            this.cVToolStripMenuItem.Text = "Consistency validation";
            this.cVToolStripMenuItem.Click += new System.EventHandler(this.cVToolStripMenuItem_Click);
            // 
            // viewToolStripMenuItem
            // 
            this.viewToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.wireframeModelToolStripMenuItem,
            this.surfaceModelToolStripMenuItem,
            this.resetToolStripMenuItem});
            this.viewToolStripMenuItem.Name = "viewToolStripMenuItem";
            this.viewToolStripMenuItem.Size = new System.Drawing.Size(53, 24);
            this.viewToolStripMenuItem.Text = "View";
            // 
            // wireframeModelToolStripMenuItem
            // 
            this.wireframeModelToolStripMenuItem.Checked = true;
            this.wireframeModelToolStripMenuItem.CheckOnClick = true;
            this.wireframeModelToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.wireframeModelToolStripMenuItem.Name = "wireframeModelToolStripMenuItem";
            this.wireframeModelToolStripMenuItem.Size = new System.Drawing.Size(201, 26);
            this.wireframeModelToolStripMenuItem.Text = "Wireframe Model";
            this.wireframeModelToolStripMenuItem.Click += new System.EventHandler(this.wireframeModelToolStripMenuItem_Click);
            // 
            // surfaceModelToolStripMenuItem
            // 
            this.surfaceModelToolStripMenuItem.Checked = true;
            this.surfaceModelToolStripMenuItem.CheckOnClick = true;
            this.surfaceModelToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.surfaceModelToolStripMenuItem.Name = "surfaceModelToolStripMenuItem";
            this.surfaceModelToolStripMenuItem.Size = new System.Drawing.Size(201, 26);
            this.surfaceModelToolStripMenuItem.Text = "Surface Model";
            this.surfaceModelToolStripMenuItem.Click += new System.EventHandler(this.surfaceModelToolStripMenuItem_Click);
            // 
            // resetToolStripMenuItem
            // 
            this.resetToolStripMenuItem.Name = "resetToolStripMenuItem";
            this.resetToolStripMenuItem.Size = new System.Drawing.Size(201, 26);
            this.resetToolStripMenuItem.Text = "Reset";
            this.resetToolStripMenuItem.Click += new System.EventHandler(this.resetToolStripMenuItem_Click);
            // 
            // splitContainer_Visualization
            // 
            this.splitContainer_Visualization.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer_Visualization.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer_Visualization.Location = new System.Drawing.Point(0, 28);
            this.splitContainer_Visualization.Margin = new System.Windows.Forms.Padding(5, 2, 3, 2);
            this.splitContainer_Visualization.Name = "splitContainer_Visualization";
            // 
            // splitContainer_Visualization.Panel1
            // 
            this.splitContainer_Visualization.Panel1.BackColor = System.Drawing.SystemColors.Control;
            this.splitContainer_Visualization.Panel1.Controls.Add(this.splitContainer_IfcTree);
            // 
            // splitContainer_Visualization.Panel2
            // 
            this.splitContainer_Visualization.Panel2.BackColor = System.Drawing.SystemColors.Control;
            this.splitContainer_Visualization.Panel2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.splitContainer_Visualization.Size = new System.Drawing.Size(1114, 652);
            this.splitContainer_Visualization.SplitterDistance = 297;
            this.splitContainer_Visualization.TabIndex = 1;
            // 
            // splitContainer_IfcTree
            // 
            this.splitContainer_IfcTree.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer_IfcTree.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer_IfcTree.Location = new System.Drawing.Point(0, 0);
            this.splitContainer_IfcTree.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.splitContainer_IfcTree.Name = "splitContainer_IfcTree";
            this.splitContainer_IfcTree.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer_IfcTree.Panel1
            // 
            this.splitContainer_IfcTree.Panel1.Controls.Add(this.IfcSBTree);
            this.splitContainer_IfcTree.Panel1.Margin = new System.Windows.Forms.Padding(5, 0, 0, 0);
            // 
            // splitContainer_IfcTree.Panel2
            // 
            this.splitContainer_IfcTree.Panel2.Controls.Add(this.splitContainer_Checking);
            this.splitContainer_IfcTree.Size = new System.Drawing.Size(293, 648);
            this.splitContainer_IfcTree.SplitterDistance = 231;
            this.splitContainer_IfcTree.SplitterWidth = 3;
            this.splitContainer_IfcTree.TabIndex = 0;
            // 
            // IfcSBTree
            // 
            this.IfcSBTree.Dock = System.Windows.Forms.DockStyle.Fill;
            this.IfcSBTree.ForeColor = System.Drawing.Color.Black;
            this.IfcSBTree.ImageIndex = 0;
            this.IfcSBTree.ImageList = this.treeIcons;
            this.IfcSBTree.Location = new System.Drawing.Point(0, 0);
            this.IfcSBTree.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.IfcSBTree.Name = "IfcSBTree";
            this.IfcSBTree.SelectedImageIndex = 0;
            this.IfcSBTree.Size = new System.Drawing.Size(291, 229);
            this.IfcSBTree.TabIndex = 0;
            // 
            // treeIcons
            // 
            this.treeIcons.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("treeIcons.ImageStream")));
            this.treeIcons.TransparentColor = System.Drawing.Color.Transparent;
            this.treeIcons.Images.SetKeyName(0, "0.bmp");
            this.treeIcons.Images.SetKeyName(1, "1.bmp");
            this.treeIcons.Images.SetKeyName(2, "2.bmp");
            this.treeIcons.Images.SetKeyName(3, "3.bmp");
            this.treeIcons.Images.SetKeyName(4, "4.bmp");
            this.treeIcons.Images.SetKeyName(5, "5.bmp");
            // 
            // splitContainer_Checking
            // 
            this.splitContainer_Checking.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer_Checking.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer_Checking.Location = new System.Drawing.Point(0, 0);
            this.splitContainer_Checking.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.splitContainer_Checking.Name = "splitContainer_Checking";
            this.splitContainer_Checking.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer_Checking.Panel1
            // 
            this.splitContainer_Checking.Panel1.Controls.Add(this.treeView_CheckingRules);
            // 
            // splitContainer_Checking.Panel2
            // 
            this.splitContainer_Checking.Panel2.Controls.Add(this.splitContainer_ResultReporting);
            this.splitContainer_Checking.Size = new System.Drawing.Size(293, 414);
            this.splitContainer_Checking.SplitterDistance = 119;
            this.splitContainer_Checking.SplitterWidth = 3;
            this.splitContainer_Checking.TabIndex = 0;
            // 
            // treeView_CheckingRules
            // 
            this.treeView_CheckingRules.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeView_CheckingRules.Location = new System.Drawing.Point(0, 0);
            this.treeView_CheckingRules.Name = "treeView_CheckingRules";
            treeNode1.Name = "Node_SR.0";
            treeNode1.Text = "-> SR.0: IfcCartesianPoint checking ";
            treeNode2.Name = "Node_SR.1";
            treeNode2.Text = "-> SR.1: SB attribute value checking ";
            treeNode3.Name = "Node_SR.2";
            treeNode3.Text = "-> SR.2: SB existence checking ";
            treeNode4.Name = "Node_SR.3";
            treeNode4.Text = "-> SR.3: Openings\' SBs checking";
            treeNode5.Name = "Node_SR.4";
            treeNode5.Text = "-> SR.4: Aggregate elements\' SBs checking";
            treeNode6.Name = "Node_SR";
            treeNode6.Text = "-> SR: Syntactic and semantic rules";
            treeNode7.Name = "Node_GR.1";
            treeNode7.Text = "-> GR.1: SB geometric representation checking";
            treeNode8.Name = "Node_GR.2";
            treeNode8.Text = "-> GR.2: Space airtightness checking";
            treeNode9.Name = "Node_GR";
            treeNode9.Text = "-> GR: Geometric rules";
            treeNode10.Name = "Node_CR.1";
            treeNode10.Text = "-> CR.1: Description/InternalOrExternalBoundary chekcing ";
            treeNode11.Name = "Node_CR.2";
            treeNode11.Text = "-> CR.2: RelatingSpace/RelatedBuildingElement checking";
            treeNode12.Name = "Node_CR.3";
            treeNode12.Text = "-> CR.3: PhysicalOrVirtualBoundary checking";
            treeNode13.Name = "Node_CR.4";
            treeNode13.Text = "-> CR.4: ParentBoundary checking ";
            treeNode14.Name = "Node_CR.5";
            treeNode14.Text = "-> CR.5: CorrespondingBoundary checking ";
            treeNode15.Name = "Node_CR";
            treeNode15.Text = "-> CR: Consistency rules";
            treeNode16.Name = "Node_CheckingRules";
            treeNode16.Text = "->Validation rules";
            this.treeView_CheckingRules.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode16});
            this.treeView_CheckingRules.Size = new System.Drawing.Size(291, 117);
            this.treeView_CheckingRules.TabIndex = 1;
            // 
            // splitContainer_ResultReporting
            // 
            this.splitContainer_ResultReporting.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer_ResultReporting.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer_ResultReporting.Location = new System.Drawing.Point(0, 0);
            this.splitContainer_ResultReporting.Name = "splitContainer_ResultReporting";
            this.splitContainer_ResultReporting.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer_ResultReporting.Panel1
            // 
            this.splitContainer_ResultReporting.Panel1.Controls.Add(this.textBox_RuleDescription);
            // 
            // splitContainer_ResultReporting.Panel2
            // 
            this.splitContainer_ResultReporting.Panel2.Controls.Add(this.treeView_ResultReporting);
            this.splitContainer_ResultReporting.Size = new System.Drawing.Size(291, 290);
            this.splitContainer_ResultReporting.SplitterDistance = 88;
            this.splitContainer_ResultReporting.TabIndex = 0;
            // 
            // textBox_RuleDescription
            // 
            this.textBox_RuleDescription.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBox_RuleDescription.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox_RuleDescription.Location = new System.Drawing.Point(0, 0);
            this.textBox_RuleDescription.Margin = new System.Windows.Forms.Padding(10);
            this.textBox_RuleDescription.Multiline = true;
            this.textBox_RuleDescription.Name = "textBox_RuleDescription";
            this.textBox_RuleDescription.ReadOnly = true;
            this.textBox_RuleDescription.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox_RuleDescription.Size = new System.Drawing.Size(287, 84);
            this.textBox_RuleDescription.TabIndex = 0;
            // 
            // treeView_ResultReporting
            // 
            this.treeView_ResultReporting.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeView_ResultReporting.Location = new System.Drawing.Point(0, 0);
            this.treeView_ResultReporting.Name = "treeView_ResultReporting";
            this.treeView_ResultReporting.Size = new System.Drawing.Size(287, 194);
            this.treeView_ResultReporting.TabIndex = 0;
            // 
            // SecondLevelSBValidation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1114, 680);
            this.Controls.Add(this.splitContainer_Visualization);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "SecondLevelSBValidation";
            this.Text = "2ndLevelSBValidation";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.splitContainer_Visualization.Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer_Visualization)).EndInit();
            this.splitContainer_Visualization.ResumeLayout(false);
            this.splitContainer_IfcTree.Panel1.ResumeLayout(false);
            this.splitContainer_IfcTree.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer_IfcTree)).EndInit();
            this.splitContainer_IfcTree.ResumeLayout(false);
            this.splitContainer_Checking.Panel1.ResumeLayout(false);
            this.splitContainer_Checking.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer_Checking)).EndInit();
            this.splitContainer_Checking.ResumeLayout(false);
            this.splitContainer_ResultReporting.Panel1.ResumeLayout(false);
            this.splitContainer_ResultReporting.Panel1.PerformLayout();
            this.splitContainer_ResultReporting.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer_ResultReporting)).EndInit();
            this.splitContainer_ResultReporting.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem checkingToolStripMenuItem;
        private System.Windows.Forms.SplitContainer splitContainer_Visualization;
        private System.Windows.Forms.SplitContainer splitContainer_IfcTree;
        private System.Windows.Forms.SplitContainer splitContainer_Checking;
        private System.Windows.Forms.TreeView IfcSBTree;
        private System.Windows.Forms.ImageList treeIcons;
        private System.Windows.Forms.ToolStripMenuItem viewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem wireframeModelToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem surfaceModelToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem resetToolStripMenuItem;
        private System.Windows.Forms.TreeView treeView_CheckingRules;
        private System.Windows.Forms.SplitContainer splitContainer_ResultReporting;
        private System.Windows.Forms.TextBox textBox_RuleDescription;
        private System.Windows.Forms.TreeView treeView_ResultReporting;
        private System.Windows.Forms.ToolStripMenuItem gVToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cVToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sSVToolStripMenuItem;
    }
}

