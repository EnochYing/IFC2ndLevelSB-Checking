﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecondLevelSBValidation
{
    public class Polyline2D
    {
        public List<Point2D> Vertices = new List<Point2D> (); // Be careful, start point MUST be not taken as the end point
        public Vector3D SurfaceNormal = new Vector3D();

        // this method used cross product of two non coline vectors fromed by the vertices of the polyline  
        // this method generate the surface normal vector according to the order of the points (clockwise or countclockwise)
        public Vector3D ExtractPolylineSurfaceNormal(Polyline2D _Polyline2D)
        {
            Vector3D _SurfaceNormal = new Vector3D();
            Vector3D vector = new Vector3D();

            Vector3D AB = new Vector3D(); // A refers to the start point of the polyline, B refers to the second point
            Vector3D AD = new Vector3D(); // vector not co line with AB vector and the direction from AB to AD should be the direction of the polyline

            AB.x = _Polyline2D.Vertices[1].x - _Polyline2D.Vertices[0].x;
            AB.y = _Polyline2D.Vertices[1].y - _Polyline2D.Vertices[0].y;
            AB.z = 0;

            _SurfaceNormal.x = 0;
            _SurfaceNormal.y = 0;
            double z = 0;
            double d = 0;

            // compute the direction from AB to AD 
            PolylineDirection direction = PolylineDirection.Unknown;
            for (int i = 2; i < _Polyline2D.Vertices.Count; i++)
            {
                AD.x = _Polyline2D.Vertices[i].x - _Polyline2D.Vertices[0].x;
                AD.y = _Polyline2D.Vertices[i].y - _Polyline2D.Vertices[0].y;
                AD.z = 0;
                if (!vector.IsParallel(AB, AD)) // not coline
                {
                    z = AB.x * AD.y - AD.x * AB.y;
                    d = Math.Sqrt(z * z);
                    if (z > 0)
                    {
                        direction = PolylineDirection.Count_Clockwise;
                    }
                    if (z < 0)
                    {
                        direction = PolylineDirection.Clockwise;
                    }
                    break;
                }
            }

            if (_Polyline2D.Polyline2DDirection(_Polyline2D) == direction)
            {
                _SurfaceNormal.z = z / d;
            }
            else
            {
                _SurfaceNormal.z = (-1) * z / d;
            }

            return _SurfaceNormal;
        }

        public PolylineDirection Polyline2DDirection(Polyline2D points) // Polygon -- if polyline is used, the start point should be not the end point 
        {
            int nCount = 0, j = 0, k = 0;
            int nPoints = points.Vertices.Count;

            if (nPoints < 3)
                return PolylineDirection.Unknown;

            for (int i = 0; i < nPoints; i++)
            {
                j = (i + 1) % nPoints; //j:=i+1;
                k = (i + 2) % nPoints; //k:=i+2;

                double crossProduct = (points.Vertices[j].x - points.Vertices[i].x) * (points.Vertices[k].y - points.Vertices[j].y);
                crossProduct = crossProduct - ((points.Vertices[j].y - points.Vertices[i].y) * (points.Vertices[k].x - points.Vertices[j].x));

                if (crossProduct > 0)
                    nCount++;
                else
                    nCount--;
            }

            if (nCount < 0)
                return PolylineDirection.Clockwise;
            else if (nCount > 0)
                return PolylineDirection.Count_Clockwise;
            else
                return PolylineDirection.Unknown;
        }
    }

    public class Polyline3D
    {
        public List<Point3D> Vertices = new List<Point3D> ();
        public Vector3D SurfaceNormal = new Vector3D();

        // The starting point != end point
        // More roboust method: Newell's Method for an arbitrary 3D polygon 
        public Vector3D AddSurfaceNormal(Polyline3D Polygon3D)
        {
            Vector3D vector = new Vector3D();

            for (int i = 0; i < Polygon3D.Vertices.Count; i++)
            {
                Point3D CP = Polygon3D.Vertices[i];
                Point3D NP = Polygon3D.Vertices[(i + 1) % Polygon3D.Vertices.Count];

                vector.x = vector.x + (CP.y - NP.y) * (CP.z + NP.z);
                vector.y = vector.y + (CP.z - NP.z) * (CP.x + NP.x);
                vector.z = vector.z + (CP.x - NP.x) * (CP.y + NP.y);
            }

            vector = vector.UnitVector(vector);
            return vector;
        }

        public Vector3D AddSurfaceNormal()
        {
            Vector3D vector = new Vector3D();

            for (int i = 0; i < this.Vertices.Count; i++)
            {
                Point3D CP = this.Vertices[i];
                Point3D NP = this.Vertices[(i + 1) % this.Vertices.Count];

                vector.x = vector.x + (CP.y - NP.y) * (CP.z + NP.z);
                vector.y = vector.y + (CP.z - NP.z) * (CP.x + NP.x);
                vector.z = vector.z + (CP.x - NP.x) * (CP.y + NP.y);
            }

            vector = vector.UnitVector(vector);
            return vector;
        }
    }

}
