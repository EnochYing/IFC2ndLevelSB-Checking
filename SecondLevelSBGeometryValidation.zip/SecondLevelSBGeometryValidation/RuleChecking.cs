﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.IO;

namespace SecondLevelSBValidation
{
    public class RuleChecking_SSV
    {
        public SR_0_1_RuleChecking SRC_0_1 = null;
        public SR_0_2_RuleChecking SRC_0_2 = null;
        public SR_1_1_RuleChecking SRC_1_1 = null;
        public SR_1_2_RuleChecking SRC_1_2 = null;
        public SR_2_1_RuleChecking SRC_2_1 = null;
        public SR_2_2_RuleChecking SRC_2_2 = null;
        public SR_3_1_RuleChecking SRC_3_1 = null;
        public SR_4_1_RuleChecking SRC_4_1 = null;

        public RuleChecking_SSV()
        {

        }
        public RuleChecking_SSV(Int64 IfcModel, List<IfcRelSpaceBoundary> SBs, Dictionary<BuildingElementType, List<Int64>> elementTypes)
        {
            SRC_0_1 = new SR_0_1_RuleChecking(SBs);
            SRC_0_2 = new SR_0_2_RuleChecking(SBs);
            SRC_1_1 = new SR_1_1_RuleChecking(SBs);            
            SRC_1_2 = new SR_1_2_RuleChecking(SBs);
            SRC_2_1 = new SR_2_1_RuleChecking(IfcModel);
            SRC_2_2 = new SR_2_2_RuleChecking(IfcModel);
            SRC_3_1 = new SR_3_1_RuleChecking(IfcModel, SBs);
            SRC_4_1 = new SR_4_1_RuleChecking(IfcModel);
        }       
    }

    public class RuleChecking_GV
    {
        public GR_1_1_RuleChecking GRC_1_1 = new GR_1_1_RuleChecking();
        public GR_1_2_RuleChecking GRC_1_2 = new GR_1_2_RuleChecking();
        public GR_2_RuleChecking GRC_2 = new GR_2_RuleChecking();
        public List<IfcSpace> Spaces = new List<IfcSpace>();

        public RuleChecking_GV()
        {

        }

        // All input SBs complying with SSV Type 1 and Type 2 rules
        public RuleChecking_GV(Int64 IfcModel, List<IfcRelSpaceBoundary> SBs, float dimensionalScale, Dictionary<BuildingElementType, List<Int64>> elementTypes, List<IfcBuildingElement> elements)
        {
            // Identify SBs satisfying SSV rules
            List<IfcRelSpaceBoundary> SBs_SSV = new List<IfcRelSpaceBoundary>();
            foreach (var sb in SBs)
            {
                if (sb.Polygon3D_WCS.Vertices.Count != 0)
                    SBs_SSV.Add(sb);
            }

            // Depending on SSV rules 
            GRC_1_1 = new GR_1_1_RuleChecking(ref SBs_SSV);       

            // Identify SBs satisfying SSV rules + GR.1.1
            List<IfcRelSpaceBoundary> SBs_SSV_GRC1_1 = new List<IfcRelSpaceBoundary>();
            foreach (var sb in SBs_SSV)
            {
                if (!GRC_1_1.failingSBs_instanceNames.Contains(sb.InstanceName))
                    SBs_SSV_GRC1_1.Add(sb);                      
            }

            this.Spaces = ExtractSpaces_GroupSBs(IfcModel, SBs_SSV_GRC1_1);

            // Depending on SSV rules + GR1.1
            GRC_1_2 = new GR_1_2_RuleChecking(IfcModel, SBs_SSV_GRC1_1, dimensionalScale, this.Spaces, elements);           
            WriteOutDefectiveSB_RelatingSpace_SE(GRC_1_2.DefectiveSBs, SBs_SSV_GRC1_1, IfcModel);

            // Depending on SSV rules + GR1.1
            GRC_2 = new GR_2_RuleChecking(Spaces, 10000, 2000, dimensionalScale);  
            WriteOutDefectiveSpaces(GRC_2.ray_defectSpace);
        }

        // All these SBs are non-opening SBs; and output their geometry in spaceLCS; ray is also defined in spaceLCS
        private void WriteOutDefectiveSpaces(Dictionary<Ray3D, defectiveSpace> ray_defectSpace)
        {
            int Num_space = 0;
            foreach (var item in ray_defectSpace)
            {
                Num_space += 1;
                string s = "Space" + "[" + item.Value.spaceInstanceName + "]" + "_" + Num_space.ToString();
                StreamWriter txtWriter = new StreamWriter(s, true);
                foreach (var SB in item.Value.nonopeningSBs)  // write out geometry in spaceLCS
                {
                    string sb = null;
                    foreach (var vertex in SB.Polygon3D_InSpace.Vertices)
                        sb += vertex.x.ToString() + ' ' + vertex.y.ToString() + ' ' + vertex.z.ToString() + ' ';
                    txtWriter.WriteLine(sb);
                }
                string ray = item.Key.StartPoint.x.ToString() + ' ' + item.Key.StartPoint.y.ToString() + ' ' + item.Key.StartPoint.z.ToString() + ' '
                  + item.Key.Direction.x.ToString() + ' '
                  + item.Key.Direction.y.ToString() + ' '
                  + item.Key.Direction.z.ToString() + ' ';  
                txtWriter.WriteLine(ray);

                txtWriter.Close();
            }
        }

        private List<IfcSpace> ExtractSpaces_GroupSBs(Int64 IfcModel, List<IfcRelSpaceBoundary> SBs)
        {
            List<IfcSpace> result = new List<IfcSpace>();
           
            // SpaceGlobalID_IfcRelSpaceBoundary
            Dictionary<string, List<IfcRelSpaceBoundary>> spaces_SBs = new Dictionary<string, List<IfcRelSpaceBoundary>>();
            foreach (var sb in SBs)
            {
                if (sb.RelatingSpaceType != SpaceType.IfcExternalSpatialElement)
                {
                    if (spaces_SBs.Count == 0)
                    {
                        List<IfcRelSpaceBoundary> sbs = new List<IfcRelSpaceBoundary>();
                        sbs.Add(sb);
                        spaces_SBs.Add(sb.RelatingSpaceGlobalID, sbs);
                    }
                    else
                    {
                        if (spaces_SBs.ContainsKey(sb.RelatingSpaceGlobalID))
                            spaces_SBs[sb.RelatingSpaceGlobalID].Add(sb);
                        else
                        {
                            List<IfcRelSpaceBoundary> sbs = new List<IfcRelSpaceBoundary>();
                            sbs.Add(sb);
                            spaces_SBs.Add(sb.RelatingSpaceGlobalID, sbs);
                        }
                    }
                }
            }

            // IfcSpace instances
            Int64 SpaceInstances = IfcEngine.sdaiGetEntityExtentBN(IfcModel, "IfcSpace");
            Int64 NumSpaces = IfcEngine.sdaiGetMemberCount(SpaceInstances);
            for (int i = 0; i < NumSpaces; i++)
            {
                Int64 SpaceInstance = 0;
                IfcEngine.engiGetAggrElement(SpaceInstances, i, IfcEngine.sdaiINSTANCE, out SpaceInstance);
                result.Add(new IfcSpace(IfcModel, SpaceInstance, spaces_SBs));
            }

            return result;
        }

        // Write out all SBs of the relating space (in spaceLCS), incorrect normal of defective SBs (in spaceLCS)
        private void WriteOutDefectiveSB_RelatingSpace_SE(List<IfcRelSpaceBoundary> SBsWithWrongSN, List<IfcRelSpaceBoundary> allSBs, Int64 IfcModel)
        {
            Dictionary<string, List<IfcRelSpaceBoundary>> spaces_SE_SBs_incorrectSN = origanizeSBsWithWrongSNBySpace_SE(SBsWithWrongSN, allSBs);

            foreach (var item in spaces_SE_SBs_incorrectSN)
            {
                string s;
                if (item.Value[0].RelatingSpaceType== SpaceType.IfcSpace)
                    s = "SBNormal_Space" + "[" + item.Key + "]";
                else
                    s = "SBNormal_ShadingElement" + "[" + item.Key + "]";

                StreamWriter txtWriter = new StreamWriter(s, true);
                foreach (var SB in item.Value)  // write out geometry in spaceLCS
                {
                    string sb = null;
                    foreach (var vertex in SB.Polygon3D_InSpace.Vertices)
                        sb += vertex.x.ToString() + ' ' + vertex.y.ToString() + ' ' + vertex.z.ToString() + ' ';
                    txtWriter.WriteLine(sb);

                    if (SB.OutputPolygon3D_InSpace)
                    {
                        Point3D sp = new Point3D();
                        sp.x = (SB.TriangulatedSB_InSpace[0].Vertex1.x + SB.TriangulatedSB_InSpace[0].Vertex2.x + SB.TriangulatedSB_InSpace[0].Vertex3.x) / 3.0;
                        sp.y = (SB.TriangulatedSB_InSpace[0].Vertex1.y + SB.TriangulatedSB_InSpace[0].Vertex2.y + SB.TriangulatedSB_InSpace[0].Vertex3.y) / 3.0;
                        sp.z = (SB.TriangulatedSB_InSpace[0].Vertex1.z + SB.TriangulatedSB_InSpace[0].Vertex2.z + SB.TriangulatedSB_InSpace[0].Vertex3.z) / 3.0;

                        string SN = sp.x.ToString() + ' ' + sp.y.ToString() + ' ' + sp.z.ToString() + ' '
                            + SB.Polygon3D_InSpace.SurfaceNormal.x.ToString() + ' '
                            + SB.Polygon3D_InSpace.SurfaceNormal.y.ToString() + ' '
                            + SB.Polygon3D_InSpace.SurfaceNormal.z.ToString() + ' ';

                        txtWriter.WriteLine(SN);
                    }
                }
                txtWriter.Close();
            }
        }

        private Dictionary<string, List<IfcRelSpaceBoundary>> origanizeSBsWithWrongSNBySpace_SE(List<IfcRelSpaceBoundary> defectiveSBs, List<IfcRelSpaceBoundary> allSBs)
        {
            Dictionary<string, List<IfcRelSpaceBoundary>> space_EE_SBs = new Dictionary<string, List<IfcRelSpaceBoundary>>();
            foreach (var sb in defectiveSBs)
            {
                sb.OutputPolygon3D_InSpace = true;
                if (sb.RelatingSpaceType == SpaceType.IfcSpace)
                {
                    if (space_EE_SBs.Keys.Contains(sb.RelatingSpaceInstanceName))
                    {
                        space_EE_SBs[sb.RelatingSpaceInstanceName].Add(sb);
                    } else
                    {
                        List<IfcRelSpaceBoundary> SBs = new List<IfcRelSpaceBoundary>();
                        SBs.Add(sb);
                        space_EE_SBs.Add(sb.RelatingSpaceInstanceName, SBs);
                    }
                } else
                {
                    if (space_EE_SBs.Keys.Contains(sb.RelatedBuildingElementInstanceName))
                    {
                        space_EE_SBs[sb.RelatedBuildingElementInstanceName].Add(sb);
                    }
                    else
                    {
                        List<IfcRelSpaceBoundary> SBs = new List<IfcRelSpaceBoundary>();
                        SBs.Add(sb);
                        space_EE_SBs.Add(sb.RelatedBuildingElementInstanceName, SBs);
                    }
                }
            }

            foreach(var item in space_EE_SBs)
            {
                List<IfcRelSpaceBoundary> others = FindAllOtherSBs(item.Value, allSBs);
                item.Value.AddRange(others);
            }

            return space_EE_SBs;
        }

        private List<IfcRelSpaceBoundary> FindAllOtherSBs(List<IfcRelSpaceBoundary> existingSBs, List<IfcRelSpaceBoundary> allSBs)
        {
            List<IfcRelSpaceBoundary> result = new List<IfcRelSpaceBoundary>();

            if (existingSBs[0].RelatingSpaceType == SpaceType.IfcSpace)
            {
                foreach (var sb in allSBs)
                {
                    if (sb.RelatingSpaceGlobalID == existingSBs[0].RelatingSpaceGlobalID)
                    {
                        bool exist = false;
                        foreach(var sbe in existingSBs)
                        {
                            if(sb.Instance == sbe.Instance)
                            {
                                exist = true;
                                break;
                            }
                        }
                        if (!exist)
                            result.Add(sb);
                    }
                }
            } else
            {
                foreach (var sb in allSBs)
                {
                    if (sb.RelatedBuildingElementGlobalID == existingSBs[0].RelatedBuildingElementGlobalID)
                    {
                        bool exist = false;
                        foreach (var sbe in existingSBs)
                        {
                            if (sb.Instance == sbe.Instance)
                            {
                                exist = true;
                                break;
                            }
                        }
                        if (!exist)
                            result.Add(sb);
                    }
                }
            }
            return result;
        }

    }

    public class RuleChecking_CV
    {
        public CR_1_RuleChecking CRC_1 = null;
        public CR_1_6_RuleChecking CRC_1_6 = null;
        public CR_2_RuleChecking CRC_2 = null;
        public CR_3_RuleChecking CRC_3 = null;
        public CR_4_RuleChecking CRC_4 = null;
        public CR_5_RuleChecking CRC_5 = null;

        public RuleChecking_CV()
        {

        }

        public RuleChecking_CV(Int64 IfcModel, List<IfcBuildingElement> Elements, List<IfcRelSpaceBoundary> SBs_PassingSSV, 
                               float dimensionalScale, Dictionary<BuildingElementType, List<Int64>> elementTypes, List<string> failingSBs_GRC_1_1, List<string> failingSBs_GRC_1_2)
        {
            // IfcSpace instances
            List<IfcSpace> Spaces = new List<IfcSpace>();
            Int64 SpaceInstances = IfcEngine.sdaiGetEntityExtentBN(IfcModel, "IfcSpace");
            Int64 NumSpaces = IfcEngine.sdaiGetMemberCount(SpaceInstances);
            for (int i = 0; i < NumSpaces; i++)
            {
                Int64 SpaceInstance = 0;
                IfcEngine.engiGetAggrElement(SpaceInstances, i, IfcEngine.sdaiINSTANCE, out SpaceInstance);
                Spaces.Add(new IfcSpace(IfcModel, SpaceInstance));
            }

            // IfcSite instances
            List<IfcSite> Sites = new List<IfcSite>();
            Int64 SiteInstances = IfcEngine.sdaiGetEntityExtentBN(IfcModel, "IfcSite");
            Int64 NumSites = IfcEngine.sdaiGetMemberCount(SiteInstances);
            for (int i = 0; i < NumSites; i++)
            {
                Int64 SiteInstance = 0;
                IfcEngine.engiGetAggrElement(SiteInstances, i, IfcEngine.sdaiINSTANCE, out SiteInstance);
                Sites.Add(new IfcSite(IfcModel, SiteInstance));
            }

            // Idnetify SBs satisfy (SSV rules + GR1.1) / (SSV rules + GR1.1 + GR1.2)
            List<IfcRelSpaceBoundary> SBs_SSV_GR1_1 = new List<IfcRelSpaceBoundary>();
            List<IfcRelSpaceBoundary> SBs_SSV_GR1_1_GR1_2 = new List<IfcRelSpaceBoundary>();         

            foreach (var sb in SBs_PassingSSV)
            {
                if (sb.Polygon3D_WCS.Vertices.Count != 0)
                {
                    if (!failingSBs_GRC_1_1.Contains(sb.InstanceName))
                    {
                        SBs_SSV_GR1_1.Add(sb);
                        if (!failingSBs_GRC_1_2.Contains(sb.InstanceName))
                        {
                            SBs_SSV_GR1_1_GR1_2.Add(sb);
                        }
                    }                        
                }             
            }

            // CR.1.1~4: Depending on SSV rules + GR1.1 + GR1.2
            // CR.1.5: Depending on SSV rules + GR1.1
            #region IMPORTANT!!!
            //The offset distance is important.
            // If we follow the heat transfer principle, we should set 800mm, but which can still have degenerate issues for very slim spaces;
            // If we follow early version SB generation algorithm, we should consider that once the other side is an object not a space, it should be 2b. then we should use varying distance slightly larger the related building element's thickness.  
            // Currently, we use the second strategy. For different Ifc files, we may accoridngly change the strategy.
            #endregion
            CRC_1 = new CR_1_RuleChecking(SBs_SSV_GR1_1, SBs_SSV_GR1_1_GR1_2, Spaces, Elements, Sites, dimensionalScale);

            // CR.1.6: Depending on SSV rules + CR.1.1~5
            List<IfcRelSpaceBoundary> SBs_SSV_CR_1 = new List<IfcRelSpaceBoundary>();
            foreach (var sb in SBs_PassingSSV)
            {
                if (!CRC_1.failingSBs_instanceNames.Contains(sb.InstanceName))
                    SBs_SSV_CR_1.Add(sb);
            }
            CRC_1_6 = new CR_1_6_RuleChecking(SBs_SSV_CR_1);
            
            // CR.2.1~2: Depending on SSV rules + GR1.1
            CRC_2 = new CR_2_RuleChecking(IfcModel, SBs_SSV_GR1_1, Elements, Spaces, dimensionalScale);
            WriteOutDefectiveSB_RelatingElementOrSpace(CRC_2.SB_RelatedElement, CRC_2.SB_RelatingSpace);

            // CR.3.1~2: None
            CRC_3 = new CR_3_RuleChecking(SBs_PassingSSV);

            // CR.4.1~2: Depending on SSV rules + GR1.1 + CR.1
            List<IfcRelSpaceBoundary> SBs_SSV_GR_1_1_CR_1 = new List<IfcRelSpaceBoundary>();
            foreach (var sb in SBs_SSV_GR1_1)
            {
                if (!CRC_1.failingSBs_instanceNames.Contains(sb.InstanceName))
                    SBs_SSV_GR_1_1_CR_1.Add(sb);
            }
            CRC_4 = new CR_4_RuleChecking(IfcModel, SBs_SSV_GR_1_1_CR_1, elementTypes, Elements, dimensionalScale);

            // CR.5.1: Depending on SSV rules + GR1.1
            CRC_5 = new CR_5_RuleChecking(IfcModel, SBs_SSV_GR1_1, elementTypes);          
        }


        private void  WriteOutDefectiveSB_RelatingElementOrSpace(Dictionary<IfcRelSpaceBoundary, IfcBuildingElement> SB_RelatedElement, Dictionary<IfcRelSpaceBoundary, IfcSpace> SB_RelatingSpace)
        {
            int Num_space = 0;
            foreach (var item in SB_RelatingSpace)
            {
                Num_space += 1;
                string s = "Space_CR2" + "[" + item.Value.InstanceName + "]" + "_" + Num_space.ToString();
                StreamWriter txtWriter = new StreamWriter(s, true);

                string sb = null;
                foreach (var vertex in item.Key.Polygon3D_WCS.Vertices)
                    sb += vertex.x.ToString() + ' ' + vertex.y.ToString() + ' ' + vertex.z.ToString() + ' ';
                txtWriter.WriteLine(sb);

                
                foreach (var face in item.Value.FactedBrep.FacetedBrep_Polygon)
                {
                    string f = null;
                    foreach (var vertex in face.Vertices)
                        f += vertex.x.ToString() + ' ' + vertex.y.ToString() + ' ' + vertex.z.ToString() + ' ';
                    txtWriter.WriteLine(f);
                }
                txtWriter.Close();
            }

            int Num_element = 0;
            foreach (var item in SB_RelatedElement)
            {
                Num_element += 1;
                string s = "Element_CR2" + "[" + item.Value.instanceName + "]" + "_" + Num_element.ToString();
                StreamWriter txtWriter = new StreamWriter(s, true);

                string sb = null;
                foreach (var vertex in item.Key.Polygon3D_WCS.Vertices)
                    sb += vertex.x.ToString() + ' ' + vertex.y.ToString() + ' ' + vertex.z.ToString() + ' ';
                txtWriter.WriteLine(sb);

                foreach (var face in item.Value.FacetedBrep.FacetedBrep_Polygon)
                {
                    string f = null;
                    foreach (var vertex in face.Vertices)
                        f += vertex.x.ToString() + ' ' + vertex.y.ToString() + ' ' + vertex.z.ToString() + ' ';
                    txtWriter.WriteLine(f);
                }
                txtWriter.Close();
            }
        }
    }
}


