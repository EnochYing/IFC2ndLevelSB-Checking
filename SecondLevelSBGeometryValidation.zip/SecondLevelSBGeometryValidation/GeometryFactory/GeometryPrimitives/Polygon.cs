﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecondLevelSBValidation
{
  
    public class Polygon2D
    {
        public Int64 NumVertex;
        public Point2D [] _Polygon2D;

        public static PolygonDirection PointsDirection(Point2D[] points)
        {
            int nCount = 0, j = 0, k = 0;
            int nPoints = points.Length;

            if (nPoints < 3)
                return PolygonDirection.Unknown;

            for (int i = 0; i < nPoints; i++)
            {
                j = (i + 1) % nPoints; //j:=i+1;
                k = (i + 2) % nPoints; //k:=i+2;

                double crossProduct = (points[j].x - points[i].x) * (points[k].y - points[j].y);
                crossProduct = crossProduct - ((points[j].y - points[i].y) * (points[k].x - points[j].x));

                if (crossProduct > 0)
                    nCount++;
                else
                    nCount--;
            }

            if (nCount < 0)
                return PolygonDirection.Count_Clockwise;
            else if (nCount > 0)
                return PolygonDirection.Clockwise;
            else
                return PolygonDirection.Unknown;
        }

        public PolygonDirection VerticesDirection()
        {
            int nCount = 0, j = 0, k = 0;
            int nVertices = _Polygon2D.Length;

            for (int i = 0; i < nVertices; i++)
            {
                j = (i + 1) % nVertices; //j:=i+1;
                k = (i + 2) % nVertices; //k:=i+2;

                double crossProduct = (_Polygon2D[j].x - _Polygon2D[i].x) * (_Polygon2D[k].y - _Polygon2D[j].y);
                crossProduct = crossProduct - ((_Polygon2D[j].y - _Polygon2D[i].y) * (_Polygon2D[k].x - _Polygon2D[j].x));

                if (crossProduct > 0)
                    nCount++;
                else
                    nCount--;
            }

            if (nCount < 0)
                return PolygonDirection.Count_Clockwise;
            else if (nCount > 0)
                return PolygonDirection.Clockwise;
            else
                return PolygonDirection.Unknown;
        }

        public static void ReversePointsDirection(Point2D[] points)
        {
            int nVertices = points.Length;
            Point2D[] aTempPts = new Point2D[nVertices];

            for (int i = 0; i < nVertices; i++)
                aTempPts[i] = points[i];

            for (int i = 0; i < nVertices; i++)
                points[i] = aTempPts[nVertices - 1 - i];
        }

        /******************************************
		To calculate the area of polygon made by given points 

		Good for polygon with holes, but the vertices make the 
		hole  should be in different direction with bounding 
		polygon.
		
		Restriction: the polygon is not self intersecting
		ref: www.swin.edu.au/astronomy/pbourke/
			geometry/polyarea/

		As polygon in different direction, the result coulb be
		in different sign:
		If dblArea>0 : polygon in clock wise to the user 
		If dblArea<0: polygon in count clock wise to the user 		
		*******************************************/
        public static double PolygonArea(Point2D[] points)
        {
            double dblArea = 0;
            int nNumOfPts = points.Length;

            int j;
            for (int i = 0; i < nNumOfPts; i++)
            {
                j = (i + 1) % nNumOfPts;
                dblArea += points[i].x * points[j].y;
                dblArea -= (points[i].y * points[j].x);
            }

            dblArea = dblArea / 2;
            return dblArea;
        }

        public Polygon2D (Point2D[] points)
        {
            int nNumOfPoitns = points.Length;
            try
            {
                if (nNumOfPoitns < 3)
                {
                    InvalidInputGeometryDataException ex = new InvalidInputGeometryDataException();
                    throw ex;
                }
                else
                {
                    _Polygon2D = new Point2D[nNumOfPoitns];
                    for (int i = 0; i < nNumOfPoitns; i++)
                    {
                        _Polygon2D[i] = points[i];
                    }
                }
            }
            catch (Exception e)
            {
                System.Diagnostics.Trace.WriteLine(e.Message + e.StackTrace);
            }
        }

        /*********************************************
    To check whether a given point is a CPolygon Vertex
    **********************************************/
        public bool PolygonVertex(Point2D point)
        {
            bool bVertex = false;
            int nIndex = VertexIndex(point);

            if ((nIndex >= 0) && (nIndex <= _Polygon2D.Length - 1))
                bVertex = true;

            return bVertex;
        }

        /***********************************
     From a given point, get its vertex index.
     If the given point is not a polygon vertex, 
     it will return -1 
     ***********************************/
        public int VertexIndex(Point2D vertex)
        {
            int nIndex = -1;

            int nNumPts =_Polygon2D.Length;
            for (int i = 0; i < nNumPts; i++) //each vertex
            {
                if (Point2D.SamePoints(_Polygon2D[i], vertex))
                    nIndex = i;
            }
            return nIndex;
        }

        /***********************************************
        To check a vertex concave point or a convex point
        -----------------------------------------------------------
        The out polygon is in count clock-wise direction
    ************************************************/
        public VertexType PolygonVertexType(Point2D vertex)
        {
            VertexType vertexType = VertexType.ErrorPoint;

            if (PolygonVertex(vertex))
            {
                Point2D pti = vertex;
                Point2D ptj = PreviousPoint(vertex);
                Point2D ptk = NextPoint(vertex);

                double dArea = PolygonArea(new Point2D[] { ptj, pti, ptk });

                if (dArea < 0)
                    vertexType = VertexType.ConvexPoint;
                else if (dArea > 0)
                    vertexType = VertexType.ConcavePoint;
            }
            return vertexType;
        }

        /***********************************
     From a given vertex, get its previous vertex point.
     If the given point is the first one, 
     it will return  the last vertex;
     If the given point is not a polygon vertex, 
     it will return null; 
     ***********************************/
        public Point2D PreviousPoint(Point2D vertex)
        {
            int nIndex;

            nIndex = VertexIndex(vertex);
            if (nIndex == -1)
                return null;
            else //a valid vertex
            {
                if (nIndex == 0) //the first vertex
                {
                    int nPoints = _Polygon2D.Length;
                    return _Polygon2D[nPoints - 1];
                }
                else //not the first vertex
                    return _Polygon2D[nIndex - 1];
            }
        }

        /***************************************
			 From a given vertex, get its next vertex point.
			 If the given point is the last one, 
			 it will return  the first vertex;
			 If the given point is not a polygon vertex, 
			 it will return null; 
		***************************************/
        public Point2D NextPoint(Point2D vertex)
        {
            Point2D nextPt = new Point2D();

            int nIndex;
            nIndex = VertexIndex(vertex);
            if (nIndex == -1)
                return null;
            else //a valid vertex
            {
                int nNumOfPt = _Polygon2D.Length;
                if (nIndex == nNumOfPt - 1) //the last vertex
                {
                    return _Polygon2D[0];
                }
                else //not the last vertex
                    return _Polygon2D[nIndex + 1];
            }
        }


    }

    public class Polygon3D
    {
        public List<Point3D> Vertices;
        public Vector3D Normal;
    }
}
