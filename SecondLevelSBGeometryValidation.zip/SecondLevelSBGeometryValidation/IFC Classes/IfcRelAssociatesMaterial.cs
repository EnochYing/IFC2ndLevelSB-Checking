﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;



namespace SecondLevelSBValidation
{
    public class IfcRelAssociatesMaterial
    {
        public string GlobalID = null;
        public List<string> RelatedObjectGlobalIDs = new List<string>();
        public double RelatingMaterialThickness = 0;

        public IfcRelAssociatesMaterial ExtractElementAssociatesMaterials(Int64 IfcModel, Int64 IfcBuildingElement)
        {
            IfcRelAssociatesMaterial _IfcRelAssociatesMaterial = new IfcRelAssociatesMaterial();

            // extract building elelment GlobalID
            IntPtr BuildingElementGlobalIdPtr = IntPtr.Zero;
            IfcEngine.sdaiGetAttrBN(IfcBuildingElement, "GlobalId", IfcEngine.sdaiUNICODE, out BuildingElementGlobalIdPtr);
            String BuildingElememntGlobalID = Marshal.PtrToStringUni(BuildingElementGlobalIdPtr);

            Int64 IfcRelAssociatesMaterialInstances = IfcEngine.sdaiGetEntityExtentBN(IfcModel, "IfcRelAssociatesMaterial");
            Int64 NumInstances = IfcEngine.sdaiGetMemberCount(IfcRelAssociatesMaterialInstances);

            if (NumInstances != 0)
            {
                for (int i = 0; i < NumInstances; i++)
                {
                    Int64 IfcRelAssociatesMaterialInstance = 0;
                    IfcEngine.engiGetAggrElement(IfcRelAssociatesMaterialInstances, i, IfcEngine.sdaiINSTANCE, out IfcRelAssociatesMaterialInstance);

                    // Extract GlobalID
                    IntPtr GlobalIdPtr = IntPtr.Zero;
                    IfcEngine.sdaiGetAttrBN(IfcRelAssociatesMaterialInstance, "GlobalId", IfcEngine.sdaiUNICODE, out GlobalIdPtr);
                    _IfcRelAssociatesMaterial.GlobalID = Marshal.PtrToStringUni(GlobalIdPtr);

                    // Exteact related objects IDs
                    Int64 ObjectInstances = 0;
                    IfcEngine.sdaiGetAttrBN(IfcRelAssociatesMaterialInstance, "RelatedObjects", IfcEngine.sdaiAGGR, out ObjectInstances);
                    Int64 NumObject = IfcEngine.sdaiGetMemberCount(ObjectInstances);
                    bool flag = false; // is the exact building element?
                    if (NumObject != 0)
                    {
                        for (int j = 0; j < NumObject; j++)
                        {
                            Int64 Object = 0;
                            IfcEngine.engiGetAggrElement(ObjectInstances, j, IfcEngine.sdaiINSTANCE, out Object);

                            IntPtr IdPtr = IntPtr.Zero;
                            IfcEngine.sdaiGetAttrBN(Object, "GlobalId", IfcEngine.sdaiUNICODE, out IdPtr);
                            String ObjectGlobalID = Marshal.PtrToStringUni(IdPtr);

                            if (ObjectGlobalID == BuildingElememntGlobalID)
                            {
                                flag = true;
                                _IfcRelAssociatesMaterial.RelatedObjectGlobalIDs.Add(ObjectGlobalID);

                                // Extract material thickness
                                // IfcMaterialSelect includes: 
                                // -- IfcMaterial: only contains the material name; the lowest level
                                // -- IfcMaterialList: normally be used where an element is described at a more abstract level, namely only list what materials (a list of Ifcmaterial) are used 
                                // -- IfcMaterialLayer； single layer material including thisckness and the name of material (ifcmaterial) 
                                // -- IfcMaterialLayerSet: A designation by which materials of an element constructed of a number of material layers is known and through which the relative positioning of individual layers can be expressed.
                                // -- IfcMaterialLayerSetUsage: Determines the usage of IfcMaterialLayerSet in terms of its location and orientation relative to the associated element geometry.
                                // In concept Deign BIM 2010：for the building element, the materials shoyuld be: ifcrelassociatesmaterial - ifcmateriallayersetusage - ifcmaterialrayerset-- ifcmaterialrayer -- ifcmaterial
                                Int64 MaterialSelect = IfcEngine.sdaiGetEntity(IfcModel, "IfcMaterialLayerSetUsage");
                                Int64 RelatingMaterialInstance = 0;
                                IfcEngine.sdaiGetAttrBN(IfcRelAssociatesMaterialInstance, "RelatingMaterial", IfcEngine.sdaiINSTANCE, out RelatingMaterialInstance);
                                Int64 RelatingMaterialType = IfcEngine.sdaiGetInstanceType(RelatingMaterialInstance);
                                if (RelatingMaterialType == MaterialSelect)  // the default path in CDB2010 is used； maybe the warning function is required.
                                {
                                    Int64 IfcMaterialLayerSetInstance = 0;
                                    IfcEngine.sdaiGetAttrBN(RelatingMaterialInstance, "ForLayerSet", IfcEngine.sdaiINSTANCE, out IfcMaterialLayerSetInstance);

                                    Int64 MaterialLayerInstances = 0;
                                    IfcEngine.sdaiGetAttrBN(IfcMaterialLayerSetInstance, "MaterialLayers", IfcEngine.sdaiAGGR, out MaterialLayerInstances);

                                    Int64 NumLayers = IfcEngine.sdaiGetMemberCount(MaterialLayerInstances);
                                    double totalthickness = 0;
                                    if (NumLayers != 0)
                                    {
                                        for (int k = 0; k < NumLayers; k++)
                                        {
                                            Int64 Layer = 0;
                                            IfcEngine.engiGetAggrElement(MaterialLayerInstances, k, IfcEngine.sdaiINSTANCE, out Layer);
                                            double thickness = 0;
                                            IfcEngine.sdaiGetAttrBN(Layer, "LayerThickness", IfcEngine.sdaiREAL, out thickness);
                                            totalthickness += thickness;
                                        }
                                    }
                                    _IfcRelAssociatesMaterial.RelatingMaterialThickness = totalthickness;
                                } 
                            }
                            if (flag)
                                break;
                        }
                    }
                    if (flag)
                        break;
                }              
            }
            return _IfcRelAssociatesMaterial;
        }

        public List<IfcRelAssociatesMaterial> ExtractAllAssociatesMaterials(Int64 IfcModel)
        {
            List<IfcRelAssociatesMaterial> Materials = new List<IfcRelAssociatesMaterial>();

            Int64 IfcRelAssociatesMaterialInstances = IfcEngine.sdaiGetEntityExtentBN(IfcModel, "IfcRelAssociatesMaterial");
            Int64 NumInstances = IfcEngine.sdaiGetMemberCount(IfcRelAssociatesMaterialInstances);

            if (NumInstances != 0)
            {
                for (int i = 0; i < NumInstances; i++)
                {
                    IfcRelAssociatesMaterial _IfcRelAssociatesMaterial = new IfcRelAssociatesMaterial();
                    Int64 IfcRelAssociatesMaterialInstance = 0;
                    IfcEngine.engiGetAggrElement(IfcRelAssociatesMaterialInstances, i, IfcEngine.sdaiINSTANCE, out IfcRelAssociatesMaterialInstance);

                    // Extract GlobalID
                    IntPtr GlobalIdPtr = IntPtr.Zero;
                    IfcEngine.sdaiGetAttrBN(IfcRelAssociatesMaterialInstance, "GlobalId", IfcEngine.sdaiUNICODE, out GlobalIdPtr);
                    _IfcRelAssociatesMaterial.GlobalID = Marshal.PtrToStringUni(GlobalIdPtr);

                    // Exteact related objects IDs
                    Int64 ObjectInstances = 0;
                    IfcEngine.sdaiGetAttrBN(IfcRelAssociatesMaterialInstance, "RelatedObjects", IfcEngine.sdaiAGGR, out ObjectInstances);
                    Int64 NumObject = IfcEngine.sdaiGetMemberCount(ObjectInstances);
                    if (NumObject != 0)
                    {
                        for (int j = 0; j < NumObject; j++)
                        {
                            Int64 Object = 0;
                            IfcEngine.engiGetAggrElement(ObjectInstances, j, IfcEngine.sdaiINSTANCE, out Object);

                            IntPtr IdPtr = IntPtr.Zero;
                            IfcEngine.sdaiGetAttrBN(Object, "GlobalId", IfcEngine.sdaiUNICODE, out IdPtr);
                            _IfcRelAssociatesMaterial.RelatedObjectGlobalIDs.Add(Marshal.PtrToStringUni(IdPtr));
                        }
                    }

                    // Extract material thickness
                    // IfcMaterialSelect includes: 
                    // -- IfcMaterial: only contains the material name; the lowest level
                    // -- IfcMaterialList: normally be used where an element is described at a more abstract level, namely only list what materials (a list of Ifcmaterial) are used 
                    // -- IfcMaterialLayer； single layer material including thisckness and the name of material (ifcmaterial) 
                    // -- IfcMaterialLayerSet: A designation by which materials of an element constructed of a number of material layers is known and through which the relative positioning of individual layers can be expressed.
                    // -- IfcMaterialLayerSetUsage: Determines the usage of IfcMaterialLayerSet in terms of its location and orientation relative to the associated element geometry.
                    // In concept Deign BIM 2010：for the building element, the materials shoyuld be: ifcrelassociatesmaterial - ifcmateriallayersetusage - ifcmaterialrayerset-- ifcmaterialrayer -- ifcmaterial
                    Int64 MaterialSelect = IfcEngine.sdaiGetEntity(IfcModel, "IfcMaterialLayerSetUsage");
                    Int64 RelatingMaterialInstance = 0;
                    IfcEngine.sdaiGetAttrBN(IfcRelAssociatesMaterialInstance, "RelatingMaterial", IfcEngine.sdaiINSTANCE, out RelatingMaterialInstance);
                    Int64 RelatingMaterialType = IfcEngine.sdaiGetInstanceType(RelatingMaterialInstance);
                    if (RelatingMaterialType == MaterialSelect)
                    {
                        Int64 IfcMaterialLayerSetInstance = 0;
                        IfcEngine.sdaiGetAttrBN(RelatingMaterialInstance, "ForLayerSet", IfcEngine.sdaiINSTANCE, out IfcMaterialLayerSetInstance);

                        Int64 MaterialLayerInstances = 0;
                        IfcEngine.sdaiGetAttrBN(IfcMaterialLayerSetInstance, "MaterialLayers", IfcEngine.sdaiAGGR, out MaterialLayerInstances);

                        Int64 NumLayers = IfcEngine.sdaiGetMemberCount(MaterialLayerInstances);
                        double totalthickness = 0;
                        if (NumLayers != 0)
                        {
                            for (int k = 0; k < NumLayers; k++)
                            {
                                Int64 Layer = 0;
                                IfcEngine.engiGetAggrElement(MaterialLayerInstances, k, IfcEngine.sdaiINSTANCE, out Layer);
                                double thickness = 0;
                                IfcEngine.sdaiGetAttrBN(Layer, "LayerThickness", IfcEngine.sdaiREAL, out thickness);
                                totalthickness += thickness;
                            }
                        }
                        _IfcRelAssociatesMaterial.RelatingMaterialThickness = totalthickness;
                    }
                    Materials.Add(_IfcRelAssociatesMaterial);
                }
            }
            return Materials;
        }

    }
}
