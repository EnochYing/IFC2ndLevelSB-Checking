﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using SharpDX.Direct3D9;
using System.Runtime.InteropServices;
using System.Windows.Forms;


namespace SecondLevelSBValidation
{
    // Ifc file parse 
    // Extract IfcProject, IfcSite, IfcBuilding, IfcBuildingStorey, IfcSpace, IfcRelSpaceBoundary
    //     and create their hierarchical relationships and stored as IfcItems
    public class IfcModel
    {
        public Int64 ifcModel = 0;
        public string SchemaName;
        public IfcItem RootIfcItem = null; // root of the IfcModel; as long as the relationhships between ifcitems have been created, the root item can represent the whole tree
        public List<IfcItem> Geometry = new List<IfcItem>(); // a collection of IfcItems that have geometry representations

        public IfcMaterialsBuilder MaterialsBuilder = null;
        public Dictionary<Material, List<KeyValuePair<IfcItem, STRUCT_MATERIALS>>> FacesGroups = new Dictionary<Material, List<KeyValuePair<IfcItem, STRUCT_MATERIALS>>>();

        public event EventHandler ModelLoaded;
        private void FireModelLoaded()
        {
            if (ModelLoaded != null)
            {
                ModelLoaded(this, new EventArgs());
            }
        }

        #region Explanation of get/set method
        //private List<IfcItem> _lsGeometry = new List<IfcItem>();  // this property can be only processed in this class not external class
        //public List<IfcItem> Geometry   // by this get method, external class/method can only read the property _IsGeometry by Geometry property; 实现封装。 
        //{                               // 甚至 还可以设计一个函数给return语句中
        //    get
        //    {
        //        return _lsGeometry;
        //    }
        //}
        #endregion

        // Load an IFC model: 
        // 1. create an IFC structure/items tree (only IFC Instances not include specific properties); 
        // 2. extract relevant geometries and associate geometries with relevant materials for visualization
        public bool IfcModelLoad(string IfcFilePath)
        {
            if (!File.Exists(IfcFilePath))
                return false;

            #region Automatically detect the schema version of the input IFC File and open the file

            ifcModel = IfcEngine.sdaiOpenModelBNUnicode(0, Encoding.Unicode.GetBytes(IfcFilePath), null);
            if (ifcModel == 0)
                MessageBox.Show("Warning: Please input an IFC file");

            string strExpFile = null;

            IntPtr outputValue = IntPtr.Zero;
            IfcEngine.GetSPFFHeaderItem(ifcModel, 9, 0, IfcEngine.sdaiUNICODE, out outputValue);
            string strVersion = Marshal.PtrToStringUni(outputValue);

            IfcEngine.sdaiCloseModel(ifcModel);
            ifcModel = 0;

            if (strVersion.Contains("IFC2"))
            {
                strExpFile += "IFC2X3_TC1.exp";

                ifcModel = IfcEngine.sdaiOpenModelBNUnicode(0, Encoding.Unicode.GetBytes(IfcFilePath), Encoding.Unicode.GetBytes(strExpFile));
            }
            else
            {
                if (strVersion.Contains("IFC4x") || strVersion.Contains("IFC4X"))
                {
                    strExpFile += "IFC4x1_FINAL.exp";
                    ifcModel = IfcEngine.sdaiOpenModelBNUnicode(0, Encoding.Unicode.GetBytes(IfcFilePath), Encoding.Unicode.GetBytes(strExpFile));
                }
                else
                {
                    if (strVersion.Contains("IFC4") ||
                        strVersion.Contains("IFC2x4") ||
                        strVersion.Contains("IFC2X4"))
                    {
                        strExpFile += "IFC4_ADD2.exp";
                        ifcModel = IfcEngine.sdaiOpenModelBNUnicode(0, Encoding.Unicode.GetBytes(IfcFilePath), Encoding.Unicode.GetBytes(strExpFile));
                    }
                }
            }

            this.SchemaName = strExpFile;

            if (ifcModel == 0)
                MessageBox.Show("Warning: Please input an IFC file");
            #endregion

            if (ifcModel == 0)
                return false;
            else
            {           
                // retrieve required objects from an Ifc file and represent them as a tree
                // Tree level: IfcProject, IfcSite, IfcBuilding, IfcBuildingStorey, IfcSpace (including geometries), IfcRelSpaceBoundary (inlcuding properties and geometries) 
                List<string> TreeObjects = new List<string>();
                TreeObjects.Add("IfcProject");
                TreeObjects.Add("IfcSite");
                TreeObjects.Add("IfcExternalSpatialElement");
                TreeObjects.Add("IfcBuilding");
                TreeObjects.Add("IfcBuildingStorey");
                TreeObjects.Add("IfcSpace");
                TreeObjects.Add("IfcRelSpaceBoundary2ndLevel");
                TreeObjects.Add("IfcRelSpaceBoundary");

                // 1. create an IFC structure/items tree;
                for (int i = 0; i < TreeObjects.Count; i++)
                {
                    RetrieveObjects(ifcModel, TreeObjects[i]);
                }

                // 2. Extract each IfcItem's geometry and relevant materials (IfcStyledItem) for visualization
                // 3D solid geometries: IfcProject, IfcSite, IfcBuilding, IfcBuildingStorey, IfcSpace
                // 3D surface geometries: IfcRelSpaceBoundary
                MaterialsBuilder = new IfcMaterialsBuilder(ifcModel); // set default value (IfcMaterialsBuilder._defaultMaterial)
                GenerateGeometry(ifcModel, RootIfcItem); // extract geometry as well as material for visualization (defined in Ifc Model)

                // reorganize parameters of extracted materials that are to be used by the requirements of SharpDX.Material
                // the obtained IfcMaterialsBuilder.Materials is just a list of materials (involved by IfcItems) whose parameters is defined a SharpDX.Material
                MaterialsBuilder.finalizeMaterials();

                // Group IfcItems with involved IfcMaterialsBuilder.Materials (SharpDX.Material); use it as the key value as it is unique
                if (MaterialsBuilder != null)
                {
                    // general objects
                    for (int iMaterial = 0; iMaterial < MaterialsBuilder.Materials.Count; iMaterial++)
                    {
                        List<KeyValuePair<IfcItem, STRUCT_MATERIALS>> lsFaces = new List<KeyValuePair<IfcItem, STRUCT_MATERIALS>>();
                        // KeyValuePair:键值对, 一对一的数据类型, 为Dictionary(字典)的基本单元
                        #region  遍历                        
                        //Dictionary<string, string> dic = new Dictionary<string, string>();
                        //dic.Add("Name", "puma");
                        //dic.Add("Blog", "F6 Team");
                        //dic.Add("Group", "Dotblogs");
                        //foreach (KeyValuePair<string, string> item in dic)
                        //{
                        //    Console.Write(string.Format("{0} : {1}<br/" + ">", item.Key, item.Value));
                        //}
                        #endregion
                        for (int iItem = 0; iItem < Geometry.Count; iItem++)
                        {
                            STRUCT_MATERIALS materials = Geometry[iItem].materials;
                            while (materials != null)
                            {
                                if (materials.material.MTRL.Equals(MaterialsBuilder.Materials[iMaterial]))
                                {
                                    lsFaces.Add(new KeyValuePair<IfcItem, STRUCT_MATERIALS>(Geometry[iItem], materials)); // other information stored in materials are needed
                                }
                                materials = materials.next;
                            }
                        }
                        FacesGroups[MaterialsBuilder.Materials[iMaterial]] = lsFaces;  // Dictionary 赋值方法:(1) .add(key,value); (2) Dict[key] = value. 
                    }
                }
             
                FireModelLoaded();
                //IfcEngine.sdaiCloseModel(ifcModel);
                return true;
            }
        }

        // generate geometries for all the extracted Ifc objects and IfcRelSpaceBoundary
        private void GenerateGeometry(Int64 IfcModel, IfcItem ifcItem)
        {
            while (ifcItem != null)
            {
                #region test 
                //if (IfcEngine.sdaiGetInstanceType(ifcItem.instance) == IfcEngine.sdaiGetEntity(IfcModel, "IFCRELSPACEBOUNDARY"))
                //{
                //    RetrieveGeometry(ifcModel, ifcItem);
                //    IfcEngine.cleanMemory(ifcModel, 0);  //????
                //    GenerateGeometry(ifcModel, ifcItem.child);
                //}
                #endregion

                RetrieveGeometry(ifcModel, ifcItem);
                IfcEngine.cleanMemory(ifcModel, 0); 
                GenerateGeometry(ifcModel, ifcItem.child);
                ifcItem = ifcItem.next;
            } 
        }

        // Retrieve the geometry
        // applicable to 3D soild geometries as well as 3D surface geometries (space boundary)
        private void RetrieveGeometry(Int64 ifcModel, IfcItem ifcItem)
        {
            if (ifcItem.instance == 0)     
                return;        
            SetFormat(ifcModel);

            Int64 iVerticesCount = 0; // number of vertices (vertices with same coordinates are distinguished by their normal)
            Int64 iIndicesCount = 0;  // number of vertices that are used for forming triangles
            IfcEngine.initializeModellingInstance(ifcModel, ref iVerticesCount, ref iIndicesCount, 0, ifcItem.instance); // calculate the needed storage room 

            if ((iVerticesCount == 0) || (iIndicesCount == 0))
                return;

            ifcItem.verticesCount = iVerticesCount; 
            ifcItem.vertices = new float[6 * iVerticesCount]; // store the vertices: a vertex is defined by coordinates as well as normal
            int[] indices = new int[iIndicesCount]; // triangles

            IfcEngine.finalizeModelling(ifcModel, ifcItem.vertices, indices, 0);  // generate triangulated geometry represntation (face sets)
   
            List<int> lsFacesIndices = new List<int>(); // a rectangular face has two triangles; each triangle have three points; all the vertices are stored in order by triangles; each tree adjacent indices representing a triangle
            List<int> lsWireframesIndices = new List<int>(); // a rectangular face has four edges; each edge have two ednpoints; all the vertices are stored in order by line segments (joined end-to-end); each two adjacent indices represeting an edge

            Int64 iFacesCount = IfcEngine.getConceptualFaceCnt(ifcItem.instance); // completed planar surfaces; not the triangulated surfaces
            for (Int64 iFace = 0; iFace < iFacesCount; iFace++)
            {
                Int64 iStartIndexTriangles = 0;  // start index of the triangles of the face
                Int64 iIndicesCountTriangles = 0; // numer of index of triangles of the face

                Int64 iStartIndexFacesPolygons = 0;
                Int64 iIndicesCountFacesPolygons = 0;

                Int64 iValue = 0;  
                IfcEngine.getConceptualFaceEx(ifcItem.instance,
                    iFace,
                    ref iStartIndexTriangles,  // triangles (rendering) for surface model use
                    ref iIndicesCountTriangles,
                    ref iValue,
                    ref iValue,
                    ref iValue,
                    ref iValue,
                    ref iStartIndexFacesPolygons, // polygons (explicit edges) for wireframe model use 
                    ref iIndicesCountFacesPolygons,
                    ref iValue, //start index conceptual face polygon
                    ref iValue); // number of index conceptual face polygon

                // Polygonal face based visualization: just extract the indices of the vertices for each face
                // Triangular faces: see IfcTriangulatedFaceSet
                for (Int64 iIndexTriangles = iStartIndexTriangles; iIndexTriangles < iStartIndexTriangles + iIndicesCountTriangles; iIndexTriangles++)
                {
                    lsFacesIndices.Add(indices[iIndexTriangles]);  // store all the triangles(their vertices) by the order of faces
                }

                // Wireframe model visulazation: just extract the indices of the vertices for each line
                Int64 iIndexWireframes = 0;
                int iLastIndex = -1;
                while (iIndexWireframes < iIndicesCountFacesPolygons) // iIndicesCountFacesPolygons stores all indices corresponding to the vertices (not each face polygon) of all the face polygon; store all the line segments (each has two endpoints) by polygons
                {
                    if ((iLastIndex >= 0) && (indices[iStartIndexFacesPolygons + iIndexWireframes] >= 0))
                    {
                        lsWireframesIndices.Add(iLastIndex);
                        lsWireframesIndices.Add(indices[iStartIndexFacesPolygons + iIndexWireframes]);
                    }

                    iLastIndex = indices[iStartIndexFacesPolygons + iIndexWireframes];
                    iIndexWireframes++;
                }
            } 

            ifcItem.indicesForFaces = lsFacesIndices.ToArray();  
            ifcItem.indicesForWireFrameLineParts = lsWireframesIndices.ToArray();

            // extract materials used for visualization (defined in the IfcModel by IfcStyledItem)
            // this method only used for physical elements with 3D precise solid geometry (Body, mesh, facetation); even bounding box is not applicable
            // Override for objetcs without materials: IfcSpace --- defalut material: Visualization in green for face model; space boundary ---- purple-door; blue-window; lighter dark-physical elements; red-virtual element        
            ifcItem.materials = MaterialsBuilder.extractMaterials(ifcItem.instance);
            Geometry.Add(ifcItem); 
        }

        // set geometry generation format
        private void SetFormat(Int64 IfcModel)
        {
            Int64 mask = 0;
            mask += IfcEngine.flagbit2;        // PRECISION (32/64 bit)
            mask += IfcEngine.flagbit3;        // INDEX ARRAY (32/64 bit)
            mask += IfcEngine.flagbit5;        // NORMALS
            mask += IfcEngine.flagbit8;        // TRIANGLES
            mask += IfcEngine.flagbit12;       // WIREFRAME

            Int64 setting = 0;
            setting += 0;                             // SINGLE PRECISION (float)
            //  - IndexBuffer() doesn't support 64 bits
            //setting += IfcEngine.x86.flagbit3;      // 64 BIT INDEX ARRAY (Int64)
            setting += IfcEngine.flagbit5;     // NORMALS ON
            setting += IfcEngine.flagbit8;     // TRIANGLES ON
            setting += IfcEngine.flagbit12;    // WIREFRAME ON
            IfcEngine.setFormat(IfcModel, setting, mask);
        }

        // retrieve ifcitems from the loaded IfcModel and represent them as a "tree"
        private void RetrieveObjects(Int64 IfcModel, string ObjectType)
        {
            Int64 IfcObjectInstances = IfcEngine.sdaiGetEntityExtentBN(IfcModel, ObjectType);
            Int64 Num_IfcObjectIntances = IfcEngine.sdaiGetMemberCount(IfcObjectInstances);

            if (Num_IfcObjectIntances != 0)
            {
                IfcItem NewItem = null; // Create a null NewItem (node) for a type of IFC instances
                if (RootIfcItem == null)
                {
                    RootIfcItem = new IfcItem();
                    RootIfcItem.CreateItem(null, 0, "");
                    NewItem = RootIfcItem;
                }
                else
                {
                    IfcItem LastItem = RootIfcItem; // insert the NewItem into the created whole tree   
                    while (LastItem != null)
                    {
                        if (LastItem.next == null)
                        {
                            LastItem.next = new IfcItem();
                            LastItem.next.CreateItem(null, 0, "");
                            NewItem = LastItem.next;
                            break;
                        }
                        else
                            LastItem = LastItem.next;
                    }
                }

                // add all IFC instances under the NewItem
                for (Int64 i = 0; i < Num_IfcObjectIntances; i++)
                {
                    Int64 IfcObjectInstance = 0;
                    IfcEngine.engiGetAggrElement(IfcObjectInstances, i, IfcEngine.sdaiINSTANCE, out IfcObjectInstance);
                    IfcItem subItem = new IfcItem();
                    subItem.CreateItem(NewItem, IfcObjectInstance, ObjectType);
                }
            }
        }

        private bool IsInstanceOf(Int64 iInstance, string strType)
        {
            if (IfcEngine.sdaiGetInstanceType(iInstance) == IfcEngine.sdaiGetEntity(ifcModel, strType))
            {
                return true;
            }

            return false;
        }
    }
}
