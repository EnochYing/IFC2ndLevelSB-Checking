﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;


namespace SecondLevelSBValidation
{
    public class IfcSIUnit
    {
        public string UnitType;
        public bool IsLenghthUnit;
        public string Prefix;
        public string Name;

        public IfcSIUnit(Int64 IfcSIUnitInstance)
        {
            IntPtr UnitTypePtr = IntPtr.Zero;
            IfcEngine.sdaiGetAttrBN(IfcSIUnitInstance, "UnitType", IfcEngine.sdaiUNICODE, out UnitTypePtr);
            this.UnitType = Marshal.PtrToStringUni(UnitTypePtr);

            if (this.UnitType == ".LENGTHUNIT.")
                IsLenghthUnit= true;
            else
                IsLenghthUnit= false;

            IntPtr PrefixPtr = IntPtr.Zero;
            IfcEngine.sdaiGetAttrBN(IfcSIUnitInstance, "Prefix", IfcEngine.sdaiUNICODE, out PrefixPtr);
            this.Prefix = Marshal.PtrToStringUni(PrefixPtr);
    
            IntPtr NamePtr = IntPtr.Zero;
            IfcEngine.sdaiGetAttrBN(IfcSIUnitInstance, "Name", IfcEngine.sdaiUNICODE, out NamePtr); // shoud be always METER for LengthUnit type
            this.Name = Marshal.PtrToStringUni(NamePtr);      
        }    
    }
}
