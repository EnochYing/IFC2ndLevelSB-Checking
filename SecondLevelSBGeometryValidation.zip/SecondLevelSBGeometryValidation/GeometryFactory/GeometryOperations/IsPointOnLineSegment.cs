﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecondLevelSBValidation
{
    public class IsPointOnLineSegment
    {
        public bool Result = false;

        public IsPointOnLineSegment(Point3D point, LineSegment3D lineSegment)
        {
            Vector3D vector = new Vector3D();
            Vector3D start_point = vector.VectorConstructor(lineSegment.StartPoint, point);
            Vector3D point_end = vector.VectorConstructor(point, lineSegment.EndPoint);

            bool sameDirection = vector.IsSameDirection(start_point, point_end);  // involve the vector angle which is to sensitive

            if (sameDirection)
                Result = true;
            else
                Result = false;
        }
    }
}
