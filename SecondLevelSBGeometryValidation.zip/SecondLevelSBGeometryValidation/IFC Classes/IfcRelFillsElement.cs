﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;

namespace SecondLevelSBValidation
{
  public class IfcRelFillsElement
    {
        public Int64 Pointer;
        public string GlobalID;
        public string RelatingOpeningElementGlobalID;
        public string RelatedBuildingElementType;

        public List<IfcRelFillsElement> ExtractIFCRelFillsElement (Int64 IFCModel)
        {
            List<IfcRelFillsElement> IfcRelFillsElements = new List<IfcRelFillsElement>();
            Int64 Relatedwindow_type = IfcEngine.sdaiGetEntity(IFCModel, "IfcWindow");
            Int64 RelatedDoor_type = IfcEngine.sdaiGetEntity(IFCModel, "IfcDoor");

            Int64 IFCRelFillsElementInstances = IfcEngine.sdaiGetEntityExtentBN(IFCModel, "IfcRelFillsElement");
            Int64 NumIFCRelFillsElementInstances = IfcEngine.sdaiGetMemberCount(IFCRelFillsElementInstances);
            if (NumIFCRelFillsElementInstances != 0)
            {
                for (Int64 i = 0; i < NumIFCRelFillsElementInstances; i++)
                {
                    IfcRelFillsElement _IFCRelFillsElement = new IfcRelFillsElement();  
                    Int64 IFCRelFillsElementInstance = 0;
                    IfcEngine.engiGetAggrElement(IFCRelFillsElementInstances, i, IfcEngine.sdaiINSTANCE, out IFCRelFillsElementInstance);
                    _IFCRelFillsElement.Pointer = IFCRelFillsElementInstance;

                   // extract the GlobalID
                    IntPtr GlobalIdPtr = IntPtr.Zero;
                    IfcEngine.sdaiGetAttrBN(IFCRelFillsElementInstance, "GlobalId", IfcEngine.sdaiUNICODE, out GlobalIdPtr);
                    _IFCRelFillsElement.GlobalID = Marshal.PtrToStringUni(GlobalIdPtr);

                    // relatingopeningelement GlobalID
                    Int64 IfcOpeningElementInstance = 0;
                    IfcEngine.sdaiGetAttrBN(IFCRelFillsElementInstance, "RelatingOpeningElement", IfcEngine.sdaiINSTANCE, out IfcOpeningElementInstance);
                    IntPtr RelatingOpeningElementGlobalIDPtr = IntPtr.Zero;
                    IfcEngine.sdaiGetAttrBN(IfcOpeningElementInstance, "GlobalID", IfcEngine.sdaiUNICODE, out RelatingOpeningElementGlobalIDPtr);
                    _IFCRelFillsElement.RelatingOpeningElementGlobalID = Marshal.PtrToStringUni(RelatingOpeningElementGlobalIDPtr);

                    // related building element type
                    Int64 IfcBuildingElementInstance = 0;
                    IfcEngine.sdaiGetAttrBN(IFCRelFillsElementInstance, "RelatedBuildingElement", IfcEngine.sdaiINSTANCE, out IfcBuildingElementInstance);
                    Int64 ElementType = IfcEngine.sdaiGetInstanceType(IfcBuildingElementInstance);
                    if (ElementType == Relatedwindow_type)
                    {
                        _IFCRelFillsElement.RelatedBuildingElementType = "IFCWINDOW";
                    }
                    else if (ElementType == RelatedDoor_type)
                    {
                        _IFCRelFillsElement.RelatedBuildingElementType = "IFCDOOR";
                    }
                    else 
                    {
                        _IFCRelFillsElement.RelatedBuildingElementType = "OTHERS";
                    }
                    IfcRelFillsElements.Add(_IFCRelFillsElement);
                }
            }
            return IfcRelFillsElements;
        }
    }
}
