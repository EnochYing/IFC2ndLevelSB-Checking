﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecondLevelSBValidation
{
    public class IsCoplanarPolygon
    {
        public bool Result;

        // Two polygons MUST be planar and defined as a 3D polyline
        // Two polygons surface normal can be adverse
        public IsCoplanarPolygon(Polyline3D surface_A, Polyline3D surface_B, double toleracneScale)
        {            
            Vector3D vector = new Vector3D();
            Vector3D Normal_A = vector.UnitVector(surface_A.SurfaceNormal);
            Vector3D Normal_B = vector.UnitVector(surface_B.SurfaceNormal);
            double dot = vector.DotProduct(Normal_A, Normal_B);

            if ((1- Math.Abs(dot)) < ConstantValue.SmallValue) // tolerance setting      
                dot = 1;

            if (dot != 1)
                Result = false;
            else
            {
                Point3D point = new Point3D();
                Vector3D vector_1 = new Vector3D();
                for (int i = 0; i < surface_B.Vertices.Count; i++)
                {
                    if (!point.IsSamePoint(surface_A.Vertices[0], surface_B.Vertices[i], toleracneScale))
                    {
                        vector_1 = vector.VectorConstructor(surface_A.Vertices[0], surface_B.Vertices[i]);
                        break;
                    }
                }

                vector_1 = vector.UnitVector(vector_1);
                double dot_1 = vector.DotProduct(vector_1, Normal_B);

                if ( Math.Abs(dot_1) < ConstantValue.SmallValue) // tolerance setting      
                    dot_1 = 0;
                               
                if (dot_1 == 0)
                    Result = true;
                else
                    Result = false;
            }
        }
    }
}
