﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace SecondLevelSBValidation
{
    public class BoundingBox_Triangle_do_intersect
    {
        // Bounding box - triangle intersection test: topological relationship detection
        // Separating axis theorem based method developed by Tomas Akenine-M¨oller(2001) in "Fast 3D Triangle-Box Overlap Testing"

        public bool Test(BoundingBox3D BBox, Triangle3D Triangle)
        {
            // transform the AABB representation as a form of center and half length and take the center as the origin of the CS
            Vector3D AABBCenter = new Vector3D();
            AABBCenter.x = (BBox.xmin + BBox.xmax) / 2;
            AABBCenter.y = (BBox.ymin + BBox.ymax) / 2;
            AABBCenter.z = (BBox.zmin + BBox.zmax) / 2;

            double[] AABBCenterL = new double[] { (BBox.xmax - BBox.xmin) / 2, (BBox.ymax - BBox.ymin) / 2, (BBox.zmax - BBox.zmin) / 2 };

            // move the triangle to the LCS of AABB
            Vector3D Vector = new Vector3D();
            TriangleVector _triangle = new TriangleVector();
            _triangle.Vertex1.x = Triangle.Vertex1.x - AABBCenter.x;
            _triangle.Vertex1.y = Triangle.Vertex1.y - AABBCenter.y;
            _triangle.Vertex1.z = Triangle.Vertex1.z - AABBCenter.z;

            _triangle.Vertex2.x = Triangle.Vertex2.x - AABBCenter.x;
            _triangle.Vertex2.y = Triangle.Vertex2.y - AABBCenter.y;
            _triangle.Vertex2.z = Triangle.Vertex2.z - AABBCenter.z;

            _triangle.Vertex3.x = Triangle.Vertex3.x - AABBCenter.x;
            _triangle.Vertex3.y = Triangle.Vertex3.y - AABBCenter.y;
            _triangle.Vertex3.z = Triangle.Vertex3.z - AABBCenter.z;
            Vector3D[] trianglevertices = new Vector3D[] { _triangle.Vertex1, _triangle.Vertex2, _triangle.Vertex3 };

            // compute the edge vectors of the triangle
            Vector3D f1 = Vector.Subtraction(_triangle.Vertex1, _triangle.Vertex2);
            Vector3D f2 = Vector.Subtraction(_triangle.Vertex2, _triangle.Vertex3);
            Vector3D f3 = Vector.Subtraction(_triangle.Vertex3, _triangle.Vertex1);
            Vector3D[] triangleedgevectors = new Vector3D[] { f1, f1, f3 };

            // compute the normal vector of the triangle
            _triangle.NormalVector = Vector.UnitVector(Vector.CrossProduct(f1, f2));

            // 3 AABB surface normal tests: axis (1,0,0); axis (0,1,0); axis (0,0,1)
            Vector3D[] BoxNormals = new Vector3D[]
                      { Vector.NewVector(1, 0, 0), Vector.NewVector(0, 1, 0), Vector.NewVector(0, 0, 1) };

            for (int i = 0; i < 3; i++)
            {
                // project the triangle vertex on the axis--the axis direction MUST be a unit vector
                List<double> Ps = new List<double>();
                for (int j = 0; j < 3; j++)
                {
                    double P = Vector.DotProduct(trianglevertices[j], BoxNormals[i]);
                    Ps.Add(P);
                }
                double PMax = Ps.Max();
                double PMin = Ps.Min();
                double r0 = AABBCenterL[0] * Math.Abs(BoxNormals[i].x) + AABBCenterL[1] * Math.Abs(BoxNormals[i].y) + AABBCenterL[2] * Math.Abs(BoxNormals[i].z);

                if (PMax < r0 * (-1) || PMin > r0)
                {
                    return false;
                }
            }

            // Triangle normal test          
            double Pt = Vector.DotProduct(_triangle.NormalVector, _triangle.Vertex1); // project triangle vertices onto its normal vector --- all three are the same
            double r = AABBCenterL[0] * Math.Abs(_triangle.NormalVector.x) + AABBCenterL[1] * Math.Abs(_triangle.NormalVector.y) + AABBCenterL[2] * Math.Abs(_triangle.NormalVector.z);  // project the box vertices on the normal vector
            if (Pt > r || Pt < (-1) * r)
            {
                return false;
            }

            // 9 triangle edges - box surface normal tests
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Vector3D V = Vector.UnitVector(Vector.CrossProduct(BoxNormals[i], triangleedgevectors[j]));
                    double r1 = AABBCenterL[0] * Math.Abs(V.x) + AABBCenterL[1] * Math.Abs(V.y) + AABBCenterL[2] * Math.Abs(V.z);
                    List<double> L = new List<double>();
                    double p0 = Vector.DotProduct(V, _triangle.Vertex1);
                    L.Add(p0);
                    double p1 = Vector.DotProduct(V, _triangle.Vertex2);
                    L.Add(p1);
                    double p2 = Vector.DotProduct(V, _triangle.Vertex3);
                    L.Add(p2);

                    if (L.Min() > r1 || L.Max() < (-1) * r1)
                    {
                        return false;
                    }
                }
            }
            return true;
        }
    }
}
