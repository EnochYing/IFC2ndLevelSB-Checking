namespace GeoAPI.Geometries
{
    /// <summary>
    /// Interface for surfaces
    /// </summary>
    public interface ISurface : IGeometry
    { }
}
