﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecondLevelSBValidation
{
    public class IfcSite
    {
        public Int64 Instance = 0;
        public IfcFacetedBrep GlobalBrep = null;

        public IfcSite(Int64 IfcModel, Int64 Instance)
        {
            this.Instance = Instance;
            this.GlobalBrep = new IfcFacetedBrep(IfcModel, Instance);

            // Extract placement information
            Int64 IfcLocalPlacementInstance = 0;
            IfcEngine.sdaiGetAttrBN(Instance, "ObjectPlacement", IfcEngine.sdaiINSTANCE, out IfcLocalPlacementInstance);
            IfcLocalPlacement Placement = new IfcLocalPlacement(IfcLocalPlacementInstance);

            InverseMatrix IM = new InverseMatrix();
            this.GlobalBrep.TM_GCS_LCS = IM.IMatrix_Matrix(Placement.TransforMatrixToRoot);
        }
    }
}
