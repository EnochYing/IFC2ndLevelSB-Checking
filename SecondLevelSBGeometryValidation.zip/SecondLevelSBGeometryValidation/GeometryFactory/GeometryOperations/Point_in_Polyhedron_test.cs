﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecondLevelSBValidation
{
    public class Point_in_Polyhedron_test  
    {
        // Uisng Ray-casting point-in-polyhedron test algorithm
        // Polyhedron Must be represeted as triangulated Brep --- List<Triangle3D>  here
        // Generally, the direction of ray to be created can be arbitrary;
        // but here a specifc port is provided for other algorithm use
        // odd-even rule: can be proved by Jordan curve theorem
        // Special case 1: point on the face of the polyhedron ????????
        // Special case 2； rounding errors -- point is very close to the faces of polyhedron
        public bool Result = false;

        public Point_in_Polyhedron_test(Point3D Point, Vector3D Direction, List<Triangle3D> TriangulatedPolyhedron, double toleranceScale)
        {
            int Num = TriangulatedPolyhedron.Count;
            int Num_intersectionPoint = 0;
            Ray3D ray = new Ray3D();
            ray.StartPoint = Point;
            ray.Direction = Direction;

            #region
            //for (int i = 0; i < Num; i++)
            //{
            //    Ray3D_Triangle3D_do_Intersection ray_triangle_test = new Ray3D_Triangle3D_do_Intersection(ray, TriangulatedPolyhedron[i]);
            //    if (ray_triangle_test.Intersection)
            //    {
            //        Num_intersectionPoint += 1;
            //    }
            //}
            #endregion

            // Special case processing: intersection points are located on the edges shared by two triangle surfaces
            // Remove same intersection points
            List<Point3D> points = new List<Point3D>();
            for (int i = 0; i < Num; i++)
            {
                Ray3D_Triangle3D_do_Intersection ray_triangle_test = new Ray3D_Triangle3D_do_Intersection(ray, TriangulatedPolyhedron[i]);
                if (ray_triangle_test.Intersection)
                {
                    if (points.Count == 0)
                    {
                        points.Add(ray_triangle_test.IntersectionPoint);
                    }
                    else
                    {
                        bool repeat = false;
                        for (int j = 0; j < points.Count; j++)
                        {
                            if (Point.IsSamePoint(points[j], ray_triangle_test.IntersectionPoint, toleranceScale))
                            {
                                repeat = true;
                                break;
                            }
                        }
                        if (!repeat)
                        {
                            points.Add(ray_triangle_test.IntersectionPoint);
                        }
                    }
                }
            }
            Num_intersectionPoint = points.Count;

            if (Num_intersectionPoint % 2 == 1)
            {
                Result= true;
            }
        }
    }
}
