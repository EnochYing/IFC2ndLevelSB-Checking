﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using ClipperLib_WithoutStatic;
using EarClipperLib;

namespace SecondLevelSBValidation
{
    using Path = List<IntPoint>;
    using Paths = List<List<IntPoint>>;

    public class IfcBuildingElement
    {
        //IfcWall, IfcWallStandardCase, IfcSlab, IfcRoof, IfcColumn, IfcCurtainWall, IfcBeam,.....
        public Int64 instance;
        public string instanceName;
        public string entityName;
        public Int64 HasFillings;  // for opening elements
        public Int64 Decomposes;  // for components of aggregate element
        public Int64 SBIntanceSet;
        public List<IfcRelSpaceBoundary> ProvidesSBs = new List<IfcRelSpaceBoundary>();

        public string GlobalID;
        public Int64 ObjectPlacement; // local CS and the higher level CS it refers to 

        public IfcFacetedBrep FacetedBrep = null;
        public List<IfcRelVoidsElement> VoidsElement = new List<IfcRelVoidsElement>();
        public BuildingElementType type = new BuildingElementType();
        public double thickness;

        public string windowdoor_OpeningGlobalID;

        // public IfcTriangulatedFaceSet TriangulatedBrep = null;  // Not the original representation form (for polyhedron, this reflects actual geometry); 

        public IfcBuildingElement()
        {

        }

        // ??? We assume only one IfcRelAggrates for an aggregrate element and contain one component wiout holes (improve later)
        public IfcBuildingElement(Int64 IfcModel, Int64 ElementInstance, BuildingElementType ElementType, string ifcengine2019)
        {
            this.instance = ElementInstance;

            Int64 instanceName = IfcEngine2019.internalGetP21Line(ElementInstance);
            this.instanceName = "#" + instanceName.ToString();

            IntPtr entity = IntPtr.Zero;
            IfcEngine2019.engiGetEntityName(ElementInstance, IfcEngine2019.sdaiUNICODE, out entity);
            this.entityName = Marshal.PtrToStringUni(entity);

            this.type = ElementType;
            // extract the GlobalID 
            IntPtr GlobalIdPtr = IntPtr.Zero;
            IfcEngine2019.sdaiGetAttrBN(ElementInstance, "GlobalId", IfcEngine2019.sdaiUNICODE, out GlobalIdPtr);
            GlobalID = Marshal.PtrToStringUni(GlobalIdPtr);       

            //if (this.GlobalID== "2HKWADuEnEXhJrj6s7d_1c")
            //{
            #region Brep

            if (ElementType == BuildingElementType.IfcOpeningStandardCase)
            {
                Int64 RelFillsElements = 0;
                IfcEngine2019.sdaiGetAttrBN(ElementInstance, "HasFillings", IfcEngine2019.sdaiAGGR, out RelFillsElements);
                Int64 NumRelFillsElement = IfcEngine2019.sdaiGetMemberCount(RelFillsElements); // !!! in most case this value is 1
                if (NumRelFillsElement == 0)
                {
                    this.FacetedBrep = new IfcFacetedBrep(IfcModel, ElementInstance, ifcengine2019);
                }
            }
            else if (ElementType != BuildingElementType.IfcDoorStandardCase && ElementType != BuildingElementType.IfcWindowStandardCase)
            {
                bool process = true;
                if (ElementType == BuildingElementType.IfcRoof)
                {
                    Int64 relAggrateInstances = 0;
                    IfcEngine2019.sdaiGetAttrBN(ElementInstance, "IsDecomposedBy", IfcEngine2019.sdaiAGGR, out relAggrateInstances);
                    Int64 Num_relAggregates = IfcEngine2019.sdaiGetMemberCount(relAggrateInstances);

                    if (Num_relAggregates != 0)
                    {
                        Int64 IfcRelAggregatesInstance = 0;
                        IfcEngine2019.engiGetAggrElement(relAggrateInstances, 0, IfcEngine2019.sdaiINSTANCE, out IfcRelAggregatesInstance);
                        Int64 relatedObjects = 0;
                        IfcEngine2019.sdaiGetAttrBN(IfcRelAggregatesInstance, "RelatedObjects", IfcEngine2019.sdaiAGGR, out relatedObjects);
                        Int64 Num_relatedObjects = IfcEngine2019.sdaiGetMemberCount(relatedObjects);
                        if (Num_relatedObjects != 0)  // ??? We assume only one IfcRelAggrates and contain one component without holes (improve later)
                        {
                            Int64 Relobject = 0;
                            IfcEngine2019.engiGetAggrElement(relatedObjects, 0, IfcEngine2019.sdaiINSTANCE, out Relobject);
                            this.FacetedBrep = new IfcFacetedBrep(IfcModel, Relobject, ifcengine2019);
                        }
                        process = false;
                    }
                }

                if (process)
                {
                    //IfcFacetedBrep temp = new IfcFacetedBrep(IfcModel, ElementInstance);
                    Int64 RelVoidsElements = 0;
                    IfcEngine2019.sdaiGetAttrBN(ElementInstance, "HasOpenings", IfcEngine2019.sdaiAGGR, out RelVoidsElements);
                    Int64 NumRelVoidsElement = IfcEngine2019.sdaiGetMemberCount(RelVoidsElements);
                    if (NumRelVoidsElement != 0)
                    {
                        for (int i = 0; i < NumRelVoidsElement; i++)
                        {
                            Int64 RelVoidsElement = 0;
                            IfcEngine2019.engiGetAggrElement(RelVoidsElements, i, IfcEngine2019.sdaiINSTANCE, out RelVoidsElement);

                            Int64 OpeningElement = 0;
                            IfcEngine2019.sdaiGetAttrBN(RelVoidsElement, "RelatedOpeningElement", IfcEngine2019.sdaiINSTANCE, out OpeningElement);

                            IfcRelVoidsElement VoidsElement = new IfcRelVoidsElement();
                            VoidsElement.InstanceInOriginalModel = RelVoidsElement;
                            VoidsElement.RelatingBuildingElement = ElementInstance;
                            VoidsElement.RelatedOpeningElement = OpeningElement;
                            this.VoidsElement.Add(VoidsElement);
                        }

                        // Be careful, once delete an instance, the whole placement for all other elements wil de displaced and result in unexcepted errors
                        //After using delete function, we cannot correctly extract information but can only write new instances
                        if (this.VoidsElement.Count != 0)
                        {
                            foreach (var Element in this.VoidsElement)
                                IfcEngine2019.sdaiDeleteInstance(Element.InstanceInOriginalModel);
                        }
                    }
                    this.FacetedBrep = new IfcFacetedBrep(IfcModel, ElementInstance, ifcengine2019);
                }
            }
            else // window/door
            {
                Int64 RelFillsElements = 0;
                IfcEngine2019.sdaiGetAttrBN(ElementInstance, "FillsVoids", IfcEngine2019.sdaiAGGR, out RelFillsElements);
                Int64 NumRelFillsElement = IfcEngine2019.sdaiGetMemberCount(RelFillsElements); // !!! in most case this value is 1

                if (NumRelFillsElement != 0) // == 1
                {
                    for (int iFill = 0; iFill < NumRelFillsElement; iFill++) // ???? in most case NumRelFillsElement == 1; 
                    {
                        Int64 RelFillsElement = 0;
                        IfcEngine2019.engiGetAggrElement(RelFillsElements, iFill, IfcEngine2019.sdaiINSTANCE, out RelFillsElement);
                        Int64 Opening = 0;
                        IfcEngine2019.sdaiGetAttrBN(RelFillsElement, "RelatingOpeningElement", IfcEngine2019.sdaiINSTANCE, out Opening);
                        this.FacetedBrep = new IfcFacetedBrep(IfcModel, Opening, ifcengine2019);

                        //Int64 windowdoor_OpeningIN = IfcEngine2019.internalGetP21Line(Opening);
                        //this.windowdoor_OpeninginstanceName = "#" + windowdoor_OpeningIN.ToString();

                        IntPtr GlobalIdPtr_Op = IntPtr.Zero;
                        IfcEngine2019.sdaiGetAttrBN(Opening, "GlobalId", IfcEngine2019.sdaiUNICODE, out GlobalIdPtr_Op);
                        this.windowdoor_OpeningGlobalID = Marshal.PtrToStringUni(GlobalIdPtr_Op);

                    }
                }
            }

            #endregion
            //}

            // extract building element thickness
            if (type == BuildingElementType.IfcWallStandardCase || 
                type == BuildingElementType.IfcWindowStandardCase || 
                type == BuildingElementType.IfcDoorStandardCase ||
                type == BuildingElementType.IfcOpeningStandardCase ||
                type == BuildingElementType.IfcCurtainWall ||
                type == BuildingElementType.IfcColumnStandardCase ||
                type == BuildingElementType.IfcBeamStandardCase)
            {
                if (this.FacetedBrep != null)
                    this.thickness = ComputeVerticalElementThickness(this.FacetedBrep, 0.00001);
            } else if (type == BuildingElementType.IfcCovering || 
                       type == BuildingElementType.IfcRoof ||
                       type == BuildingElementType.IfcSlabStandardCase)
            {
                if (this.FacetedBrep != null)
                    this.thickness = ComputeHorizontalElementThickness(this.FacetedBrep, 0.00001);
            }
        }

        //???: not robust: cannot handle sloped element; the shortest edge may not reflect thickness of building element (e.g., wall end partially connected with another wall )
        private double ComputeVerticalElementThickness(IfcFacetedBrep Brep, double angleTolerance)
        {
            double result = 100000000;
            Vector3D v = new Vector3D(0, 0, 1);
            foreach (var face in Brep.FacetedBrep_Polygon)
            {
                double d = v.DotProduct(face.SurfaceNormal, v);
                double d1 = Math.Abs(Math.Abs(d) - 1);
                if (d1 < angleTolerance)
                {
                    Point3D p = new Point3D();
                    for (int i = 0; i < face.Vertices.Count-1 ; i++)
                    {
                        double dist = p.Distance(face.Vertices[i], face.Vertices[i + 1]);
                        if (result > dist)
                            result = dist;
                    }

                    double dis = p.Distance(face.Vertices[face.Vertices.Count - 1], face.Vertices[0]);
                    if (result > dis)
                        result = dis;                   
                    break;
                }                     
            }

            if (result == 100000000)
                result = 0;

            return result;
        }

        //???: not robust: cannot handle sloped element; the shortest edge may not reflect thickness of building element (e.g., slab partially connected with another wall )
        private double ComputeHorizontalElementThickness(IfcFacetedBrep Brep, double angleTolerance)
        {
            double result = 100000000;
            Vector3D v = new Vector3D(0, 0, 1);
            foreach (var face in Brep.FacetedBrep_Polygon)
            {
                double d = v.DotProduct(face.SurfaceNormal, v);
                double d1 = Math.Abs(d);
                if (d1 < angleTolerance)
                {
                    Point3D p = new Point3D();
                    for (int i = 0; i < face.Vertices.Count - 1; i++)
                    {
                        double dist = p.Distance(face.Vertices[i], face.Vertices[i + 1]);
                        if (result > dist)
                            result = dist;
                    }

                    double dis = p.Distance(face.Vertices[face.Vertices.Count - 1], face.Vertices[0]);
                    if (result > dis)
                        result = dis;
                    break;
                }
            }

            if (result == 100000000)
                result = 0;

            return result;
        }
      
        public IfcBuildingElement(Int64 IfcModel, Int64 ElementInstance /*, List<IfcRelSpaceBoundary> SpaceBoundaries*/)
        {
            this.instance = ElementInstance;

            Int64 instanceName = IfcEngine.internalGetP21Line(ElementInstance);
            this.instanceName = "#" + instanceName.ToString();

            IntPtr entity = IntPtr.Zero;
            IfcEngine.engiGetEntityName(ElementInstance, IfcEngine.sdaiUNICODE, out entity);
            this.entityName = Marshal.PtrToStringUni(entity);

            IfcEngine.sdaiGetAttrBN(ElementInstance, "HasFillings", IfcEngine.sdaiAGGR, out this.HasFillings);
            IfcEngine.sdaiGetAttrBN(ElementInstance, "Decomposes", IfcEngine.sdaiAGGR, out this.Decomposes);
            IfcEngine.sdaiGetAttrBN(ElementInstance, "ProvidesBoundaries", IfcEngine.sdaiAGGR, out this.SBIntanceSet);

            Int64 NumSBs = IfcEngine.sdaiGetMemberCount(this.SBIntanceSet);

            if (NumSBs != 0)
            {
                for (int i = 0; i < NumSBs; i++)
                {
                    Int64 SBInstance = 0;
                    IfcEngine.engiGetAggrElement(this.SBIntanceSet, i, IfcEngine.sdaiINSTANCE, out SBInstance);
                    ProvidesSBs.Add(new IfcRelSpaceBoundary(SBInstance));
                }
            }
        }
    }

}
