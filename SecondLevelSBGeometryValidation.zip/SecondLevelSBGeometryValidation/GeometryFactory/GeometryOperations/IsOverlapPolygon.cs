﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MathNet.Numerics.LinearAlgebra;

namespace SecondLevelSBValidation
{
    public class IsOverlapPolygon
    {
        public bool Result = false;

        // For two any given 3D polygons (concave or convex, coplanar or non coplanar)
        // Possible ways:
        // 1. First find if there's an intersection between the edges of the two polygons.
        // 2. If not, then choose any one point of the first polygon and test whether it is fully inside the second.
        // 3. If not, then choose any one point of the second polygon and test whether it is fully inside the first.
        // 4. If not, then you can conclude that the two polygons are completely outside each other.

        #region 
        // Two polygon MUST be planar
        //public IsOverlapPolygon(Polyline3D polylineA, Polyline3D polylineB)
        //{
        //    Vector3D vector = new Vector3D();
        //    Point3D point = new Point3D();

        //    int numA = polylineA.Vertices.Count;
        //    if (point.IsSamePoint(polylineA.Vertices[0], polylineA.Vertices[numA-1]))         
        //        polylineA.Vertices.RemoveAt(numA - 1);

        //    int numB = polylineB.Vertices.Count;
        //    if (point.IsSamePoint(polylineB.Vertices[0], polylineB.Vertices[numB - 1]))
        //        polylineB.Vertices.RemoveAt(numB - 1);

        //    for (int i = 0; i< polylineA.Vertices.Count - 1; i++)
        //    {
        //        LineSegment3D AB = new LineSegment3D(polylineA.Vertices[i], polylineA.Vertices[i + 1]);
        //        for (int j = 0; j< polylineB.Vertices.Count - 1; j++)
        //        {
        //            LineSegment3D CD = new LineSegment3D(polylineB.Vertices[j], polylineB.Vertices[j + 1]);
        //            IsLineSegmentIntersection check = new IsLineSegmentIntersection(AB, CD);
        //            if (check.Result)
        //            {
        //                Result = true;
        //                return;
        //            }
        //        }

        //        LineSegment3D CD_0 = new LineSegment3D(polylineB.Vertices[polylineB.Vertices.Count - 1], polylineB.Vertices[0]);
        //        if (new IsLineSegmentIntersection(AB, CD_0).Result)
        //        {
        //            Result = true;
        //            return;
        //        }
        //    }

        //    LineSegment3D AB_0 = new LineSegment3D(polylineA.Vertices[polylineA.Vertices.Count - 1], polylineA.Vertices[0]);
        //    for (int j = 0; j < polylineB.Vertices.Count - 1; j++)
        //    {
        //        LineSegment3D CD_1 = new LineSegment3D(polylineB.Vertices[j], polylineB.Vertices[j + 1]);
        //        if (new IsLineSegmentIntersection(AB_0, CD_1).Result)
        //        {
        //            Result = true;
        //            return;
        //        }
        //    }

        //    LineSegment3D CD_2 = new LineSegment3D(polylineB.Vertices[polylineB.Vertices.Count - 1], polylineB.Vertices[0]);
        //    if (new IsLineSegmentIntersection(AB_0, CD_2).Result)
        //    {
        //        Result = true;
        //        return;
        //    }
        //}
        #endregion
    }
}
