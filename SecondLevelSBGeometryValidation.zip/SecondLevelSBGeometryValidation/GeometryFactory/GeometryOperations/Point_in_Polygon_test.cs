﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace SecondLevelSBValidation
{
    public class Point3D_in_Polygon3D_test
    {
        // Uisng Ray-casting (ray crossing or simple boundary crossing) algorithm
        // This algorithm is only applied to SIMPLE POLYGON and Only works for the point being not on the edges of the polygon
        // Non-simple polygon case can be addressed by Winding number algorithm, which is usually slower than ray-casting algorithm in simple polygon case
        // Most of current algorithm implementations focus on the 2D space.

        // Generally, the direction of ray to be created can be arbitary, but here a specifc port is provided for other algorithm use
        // odd-even rule: can be proved by Jordan curve theorem

        // Special case 1: point on the edge of the polygon 
        // Special case 2；rounding errors -- point is very close to the edges of polygon
        // Special case 3: intersection points are located on the vertices of polygon

        public bool test(Point3D point, Polygon3D polygon)
        {
            Ray3D ray = new Ray3D();
            Vector3D vector = new Vector3D();
            Vector3D vector_1 = vector.VectorConstructor(polygon.Vertices[0], point);

            if (vector.DotProduct(vector_1, polygon.Normal) != 0)  // point is not coplanar with the polygon
            {
                return false;
            }
            else
            {
                // ray construction
                ray.StartPoint = point;

                Point3D Point_2 = new Point3D();
                Point_2.x = (polygon.Vertices[0].x + polygon.Vertices[1].x) / 2;
                Point_2.y = (polygon.Vertices[0].y + polygon.Vertices[1].y) / 2;
                Point_2.z = (polygon.Vertices[0].z + polygon.Vertices[1].z) / 2;
                ray.Direction = vector.VectorConstructor(point, Point_2);

                // for polygon the start point generally is not repeated as the last point; 
                // but when constructing line segments, the first point should be also the last point
                int NumLineSegement = polygon.Vertices.Count;
                Point3D lastPointForLS = polygon.Vertices[0];
                polygon.Vertices.Add(lastPointForLS);

                int NumIntersectionPoint = 0;
                for (int i = 0; i < NumLineSegement; i++)
                {
                    LineSegment3D LS = new LineSegment3D(polygon.Vertices[i], polygon.Vertices[i + 1]);
                    Coplane_Ray_LineSegement_do_Intersection ray_lineSegement = new Coplane_Ray_LineSegement_do_Intersection(ray, LS); // actually we do no need computer the distance between the ray's initial point and the intersection point;
                    if (ray_lineSegement.Intersection)
                    {
                        NumIntersectionPoint += 1;
                    }
                }

                if (NumIntersectionPoint % 2 == 1)  // Odd and even rule: point in the polygon
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
    }

}

