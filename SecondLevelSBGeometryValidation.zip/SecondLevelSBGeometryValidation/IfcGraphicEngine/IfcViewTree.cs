﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Drawing;
using System.IO;

namespace SecondLevelSBValidation
{
    // generally used for the representation of ifc entities
    public class IfcItem  
    {
        public Int64 instance = 0; 
        public string ifcType;     // name of this IfcItem

        public IfcItem parent = null;  
        public IfcItem next = null;    // when the parent has alread had a children, then this will be put in the next
        public IfcItem child = null;

        public Int64 circleSegments = 36;
        public STRUCT_MATERIALS materials = null; // associated materials for visualization (IfcstyledItem)

        // geometry extraction
        public float[] vertices;   // vertex storage
        public Int64 verticesCount;  // vertex number
        public int[] indicesForFaces; // face index
        public int[] indicesForWireFrameLineParts; // line sgements index

        // geometry visualization: SharpDX required; get from IfcMaterialBuilder
        public Int64 vertexOffsetForFaces;
        public Int64 indexOffsetForFaces;
        public Int64 vertexOffsetForWireFrame;
        public Int64 indexOffsetForWireFrame;

        public IfcItemView ifcItemView = null;  // IfcItems for visualization in the view tree panel

        // Pretty good!!! 
        // When the value of a property can be derived from other property, "Get" method can be used
        public int TrianglesCount
        {
            get
            {
                if (indicesForFaces != null)
                    return indicesForFaces.Length / 3;  
                return 0;
            }
        }  

        public int LinesCount
        {
            get
            {
                if (indicesForFaces != null) 
                    return indicesForWireFrameLineParts.Length / 2; 
                return 0;
            }
        }  

        public void CreateItem(IfcItem parent, Int64 iInstance, string ifcType)
        {
            this.parent = parent;  // build the relationship: this ----> parent
            this.next = null;
            this.child = null;
            this.instance = iInstance;
            this.ifcType = ifcType;

            if (parent != null)   // build the relationhsip: parent ----> this
            {
                if (parent.child == null)
                {
                    parent.child = this;
                }
                else
                {
                    IfcItem NextChild = parent;                                                         
                    while (true)
                    {
                        if (NextChild.next == null)  //if the parent has already had a child, then assign this to its null next.
                        {
                            NextChild.next = this;
                            break;
                        }
                        else
                            NextChild = NextChild.next;                  
                    }
                }
            }
        }
    }

    // ifcitems showed in the treeview panel
    public class IfcItemView  
    {
        public Int64 Instance  // == public Int64 Instance = 0; 
        {
            get;
            private set;
        }

        public IfcItem Item
        {
            get;
            private set;
        }

        public IfcItemView() // Method 1-1: no input
        {
            this.Instance = -1;
            this.Item = null;
        }

        public IfcItemView(Int64 iInstance, IfcItem item) // Method 1-2: two input
        {
            this.Instance = iInstance;
            this.Item = item;
        }

        public IfcItemView(Int64 iInstance) // Method 1-3: one input
            : this(iInstance, null)
        {
        }

        // == public virtual bool IsVisible = true;
        public virtual bool IsVisible // virtual 虚方法可让继承本类(父类)的子类重新定义该方法： public override bool IsVisible(){}
        {
            get
            {
                return true;
            }
        }
    }

    // children class of the IfcItemView
    // real ifcitems showed in the tree view panel
    // inherit: 子类拥有父类非private属性和功能; 子类可以扩展父类没有的属性和功能; 子类可以重写父类功能
    public class TreeIfcItemView : IfcItemView  
    {
        public TreeIfcItemView()
            : base() //base 代表父类关键词, 用于在派生类中实现对基类公有或者受保护成员的访问, base() == IfcItemView().
        {
        }

        public TreeIfcItemView(Int64 iInstance, IfcItem item)
            : base(iInstance, item)   //base(iInstance, item) == IfcItemView(iInstance, item).
        {
        }

        public TreeIfcItemView(Int64 iInstance)
            : base(iInstance)  //base(iInstance) == IfcItemView(iInstance).
        {
        }

        public TreeNode Node  // new property
        {
            get;
            set;
        }

        // override "IsVisible" method in the parent class; for geometry visualization useage; specifically consider IfcSpace
        public override bool IsVisible  
        {
            get
            {
                System.Diagnostics.Debug.Assert(this.Node != null, "Internal error.");
                if (!this.Node.Text.Contains("IfcSpace"))
                {
                    if ((this.Node.ImageIndex == IfcTreeView.IMAGE_CHECKED) || (this.Node.ImageIndex == IfcTreeView.IMAGE_MIDDLE))
                    {
                        return true;
                    }
                    return false;
                } else
                {
                    if (this.Node.Nodes[0].ImageIndex == IfcTreeView.IMAGE_CHECKED) // only if the geometry item of IfcSpace is CHECKED, the geometry of IfcSpace will display
                    {
                        return true;
                    }
                    return false;
                }
                
            }
        }
    }

    // Display hierarchical relationships of extracted IfcItems in viewTree Panel
    public class IfcTreeView : IfcViewer
    {
        private IfcModel _IfcModel = null;
        TreeView _TreeView = null;

        // images for the tree nodes
        public const int IMAGE_CHECKED = 0;         // stick and active 
        public const int IMAGE_MIDDLE = 1;          // stick but unactive (grey)
        public const int IMAGE_UNCHECKED = 2;       // unstick 
        public const int IMAGE_PROPERTY_SET = 3;    // properties set (non-geometry properties)
        public const int IMAGE_PROPERTY = 4;        // single property (non-geometry property)
        public const int IMAGE_NOT_REFERENCED = 5;   // used for unreferenced item 

        public IfcTreeView(IfcModel ifcModel, TreeView treeView)
        {
            if (ifcModel == null || treeView == null)
                throw new ArgumentNullException();
            _IfcModel = ifcModel;
            _IfcModel.ModelLoaded += (s, e) =>
            {
                _TreeView.Nodes.Clear();
                if (_IfcModel.ifcModel == 0)
                    return;
                if (_IfcModel.RootIfcItem == null)
                    return;
                Cursor.Current = Cursors.WaitCursor; // the shape of mouse           

                // CreateHeaderTreeItems();    
                CreateProjectTree();
                //CreateNotReferencedTreeItems();  
            };

            _TreeView = treeView;
            // Mouse Click Events: Various Mouse Operations (select and unselect the TreeNode)
            _TreeView.NodeMouseClick += (s, e) =>    // e --> event
            {
                if (e.Button == MouseButtons.Left)   // left click
                {
                    Rectangle rcIcon = new Rectangle(e.Node.Bounds.Location - new Size(16, 0), new Size(16, 16)); // ??? why - new Size(16, 0)
                    if (!rcIcon.Contains(e.Location))   // 鼠标点击位置不在 rcTcon 范围内    
                        return;

                    if (e.Node.Tag == null)
                        return;

                    switch (e.Node.ImageIndex)
                    {
                        case IMAGE_CHECKED:   // 如果点击的是已经checked 的item， ignore
                        case IMAGE_MIDDLE:    // 如果点击的是middle， 更换成unchecked
                            {
                                e.Node.ImageIndex = e.Node.SelectedImageIndex = IMAGE_UNCHECKED;
                                UpdateChildrenTreeItems(e.Node);
                                UpdateParentTreeItems(e.Node);
                                this.Renderer.Redraw();  // 点击事件之后 item tree 的状态重新调整，根据调整后的状态重新绘制图形
                            }
                            break;

                        case IMAGE_UNCHECKED:    // 如果点击的是unchecked， 更换成checked
                            {
                                e.Node.ImageIndex = e.Node.SelectedImageIndex = IMAGE_CHECKED; // ImageIndex --- original one; SelectedImageIndex --- after selected 
                                UpdateChildrenTreeItems(e.Node);
                                UpdateParentTreeItems(e.Node);
                                this.Renderer.Redraw(); // 点击事件之后 item tree 的状态重新调整，根据调整后的状态重新绘制图形
                            }
                            break;
                    } 
                } 
                else if (e.Button == MouseButtons.Right)                       
                        _TreeView.SelectedNode = e.Node;
            };

            /*
            * AfterSelect event handler
            */
            _TreeView.AfterSelect += (s, e) =>
            {
                if (e.Node.Tag == null)
                {
                    // skip properties
                    return;
                }

                if (e.Node.ImageIndex != IMAGE_CHECKED)
                {
                    // skip invisible & not referenced items
                    return;
                }

                this.Renderer.OnSelect((e.Node.Tag as TreeIfcItemView).Item);
            };

            /*
             * MouseUp event handler
             */
            _TreeView.MouseUp += (s, e) =>
            {
                if (e.Button == System.Windows.Forms.MouseButtons.Right)
                {
                    ContextMenuStrip contextMenu = new ContextMenuStrip();
                    contextMenu.Items.Clear();

                    Dictionary<string, int> dicIfcType2VisibleCount = new Dictionary<string, int>();
                    foreach (var item in ifcModel.Geometry)
                    {
                        if (!dicIfcType2VisibleCount.ContainsKey(item.ifcType))
                        {
                            dicIfcType2VisibleCount[item.ifcType] = 0;
                        }

                        if (item.ifcItemView.IsVisible)
                        {
                            dicIfcType2VisibleCount[item.ifcType]++;
                        }
                    }

                    foreach (var pair in dicIfcType2VisibleCount)
                    {
                        ToolStripMenuItem menuItem = contextMenu.Items.Add(pair.Key) as ToolStripMenuItem;
                        menuItem.CheckOnClick = true;
                        menuItem.Checked = pair.Value > 0;

                        menuItem.Click += new EventHandler(delegate (object item, EventArgs args)
                        {
                            foreach (TreeNode node in _TreeView.Nodes)
                            {
                                OnContextMenu_UpdateTreeElement(node, pair.Key, menuItem.Checked);
                            }

                            this.Renderer.Redraw();
                        });
                    }

                    contextMenu.Show(_TreeView, new Point(e.X, e.Y));
                }
            };

        }

        #region CreateHeaderTreeItems
        //private void CreateHeaderTreeItems()
        //{
        //    // Header info
        //    TreeNode tnHeaderInfo = _TreeView.Nodes.Add("Header Info");
        //    tnHeaderInfo.ImageIndex = tnHeaderInfo.SelectedImageIndex = IMAGE_PROPERTY_SET;

        //    // Descriptions
        //    TreeNode tnDescriptions = tnHeaderInfo.Nodes.Add("Descriptions");
        //    tnDescriptions.ImageIndex = tnDescriptions.SelectedImageIndex = IMAGE_PROPERTY;

        //    int i = 0;
        //    IntPtr description;
        //    while (IfcEngine.GetSPFFHeaderItem(_Interface_IfcModel.IfcModel, 0, i++, IfcEngine.sdaiSTRING, out description) == 0)
        //    {
        //        TreeNode tnDescription = tnDescriptions.Nodes.Add(Marshal.PtrToStringAnsi(description));
        //        tnDescription.ImageIndex = tnDescription.SelectedImageIndex = IMAGE_PROPERTY;
        //    }

        //    // ImplementationLevel
        //    IntPtr implementationLevel;
        //    IfcEngine.GetSPFFHeaderItem(_Interface_IfcModel.IfcModel, 1, 0, IfcEngine.sdaiSTRING, out implementationLevel);

        //    TreeNode tnImplementationLevel = tnHeaderInfo.Nodes.Add("ImplementationLevel = '" + Marshal.PtrToStringAnsi(implementationLevel) + "'");
        //    tnImplementationLevel.ImageIndex = tnImplementationLevel.SelectedImageIndex = IMAGE_PROPERTY;

        //    // Name
        //    IntPtr name;
        //    IfcEngine.GetSPFFHeaderItem(_Interface_IfcModel.IfcModel, 2, 0, IfcEngine.sdaiSTRING, out name);

        //    TreeNode tnName = tnHeaderInfo.Nodes.Add("Name = '" + Marshal.PtrToStringAnsi(name) + "'");
        //    tnName.ImageIndex = tnName.SelectedImageIndex = IMAGE_PROPERTY;

        //    // TimeStamp
        //    IntPtr timeStamp;
        //    IfcEngine.GetSPFFHeaderItem(_Interface_IfcModel.IfcModel, 3, 0, IfcEngine.sdaiSTRING, out timeStamp);

        //    TreeNode tnTimeStamp = tnHeaderInfo.Nodes.Add("TimeStamp = '" + Marshal.PtrToStringAnsi(timeStamp) + "'");
        //    tnTimeStamp.ImageIndex = tnTimeStamp.SelectedImageIndex = IMAGE_PROPERTY;

        //    // Authors
        //    TreeNode tnAuthors = tnHeaderInfo.Nodes.Add("Authors");
        //    tnAuthors.ImageIndex = tnAuthors.SelectedImageIndex = IMAGE_PROPERTY;

        //    i = 0;
        //    IntPtr author;
        //    while (IfcEngine.GetSPFFHeaderItem(_Interface_IfcModel.IfcModel, 4, i++, IfcEngine.sdaiSTRING, out author) == 0)
        //    {
        //        TreeNode tnAuthor = tnAuthors.Nodes.Add(Marshal.PtrToStringAnsi(author));
        //        tnAuthor.ImageIndex = tnAuthor.SelectedImageIndex = IMAGE_PROPERTY;
        //    }

        //    // Organizations
        //    TreeNode tnOrganizations = tnHeaderInfo.Nodes.Add("Organizations");
        //    tnOrganizations.ImageIndex = tnOrganizations.SelectedImageIndex = IMAGE_PROPERTY;

        //    i = 0;
        //    IntPtr organization;
        //    while (IfcEngine.GetSPFFHeaderItem(_Interface_IfcModel.IfcModel, 5, i++, IfcEngine.sdaiSTRING, out organization) == 0)
        //    {
        //        TreeNode tnOrganization = tnOrganizations.Nodes.Add(Marshal.PtrToStringAnsi(organization));
        //        tnOrganization.ImageIndex = tnOrganization.SelectedImageIndex = IMAGE_PROPERTY;
        //    }

        //    // PreprocessorVersion
        //    IntPtr preprocessorVersion;
        //    IfcEngine.GetSPFFHeaderItem(_Interface_IfcModel.IfcModel, 6, 0, IfcEngine.sdaiSTRING, out preprocessorVersion);

        //    TreeNode tnPreprocessorVersion = tnHeaderInfo.Nodes.Add("PreprocessorVersion = '" + Marshal.PtrToStringAnsi(preprocessorVersion) + "'");
        //    tnPreprocessorVersion.ImageIndex = tnPreprocessorVersion.SelectedImageIndex = IMAGE_PROPERTY;

        //    // OriginatingSystem
        //    IntPtr originatingSystem;
        //    IfcEngine.GetSPFFHeaderItem(_Interface_IfcModel.IfcModel, 7, 0, IfcEngine.sdaiSTRING, out originatingSystem);

        //    TreeNode tnOriginatingSystem = tnHeaderInfo.Nodes.Add("OriginatingSystem = '" + Marshal.PtrToStringAnsi(originatingSystem) + "'");
        //    tnOriginatingSystem.ImageIndex = tnOriginatingSystem.SelectedImageIndex = IMAGE_PROPERTY;

        //    // Authorization
        //    IntPtr authorization;
        //    IfcEngine.GetSPFFHeaderItem(_Interface_IfcModel.IfcModel, 8, 0, IfcEngine.sdaiSTRING, out authorization);

        //    TreeNode tnAuthorization = tnHeaderInfo.Nodes.Add("Authorization = '" + Marshal.PtrToStringAnsi(authorization) + "'");
        //    tnAuthorization.ImageIndex = tnAuthorization.SelectedImageIndex = IMAGE_PROPERTY;

        //    // FileSchemas
        //    TreeNode tnFileSchemas = tnHeaderInfo.Nodes.Add("FileSchemas");
        //    tnFileSchemas.ImageIndex = tnFileSchemas.SelectedImageIndex = IMAGE_PROPERTY;

        //    i = 0;
        //    IntPtr fileSchema;
        //    while (IfcEngine.GetSPFFHeaderItem(_Interface_IfcModel.IfcModel, 9, i++, IfcEngine.sdaiSTRING, out fileSchema) == 0)
        //    {
        //        TreeNode tnFileSchema = tnFileSchemas.Nodes.Add(Marshal.PtrToStringAnsi(fileSchema));
        //        tnFileSchema.ImageIndex = tnFileSchema.SelectedImageIndex = IMAGE_PROPERTY;
        //    }
        //}
        #endregion

        // Create project tree 
        // Follow the hierarchy: IfcProject, IfcSite, IfcBuildingStorey, IfcSpace, IfcRelSpaceBoundary (including non-geometry properties nad geometry properties)
        private void CreateProjectTree()
        {
            Int64 iEntityID = IfcEngine.sdaiGetEntityExtentBN(_IfcModel.ifcModel, "IfcProject");
            Int64 iEntitiesCount = IfcEngine.sdaiGetMemberCount(iEntityID);
            for (Int64 iEntity = 0; iEntity < iEntitiesCount; iEntity++)
            {
                Int64 iInstance = 0;
                IfcEngine.engiGetAggrElement(iEntityID, iEntity, IfcEngine.sdaiINSTANCE, out iInstance);
                AddNestedTree(null, iInstance); // IfcProject should not have a parent ifcitem
            }
        }

        #region CreateNotReferencedTreeItems
        //private void CreateNotReferencedTreeItems()
        //{
        //    TreeIfcItemView ifcTreeItem = new TreeIfcItemView();
        //    ifcTreeItem.Node = _TreeView.Nodes.Add("Not Referenced");
        //    ifcTreeItem.Node.ForeColor = Color.Gray;
        //    ifcTreeItem.Node.ImageIndex = ifcTreeItem.Node.SelectedImageIndex = IMAGE_CHECKED;
        //    ifcTreeItem.Node.Tag = ifcTreeItem;

        //    FindNonReferencedIFCItems(_IfcModel.RootIfcItem, ifcTreeItem.Node);

        //    if (ifcTreeItem.Node.Nodes.Count == 0)
        //    {
        //        // don't show empty Not Referenced item
        //        _TreeView.Nodes.Remove(ifcTreeItem.Node);
        //    }
        //}
        #endregion

        // add the tree node incrementally
        private void AddNestedTree(TreeIfcItemView ifcParent, Int64 iParentInstance)
        {
            // asign the iParentInstance to the corresponding IfcItem;
            TreeIfcItemView TreeIfcItemView =
                new TreeIfcItemView(iParentInstance, FindIfcItem(_IfcModel.RootIfcItem, iParentInstance));

            // add tree node (name and relevant data source) as a sub node of the ifcparent;
            CreateTreeItem(ifcParent, TreeIfcItemView);

            if (TreeIfcItemView.Item != null)
            {
                TreeIfcItemView.Item.ifcItemView = TreeIfcItemView;
                //TreeIfcItemView.Node.ImageIndex = TreeIfcItemView.Node.SelectedImageIndex = IMAGE_CHECKED;  // 所有visual representation 的 IFCitem 初始化为checked

                if (IsInstanceOf(iParentInstance, "IfcSpace"))
                {
                    TreeIfcItemView.Node.ImageIndex = TreeIfcItemView.Node.SelectedImageIndex = IMAGE_CHECKED;
                    TreeIfcItemView.Node.Nodes[0].ImageIndex = TreeIfcItemView.Node.Nodes[0].SelectedImageIndex = IMAGE_CHECKED;
                }
                else
                {
                    TreeIfcItemView.Node.ImageIndex = TreeIfcItemView.Node.SelectedImageIndex = IMAGE_CHECKED;
                }
            }  else
            {
                TreeIfcItemView.Node.ImageIndex = TreeIfcItemView.Node.SelectedImageIndex = IMAGE_NOT_REFERENCED; // ????
            }

            // check for decomposition: IfcProject---IfcSite---IfcBuilding---IfcBuildingStorey---IfcSpace
            IntPtr decompositionInstance;
            IfcEngine.sdaiGetAttrBN(iParentInstance, "IsDecomposedBy", IfcEngine.sdaiAGGR, out decompositionInstance);

            if (decompositionInstance != IntPtr.Zero)
            {
                Int64 iDecompositionsCount = IfcEngine.sdaiGetMemberCount((Int64)decompositionInstance);
                for (Int64 iDecomposition = 0; iDecomposition < iDecompositionsCount; iDecomposition++)
                {
                    Int64 iDecompositionInstance = 0;
                    IfcEngine.engiGetAggrElement((Int64)decompositionInstance, iDecomposition, IfcEngine.sdaiINSTANCE, out iDecompositionInstance);

                    if (IsInstanceOf(iDecompositionInstance, "IFCRELAGGREGATES"))
                    {
                        IntPtr objectInstances;
                        IfcEngine.sdaiGetAttrBN(iDecompositionInstance, "RelatedObjects", IfcEngine.sdaiAGGR, out objectInstances);

                        Int64 iObjectsCount = IfcEngine.sdaiGetMemberCount((Int64)objectInstances);
                        for (Int64 iObject = 0; iObject < iObjectsCount; iObject++)
                        {
                            Int64 iObjectInstance = 0;
                            IfcEngine.engiGetAggrElement((Int64)objectInstances, iObject, IfcEngine.sdaiINSTANCE, out iObjectInstance);
                            AddNestedTree(TreeIfcItemView, iObjectInstance); // add the Decomposition nodes under the TreeIfcItemView 
                        }
                    }
                }
            }

            // add geometry node specifically for IfcSpace 
            // attach space boundaries: IfcSpace---IfcRelSapceBoundary
            if (IsInstanceOf(iParentInstance, "IFCSPACE"))
            {
                Int64 SpaceBoundaryInstances = 0;
                IfcEngine.sdaiGetAttrBN(iParentInstance, "BoundedBy", IfcEngine.sdaiAGGR, out SpaceBoundaryInstances);
                if (SpaceBoundaryInstances != 0)
                {
                    Int64 Num_SpaceBoundaryInstances = IfcEngine.sdaiGetMemberCount(SpaceBoundaryInstances);
                    for (Int64 iSpaceBoundary = 0; iSpaceBoundary < Num_SpaceBoundaryInstances; iSpaceBoundary++)
                    {
                        Int64 SpaceBoundaryInstance = 0;
                        IfcEngine.engiGetAggrElement(SpaceBoundaryInstances, iSpaceBoundary, IfcEngine.sdaiINSTANCE, out SpaceBoundaryInstance);
                        AddNestedTree(TreeIfcItemView, SpaceBoundaryInstance);  // the geometry part need to be rethinked as it is 3D surface geometry
                    }
                }
            }


            // attach space boundaries: IfcExternalSpatialElement---IfcRelSapceBoundary2ndLevel
            if (IsInstanceOf(iParentInstance, "IFCEXTERNALSPATIALELEMENT"))
            {
                Int64 SpaceBoundaryInstances = 0;
                IfcEngine.sdaiGetAttrBN(iParentInstance, "BoundedBy", IfcEngine.sdaiAGGR, out SpaceBoundaryInstances);
                if (SpaceBoundaryInstances != 0)
                {
                    Int64 Num_SpaceBoundaryInstances = IfcEngine.sdaiGetMemberCount(SpaceBoundaryInstances);
                    for (Int64 iSpaceBoundary = 0; iSpaceBoundary < Num_SpaceBoundaryInstances; iSpaceBoundary++)
                    {
                        Int64 SpaceBoundaryInstance = 0;
                        IfcEngine.engiGetAggrElement(SpaceBoundaryInstances, iSpaceBoundary, IfcEngine.sdaiINSTANCE, out SpaceBoundaryInstance);
                        AddNestedTree(TreeIfcItemView, SpaceBoundaryInstance);  // the geometry part need to be rethinked as it is 3D surface geometry
                    }
                }
            }

            if (IsInstanceOf(iParentInstance, "IFCRELSPACEBOUNDARY2NDLEVEL"))
            {
                Add2ndLevelSBPropertyTreeItems(TreeIfcItemView, iParentInstance);
            }
            else if (IsInstanceOf(iParentInstance, "IFCRELSPACEBOUNDARY"))
            {
                AddSBPropertyTreeItems(TreeIfcItemView, iParentInstance);
            }

            #region check for containment: IfcBuildingStorey --- physical elements
            //IntPtr elementsInstance;
            //IfcEngine.sdaiGetAttrBN(iParentInstance, "ContainsElements", IfcEngine.sdaiAGGR, out elementsInstance);

            //if (elementsInstance != IntPtr.Zero)
            //{
            //    Int64 iElementsCount = IfcEngine.sdaiGetMemberCount((Int64)elementsInstance);
            //    for (Int64 iElement = 0; iElement < iElementsCount; iElement++)
            //    {
            //        Int64 iElementInstance = 0;
            //        IfcEngine.engiGetAggrElement((Int64)elementsInstance, iElement, IfcEngine.sdaiINSTANCE, out iElementInstance);

            //        if (IsInstanceOf(iElementInstance, "IFCRELCONTAINEDINSPATIALSTRUCTURE"))
            //        {
            //            IntPtr objectInstances;
            //            IfcEngine.sdaiGetAttrBN(iElementInstance, "RelatedElements", IfcEngine.sdaiAGGR, out objectInstances);

            //            Int64 iObjectsCount = IfcEngine.sdaiGetMemberCount((Int64)objectInstances);
            //            for (Int64 iObject = 0; iObject < iObjectsCount; iObject++)
            //            {
            //                Int64 iObjectInstance = 0;
            //                IfcEngine.engiGetAggrElement((Int64)objectInstances, iObject, IfcEngine.sdaiINSTANCE, out iObjectInstance);

            //                AddNestedTree(TreeIfcItemView, iObjectInstance); // add the Containment nodes under the TreeIfcItemView 
            //            }
            //        }
            //    }
            //}
            #endregion
            // attach space boundaries: physical elements---IfcRelSapceBoundary
        }

        // Properties: GUID, Name, Description, RelatingSpace (GUID), RelatedBuildingElement, PhysicalOrVirtualBoundary, InternalOrExternalBoundary
        private void Add2ndLevelSBPropertyTreeItems(TreeIfcItemView ifcSpaceBoundary, Int64 SpaceBoundaryInstance)
        {
            IntPtr GUID;
            IfcEngine.sdaiGetAttrBN(SpaceBoundaryInstance, "GlobalId", IfcEngine.sdaiSTRING, out GUID);
            string GUIDVaule = "GUID: " + Marshal.PtrToStringAnsi(GUID);
            TreeIfcItemView TreeIfcItemView_GUID = new TreeIfcItemView();
            CreateSBPropertyTreeItem(ifcSpaceBoundary, TreeIfcItemView_GUID, GUIDVaule);

            //IntPtr Name;
            //IfcEngine.sdaiGetAttrBN(SpaceBoundaryInstance, "Name", IfcEngine.sdaiSTRING, out Name);
            //string NameVaule = "Name:" + Marshal.PtrToStringAnsi(Name);
            //TreeIfcItemView TreeIfcItemView_Name = new TreeIfcItemView();
            //CreateSBPropertyTreeItem(ifcSpaceBoundary, TreeIfcItemView_Name, NameVaule);

            IntPtr Description;
            IfcEngine.sdaiGetAttrBN(SpaceBoundaryInstance, "Description", IfcEngine.sdaiSTRING, out Description);
            string DescriptionVaule = "Description: " + Marshal.PtrToStringAnsi(Description);
            TreeIfcItemView TreeIfcItemView_Description = new TreeIfcItemView();
            CreateSBPropertyTreeItem(ifcSpaceBoundary, TreeIfcItemView_Description, DescriptionVaule);

            Int64 RelatingSpace = 0;
            IfcEngine.sdaiGetAttrBN(SpaceBoundaryInstance, "RelatingSpace", IfcEngine.sdaiINSTANCE, out RelatingSpace);
            //IntPtr RelatingSpace_GUID;
            //IfcEngine.sdaiGetAttrBN(RelatingSpace, "GlobalId", IfcEngine.sdaiSTRING, out RelatingSpace_GUID);
            //string RelatingSpace_GUIDVaule = "RelatingSpace:" + Marshal.PtrToStringAnsi(RelatingSpace_GUID);
            string RelatingSpace_InstanceName = "RelatingSpace: ";
            if (RelatingSpace != 0)
            {
                Int64 RelatingSpace_instanceName = IfcEngine.internalGetP21Line(RelatingSpace);
                string RelatingSpace_EntityName;
                if (IsInstanceOf(RelatingSpace, "IfcSpace"))
                    RelatingSpace_EntityName = "IfcSpace";
                else if (IsInstanceOf(RelatingSpace, "IfcExternalSpatialElement"))
                    RelatingSpace_EntityName = "IfcExternalSpatialElement";
                else
                    RelatingSpace_EntityName = "";
                RelatingSpace_InstanceName += "#" + RelatingSpace_instanceName.ToString() + " " + RelatingSpace_EntityName;
            }          
            TreeIfcItemView TreeIfcItemView_RelatingSpace = new TreeIfcItemView(RelatingSpace); // Conflict (as already created as an node)
            CreateSBPropertyTreeItem(ifcSpaceBoundary, TreeIfcItemView_RelatingSpace, RelatingSpace_InstanceName);

            Int64 RelatedBuildingElement = 0;
            IfcEngine.sdaiGetAttrBN(SpaceBoundaryInstance, "RelatedBuildingElement", IfcEngine.sdaiINSTANCE, out RelatedBuildingElement);
            //IntPtr RelatedBuildingElement_GUID;
            //IfcEngine.sdaiGetAttrBN(RelatedBuildingElement, "GlobalId", IfcEngine.sdaiSTRING, out RelatedBuildingElement_GUID);
            //string RelatedBuildingElement_GUIDVaule = "RelatedBuildingElement:" + Marshal.PtrToStringAnsi(RelatedBuildingElement_GUID);
            string RelatedBuildingElement_InstanceName = "RelatedBuildingElement: ";
            if (RelatedBuildingElement != 0)
            {
                Int64 RelatedBuildingElement_instanceName = IfcEngine.internalGetP21Line(RelatedBuildingElement);
                string RelatedBuildingElement_EntityName = DetectBuildingElementEntityType(RelatedBuildingElement);

                RelatedBuildingElement_InstanceName += "#" + RelatedBuildingElement_instanceName.ToString() + " " + RelatedBuildingElement_EntityName;
            }          
            TreeIfcItemView TreeIfcItemView_RelatedBuildingElement = new TreeIfcItemView(RelatedBuildingElement); // Conflict
            CreateSBPropertyTreeItem(ifcSpaceBoundary, TreeIfcItemView_RelatedBuildingElement, RelatedBuildingElement_InstanceName);

            Int64 ConnectionSurfaceGeometryInstance = 0;
            Int64 CurveBoundedPlaneInstance = 0;
            IfcEngine.sdaiGetAttrBN(SpaceBoundaryInstance, "ConnectionGeometry", IfcEngine.sdaiINSTANCE, out ConnectionSurfaceGeometryInstance);
            IfcEngine.sdaiGetAttrBN(ConnectionSurfaceGeometryInstance, "SurfaceOnRelatingElement", IfcEngine.sdaiINSTANCE, out CurveBoundedPlaneInstance);

            Int64 PlaneInstance = 0;
            Int64 Axis2Placement3DInstance = 0;
            IfcEngine.sdaiGetAttrBN(CurveBoundedPlaneInstance, "BasisSurface", IfcEngine.sdaiINSTANCE, out PlaneInstance);
            IfcEngine.sdaiGetAttrBN(PlaneInstance, "Position", IfcEngine.sdaiINSTANCE, out Axis2Placement3DInstance);
            IfcAxis2Placement3D_IfcEngine Axis2Placement3D = new IfcAxis2Placement3D_IfcEngine(Axis2Placement3DInstance);

            // transformation matrix calculation                   
            AffineTR _AffineTR = new AffineTR();
            double[,] TransformationMatrix = _AffineTR.TRMatrix(Axis2Placement3D.LCSLocation, Axis2Placement3D.LCSxAxis, Axis2Placement3D.LCSzAxis);
            PointCoordTransf PTransfer = new PointCoordTransf();

            Int64 IfcPolylineInstance = 0;
            IfcEngine.sdaiGetAttrBN(CurveBoundedPlaneInstance, "OuterBoundary", IfcEngine.sdaiINSTANCE, out IfcPolylineInstance);
            TreeIfcItemView TreeIfcItemView_ConnectionGeometry_ownLCS = new TreeIfcItemView();
            TreeIfcItemView TreeIfcItemView_ConnectionGeometry_spaceLCS = new TreeIfcItemView();
            if (IsInstanceOf(IfcPolylineInstance, "IfcPolyline"))
            {
                #region ownLCS connection geometry

                string ConnectionGeometry_instanceName = "ConnectionGeometry (ownLCS): ";
                ConnectionGeometry_instanceName += "#" + IfcEngine.internalGetP21Line(IfcPolylineInstance).ToString() + " " + "IfcPolyline";
                CreateSBPropertyTreeItem(ifcSpaceBoundary, TreeIfcItemView_ConnectionGeometry_ownLCS, ConnectionGeometry_instanceName);
                IfcPolyline _IfcPolyline = new IfcPolyline(IfcPolylineInstance);
                List<Point2D> polylineLCS = new List<Point2D>();
                if (_IfcPolyline.Polygon3D.Vertices.Count != 0)
                {
                    foreach (var p in _IfcPolyline.Polygon3D.Vertices)
                    {
                        Point2D p2d = new Point2D();
                        p2d.x = p.x;
                        p2d.y = p.y;
                        polylineLCS.Add(p2d);
                    }
                }

                foreach (var p in polylineLCS)
                {
                    TreeIfcItemView TreeIfcItemView_vertex = new TreeIfcItemView();
                    CreateSBGeometryVertexTreeItem(TreeIfcItemView_ConnectionGeometry_ownLCS, TreeIfcItemView_vertex, p);
                }
                #endregion

                #region spaceLCS connection geometry

                string ConnectionGeometry_instanceName_spaceLCS = "ConnectionGeometry (spaceLCS): ";
                ConnectionGeometry_instanceName_spaceLCS += "#" + IfcEngine.internalGetP21Line(IfcPolylineInstance).ToString() + " " + "IfcPolyline";
                CreateSBPropertyTreeItem(ifcSpaceBoundary, TreeIfcItemView_ConnectionGeometry_spaceLCS, ConnectionGeometry_instanceName_spaceLCS);
                List<Point3D> polylineSpaceLCS = new List<Point3D>();
                if (_IfcPolyline.Polygon3D.Vertices.Count != 0)
                {
                    foreach (var p in _IfcPolyline.Polygon3D.Vertices)
                        polylineSpaceLCS.Add(PTransfer.PointTransf3D(p, TransformationMatrix));
                }

                foreach (var p in polylineSpaceLCS)
                {
                    TreeIfcItemView TreeIfcItemView_vertex_spaceLCS = new TreeIfcItemView();
                    CreateSBGeometryVertexTreeItem(TreeIfcItemView_ConnectionGeometry_spaceLCS, TreeIfcItemView_vertex_spaceLCS, p);
                }

                #endregion 

            }
            else if (IsInstanceOf(IfcPolylineInstance, "IfcComPositeCurve"))
            {
                #region ownLCS connection geometry

                string ConnectionGeometry_instanceName = "ConnectionGeometry (ownLCS): ";
                ConnectionGeometry_instanceName += "#" + IfcEngine.internalGetP21Line(IfcPolylineInstance).ToString() + " " + "IfcComPositeCurve";
                CreateSBPropertyTreeItem(ifcSpaceBoundary, TreeIfcItemView_ConnectionGeometry_ownLCS, ConnectionGeometry_instanceName);
                Int64 IfcCompositeCurveSegmentInstances = 0;
                IfcEngine.sdaiGetAttrBN(IfcPolylineInstance, "Segments", IfcEngine.sdaiAGGR, out IfcCompositeCurveSegmentInstances);
                Int64 Num = IfcEngine.sdaiGetMemberCount(IfcCompositeCurveSegmentInstances);
                List<Point2D> polylineLCS = new List<Point2D>();
                List<Point3D> polylineLCS_3D = new List<Point3D>();
                if (Num != 0)
                {
                    for (int s = 0; s < Num; s++)
                    {
                        Int64 IfcCompositeCurveSegmentInstance = 0;
                        IfcEngine.engiGetAggrElement(IfcCompositeCurveSegmentInstances, s, IfcEngine.sdaiINSTANCE, out IfcCompositeCurveSegmentInstance);
                        Int64 ParentCurve = 0; // should be IfcPolyline
                        IfcEngine.sdaiGetAttrBN(IfcCompositeCurveSegmentInstance, "ParentCurve", IfcEngine.sdaiINSTANCE, out ParentCurve);
                        IfcPolyline _IfcPolyline = new IfcPolyline(ParentCurve);
                        if (_IfcPolyline.Polygon3D.Vertices.Count != 0) // Sometimes cooridnates defined as 3D (z should be always 0)
                        {
                            foreach (var p in _IfcPolyline.Polygon3D.Vertices)
                            {
                                polylineLCS_3D.Add(p);
                                Point2D p2d = new Point2D();
                                p2d.x = p.x;
                                p2d.y = p.y;
                                polylineLCS.Add(p2d);
                            }
                        }
                    }
                }
                foreach (var p in polylineLCS)
                {
                    TreeIfcItemView TreeIfcItemView_vertex = new TreeIfcItemView();
                    CreateSBGeometryVertexTreeItem(TreeIfcItemView_ConnectionGeometry_ownLCS, TreeIfcItemView_vertex, p);
                }

                #endregion

                #region spaceLCS connection geometry

                string ConnectionGeometry_instanceName_spaceLCS = "ConnectionGeometry (spaceLCS): ";
                ConnectionGeometry_instanceName_spaceLCS += "#" + IfcEngine.internalGetP21Line(IfcPolylineInstance).ToString() + " " + "IfcComPositeCurve";
                CreateSBPropertyTreeItem(ifcSpaceBoundary, TreeIfcItemView_ConnectionGeometry_spaceLCS, ConnectionGeometry_instanceName_spaceLCS);
               
                foreach (var p in polylineLCS_3D)
                {
                    Point3D p1 = PTransfer.PointTransf3D(p, TransformationMatrix);
                    TreeIfcItemView TreeIfcItemView_vertex = new TreeIfcItemView();
                    CreateSBGeometryVertexTreeItem(TreeIfcItemView_ConnectionGeometry_ownLCS, TreeIfcItemView_vertex, p1);
                }
                #endregion
            }

            IntPtr PhysicalOrVirtualBoundary;
            IfcEngine.sdaiGetAttrBN(SpaceBoundaryInstance, "PhysicalOrVirtualBoundary", IfcEngine.sdaiSTRING, out PhysicalOrVirtualBoundary);
            string PhysicalOrVirtualBoundaryVaule = "PhysicalOrVirtualBoundary: " + Marshal.PtrToStringAnsi(PhysicalOrVirtualBoundary);
            TreeIfcItemView TreeIfcItemView_PhysicalOrVirtualBoundary = new TreeIfcItemView();
            CreateSBPropertyTreeItem(ifcSpaceBoundary, TreeIfcItemView_PhysicalOrVirtualBoundary, PhysicalOrVirtualBoundaryVaule);

            IntPtr InternalOrExternalBoundary;
            IfcEngine.sdaiGetAttrBN(SpaceBoundaryInstance, "InternalOrExternalBoundary", IfcEngine.sdaiSTRING, out InternalOrExternalBoundary);
            string InternalOrExternalBoundaryVaule = "InternalOrExternalBoundary: " + Marshal.PtrToStringAnsi(InternalOrExternalBoundary);
            TreeIfcItemView TreeIfcItemView_InternalOrExternalBoundary = new TreeIfcItemView();
            CreateSBPropertyTreeItem(ifcSpaceBoundary, TreeIfcItemView_InternalOrExternalBoundary, InternalOrExternalBoundaryVaule);

            Int64 ParentBoundary = 0;
            IfcEngine.sdaiGetAttrBN(SpaceBoundaryInstance, "ParentBoundary", IfcEngine.sdaiINSTANCE, out ParentBoundary);
            //IntPtr ParentBoundary_GUID;
            //IfcEngine.sdaiGetAttrBN(ParentBoundary, "GlobalId", IfcEngine.sdaiSTRING, out ParentBoundary_GUID);
            //string ParentBoundary_GUIDVaule = "ParentBoundary:" + Marshal.PtrToStringAnsi(ParentBoundary_GUID);
            string ParentBoundary_InstanceName = "ParentBoundary: ";
            if (ParentBoundary != 0)
            {
                Int64 ParentBoundary_instanceName = IfcEngine.internalGetP21Line(ParentBoundary);
                string ParentBoundary_EntityName;
                if (IsInstanceOf(ParentBoundary, "IfcRelSpaceBoundary2ndLevel"))
                    ParentBoundary_EntityName = "IfcRelSpaceBoundary2ndLevel";
                else if (IsInstanceOf(ParentBoundary, "IfcRelSpaceBoundary"))
                    ParentBoundary_EntityName = "IfcRelSpaceBoundary";
                else if (IsInstanceOf(ParentBoundary, "IfcRelSpaceBoundary1stLevel"))
                    ParentBoundary_EntityName = "IfcRelSpaceBoundary1stLevel";
                else
                    ParentBoundary_EntityName = "";
                ParentBoundary_InstanceName += "#" + ParentBoundary_instanceName.ToString() + " " + ParentBoundary_EntityName;
            }        
            TreeIfcItemView TreeIfcItemView_ParentBoundary = new TreeIfcItemView(ParentBoundary); // Conflict
            CreateSBPropertyTreeItem(ifcSpaceBoundary, TreeIfcItemView_ParentBoundary, ParentBoundary_InstanceName);

            Int64 CorrespondingBoundary = 0;
            IfcEngine.sdaiGetAttrBN(SpaceBoundaryInstance, "CorrespondingBoundary", IfcEngine.sdaiINSTANCE, out CorrespondingBoundary);
            //IntPtr CorrespondingBoundary_GUID;
            //IfcEngine.sdaiGetAttrBN(CorrespondingBoundary, "GlobalId", IfcEngine.sdaiSTRING, out CorrespondingBoundary_GUID);
            //string CorrespondingBoundary_GUIDVaule = "CorrespondingBoundary:" + Marshal.PtrToStringAnsi(CorrespondingBoundary_GUID);
            string CorrespondingBoundary_InstanceName = "CorrespondingBoundary: ";
            if (CorrespondingBoundary != 0)
            {
                Int64 CorrespondingBoundary_instanceName = IfcEngine.internalGetP21Line(CorrespondingBoundary);
                string CorrespondingBoundary_EntityName;
                if (IsInstanceOf(CorrespondingBoundary, "IfcRelSpaceBoundary2ndLevel"))
                    CorrespondingBoundary_EntityName = "IfcRelSpaceBoundary2ndLevel";
                else if (IsInstanceOf(CorrespondingBoundary, "IfcRelSpaceBoundary"))
                    CorrespondingBoundary_EntityName = "IfcRelSpaceBoundary";
                else if (IsInstanceOf(CorrespondingBoundary, "IfcRelSpaceBoundary1stLevel"))
                    CorrespondingBoundary_EntityName = "IfcRelSpaceBoundary1stLevel";
                else
                    CorrespondingBoundary_EntityName = "";
                CorrespondingBoundary_InstanceName += "#" + CorrespondingBoundary_instanceName.ToString() + " " + CorrespondingBoundary_EntityName;
            }           
            TreeIfcItemView TreeIfcItemView_CorrespondingBoundary = new TreeIfcItemView(CorrespondingBoundary); // Conflict
            CreateSBPropertyTreeItem(ifcSpaceBoundary, TreeIfcItemView_CorrespondingBoundary, CorrespondingBoundary_InstanceName);
        }

        private string DetectBuildingElementEntityType(Int64 buildingElement)
        {
            string result = "";
            if (IsInstanceOf(buildingElement, "IfcWallStandardCase"))
                result = "IfcWallStandardCase";
            else if (IsInstanceOf(buildingElement, "IfcWall"))
                result = "IfcWall";
            else if (IsInstanceOf(buildingElement, "IfcWallElementedCase"))
                result = "IfcWallElementedCase";
            else if (IsInstanceOf(buildingElement, "IfcCurtainWall"))
                result = "IfcCurtainWall";
            else if (IsInstanceOf(buildingElement, "IfcSlab"))
                result = "IfcSlab";
            else if (IsInstanceOf(buildingElement, "IfcSlabStandardCase"))
                result = "IfcSlabStandardCase";
            else if (IsInstanceOf(buildingElement, "IfcSlabElementedCase"))
                result = "IfcSlabElementedCase";
            else if (IsInstanceOf(buildingElement, "IfcWindow"))
                result = "IfcWindow";
            else if (IsInstanceOf(buildingElement, "IfcWindowStandardCase"))
                result = "IfcWindowStandardCase";
            else if (IsInstanceOf(buildingElement, "IfcDoor"))
                result = "IfcDoor";
            else if (IsInstanceOf(buildingElement, "IfcDoorStandardCase"))
                result = "IfcDoorStandardCase";
            else if (IsInstanceOf(buildingElement, "IfcColumn"))
                result = "IfcColumn";
            else if (IsInstanceOf(buildingElement, "IfcColumnStandardCase"))
                result = "IfcColumnStandardCase";
            else if (IsInstanceOf(buildingElement, "IfcBeam"))
                result = "IfcBeam";
            else if (IsInstanceOf(buildingElement, "IfcRoof"))
                result = "IfcRoof";
            else if (IsInstanceOf(buildingElement, "IfcOpeningElement"))
                result = "IfcOpeningElement";
            else if (IsInstanceOf(buildingElement, "IfcOpeningStandardCase"))
                result = "IfcOpeningStandardCase";
            else if (IsInstanceOf(buildingElement, "IFCVIRTUALELEMENT"))
                result = "IFCVIRTUALELEMENT";

            return result;  
        }

        // Properties: GUID, Name, Description, RelatingSpace (GUID), RelatedBuildingElement, PhysicalOrVirtualBoundary, InternalOrExternalBoundary
        private void AddSBPropertyTreeItems(TreeIfcItemView ifcSpaceBoundary, Int64 SpaceBoundaryInstance)
        {
            IntPtr GUID;
            IfcEngine.sdaiGetAttrBN(SpaceBoundaryInstance, "GlobalId", IfcEngine.sdaiSTRING, out GUID);
            string GUIDVaule = "GUID:" + Marshal.PtrToStringAnsi(GUID);
            TreeIfcItemView TreeIfcItemView_GUID = new TreeIfcItemView();
            CreateSBPropertyTreeItem(ifcSpaceBoundary, TreeIfcItemView_GUID, GUIDVaule);

            IntPtr Name;
            IfcEngine.sdaiGetAttrBN(SpaceBoundaryInstance, "Name", IfcEngine.sdaiSTRING, out Name);
            string NameVaule = "Name:" + Marshal.PtrToStringAnsi(Name);
            TreeIfcItemView TreeIfcItemView_Name = new TreeIfcItemView();
            CreateSBPropertyTreeItem(ifcSpaceBoundary, TreeIfcItemView_Name, NameVaule);

            IntPtr Description;
            IfcEngine.sdaiGetAttrBN(SpaceBoundaryInstance, "Description", IfcEngine.sdaiSTRING, out Description);
            string DescriptionVaule = "Description:" + Marshal.PtrToStringAnsi(Description);
            TreeIfcItemView TreeIfcItemView_Description = new TreeIfcItemView();
            CreateSBPropertyTreeItem(ifcSpaceBoundary, TreeIfcItemView_Description, DescriptionVaule);

            Int64 RelatingSpace = 0;
            IfcEngine.sdaiGetAttrBN(SpaceBoundaryInstance, "RelatingSpace", IfcEngine.sdaiINSTANCE, out RelatingSpace);
            IntPtr RelatingSpace_GUID;
            IfcEngine.sdaiGetAttrBN(RelatingSpace, "GlobalId", IfcEngine.sdaiSTRING, out RelatingSpace_GUID);
            string RelatingSpace_GUIDVaule = "RelatingSpace:" + Marshal.PtrToStringAnsi(RelatingSpace_GUID);
            TreeIfcItemView TreeIfcItemView_RelatingSpace = new TreeIfcItemView(RelatingSpace); // Conflict (as already created as an node)
            CreateSBPropertyTreeItem(ifcSpaceBoundary, TreeIfcItemView_RelatingSpace, RelatingSpace_GUIDVaule);

            Int64 RelatedBuildingElement = 0;
            IfcEngine.sdaiGetAttrBN(SpaceBoundaryInstance, "RelatedBuildingElement", IfcEngine.sdaiINSTANCE, out RelatedBuildingElement);
            IntPtr RelatedBuildingElement_GUID;
            IfcEngine.sdaiGetAttrBN(RelatedBuildingElement, "GlobalId", IfcEngine.sdaiSTRING, out RelatedBuildingElement_GUID);
            string RelatedBuildingElement_GUIDVaule = "RelatedBuildingElement:" + Marshal.PtrToStringAnsi(RelatedBuildingElement_GUID);
            TreeIfcItemView TreeIfcItemView_RelatedBuildingElement = new TreeIfcItemView(RelatedBuildingElement); // Conflict
            CreateSBPropertyTreeItem(ifcSpaceBoundary, TreeIfcItemView_RelatedBuildingElement, RelatedBuildingElement_GUIDVaule);

            IntPtr PhysicalOrVirtualBoundary;
            IfcEngine.sdaiGetAttrBN(SpaceBoundaryInstance, "PhysicalOrVirtualBoundary", IfcEngine.sdaiSTRING, out PhysicalOrVirtualBoundary);
            string PhysicalOrVirtualBoundaryVaule = "PhysicalOrVirtualBoundary:" + Marshal.PtrToStringAnsi(PhysicalOrVirtualBoundary);
            TreeIfcItemView TreeIfcItemView_PhysicalOrVirtualBoundary = new TreeIfcItemView();
            CreateSBPropertyTreeItem(ifcSpaceBoundary, TreeIfcItemView_PhysicalOrVirtualBoundary, PhysicalOrVirtualBoundaryVaule);

            IntPtr InternalOrExternalBoundary;
            IfcEngine.sdaiGetAttrBN(SpaceBoundaryInstance, "InternalOrExternalBoundary", IfcEngine.sdaiSTRING, out InternalOrExternalBoundary);
            string InternalOrExternalBoundaryVaule = "InternalOrExternalBoundary:" + Marshal.PtrToStringAnsi(InternalOrExternalBoundary);
            TreeIfcItemView TreeIfcItemView_InternalOrExternalBoundary = new TreeIfcItemView();
            CreateSBPropertyTreeItem(ifcSpaceBoundary, TreeIfcItemView_InternalOrExternalBoundary, InternalOrExternalBoundaryVaule);
        }

        // create tree item for space boundary semantic property
        private void CreateSBPropertyTreeItem(TreeIfcItemView ifcParent, TreeIfcItemView ifcItem, string strProperty)
        {
            if ((ifcParent != null) && (ifcParent.Node != null))
            {
                ifcItem.Node = ifcParent.Node.Nodes.Add(strProperty);
            }
            else
            {
                ifcItem.Node = _TreeView.Nodes.Add(strProperty);
            }

            if (ifcItem.Item == null)
            {
                // item without visual representation
                ifcItem.Node.ForeColor = Color.Gray;
            }

            ifcItem.Node.ImageIndex = ifcItem.Node.SelectedImageIndex = IMAGE_PROPERTY;
        }

        // create tree item for space boundary geometry vertices
        private void CreateSBGeometryVertexTreeItem(TreeIfcItemView ifcParent, TreeIfcItemView ifcItem, Point2D p)
        {
            string strProperty = "Vertex: " + "(" + p.x.ToString() + ", " + p.y.ToString() + ")";
            if ((ifcParent != null) && (ifcParent.Node != null))
            {
                ifcItem.Node = ifcParent.Node.Nodes.Add(strProperty);
            }
            else
            {
                ifcItem.Node = _TreeView.Nodes.Add(strProperty);
            }

            if (ifcItem.Item == null)
            {
                // item without visual representation
                ifcItem.Node.ForeColor = Color.Gray;
            }

            ifcItem.Node.ImageIndex = ifcItem.Node.SelectedImageIndex = IMAGE_PROPERTY;
        }

        // create tree item for space boundary geometry vertices
        private void CreateSBGeometryVertexTreeItem(TreeIfcItemView ifcParent, TreeIfcItemView ifcItem, Point3D p)
        {
            string strProperty = "Vertex: " + "(" + p.x.ToString() + ", " + p.y.ToString() + ", " + p.z.ToString() + ")";
            if ((ifcParent != null) && (ifcParent.Node != null))
            {
                ifcItem.Node = ifcParent.Node.Nodes.Add(strProperty);
            }
            else
            {
                ifcItem.Node = _TreeView.Nodes.Add(strProperty);
            }

            if (ifcItem.Item == null)
            {
                // item without visual representation
                ifcItem.Node.ForeColor = Color.Gray;
            }

            ifcItem.Node.ImageIndex = ifcItem.Node.SelectedImageIndex = IMAGE_PROPERTY;
        }

        // find the ifcitem whose instance == iInstance;
        private IfcItem FindIfcItem(IfcItem ifcParent, Int64 iInstance)
        {
            if (ifcParent == null)
            {
                return null;
            }

            IfcItem ifcIterator = ifcParent;
            while (ifcIterator != null)
            {
                if (ifcIterator.instance == iInstance)
                {
                    return ifcIterator;
                }
                IfcItem ifcItem = FindIfcItem(ifcIterator.child, iInstance);
                if (ifcItem != null)
                {
                    return ifcItem;
                }
                ifcIterator = ifcIterator.next;
            }
            return FindIfcItem(ifcParent.child, iInstance);
        }

        // create sub nodes for each node： namely show the node name and associate the data source with the tree node
        // up-to-bottom approach
        private void CreateTreeItem(TreeIfcItemView ifcParent, TreeIfcItemView treeIfcItem)
        {
            // extract the node name, namely the node
            string strItemText = BuildItemText(treeIfcItem.Instance);
            if ((ifcParent != null) && (ifcParent.Node != null))
            {
                treeIfcItem.Node = ifcParent.Node.Nodes.Add(strItemText);  // IfcParent.node refers to the node of ifcparent which can have a series of sub nodes
                if (IsInstanceOf(treeIfcItem.Instance, "IfcSpace")) //add geometry item for IfcSpace
                {
                    treeIfcItem.Node.Nodes.Add("Space geometry");
                }
            }
            else
            {
                treeIfcItem.Node = _TreeView.Nodes.Add(strItemText);  // if this node does not have a parent node, then this node should be one of the root nodes of the whole treeview panel
            }

            if (treeIfcItem.Item == null)  // 当节点不存在Ifcitem (entity的属性)，设置节点前景色(看到的颜色)为灰；item without visual representation 
            {               
                treeIfcItem.Node.ForeColor = Color.Gray; 
            }

            //treeIfcItem.Node.Tag = treeIfcItem; //Node.Tag: 获取或设置包含树节点有关数据的对象; 然而SharpRenderer 并非从此出提取geometry for visualization; 而是 直接 从ifcItem 中

            if (IsInstanceOf(treeIfcItem.Instance, "IfcSpace"))
            {
                treeIfcItem.Node.Tag = treeIfcItem;
                treeIfcItem.Node.Nodes[0].Tag = treeIfcItem; // attach to the geometry item; Notice: SharpRenderer only process geometry attached to IfcSpace, not for the geometry item; the geometry ietm is just used for the visibility control of IfcSpace through the TreeIfcItemView.IsVisible
            }
            else
            {
                treeIfcItem.Node.Tag = treeIfcItem; //Node.Tag: 获取或设置包含树节点有关数据的对象；然而SharpRenderer 并非从此出提取geometry for visualization
            }
        }

        /// <summary>
        /// Helper
        /// </summary>
        /// <param name="tnParent"></param>
        /// <param name="strIfcType"></param>
        /// <param name="bCheck"></param>
        private void OnContextMenu_UpdateTreeElement(TreeNode tnParent, string strIfcType, bool bCheck)
        {
            if (tnParent.Tag != null)
            {
                OnContextMenu_UpdateTreeElement(tnParent.Tag as TreeIfcItemView, strIfcType, bCheck);
            }

            foreach (TreeNode tnChild in tnParent.Nodes)
            {
                OnContextMenu_UpdateTreeElement(tnChild, strIfcType, bCheck);
            }
        }

        /// <summary>
        /// Helper
        /// </summary>
        /// <param name="ifcTreeItem"></param>
        /// <param name="strIfcType"></param>
        /// <param name="bCheck"></param>
        private void OnContextMenu_UpdateTreeElement(TreeIfcItemView ifcTreeItem, string strIfcType, bool bCheck)
        {
            if (ifcTreeItem.Item == null)
            {
                // skip not referenced items
                return;
            }

            if (string.IsNullOrEmpty(ifcTreeItem.Item.ifcType) || (ifcTreeItem.Item.ifcType != strIfcType))
            {
                // filter the items 
                return;
            }

            if (bCheck)
            {
                ifcTreeItem.Node.ImageIndex = ifcTreeItem.Node.SelectedImageIndex = IMAGE_CHECKED;
            }
            else
            {
                ifcTreeItem.Node.ImageIndex = ifcTreeItem.Node.SelectedImageIndex = IMAGE_UNCHECKED;
            }

            UpdateChildrenTreeItems(ifcTreeItem.Node);
            UpdateParentTreeItems(ifcTreeItem.Node);
        }

        // Create the name (string) of the tree node: Entity Name + Name (Property; if exists) + Description (Property; if exists)
        private string BuildItemText(Int64 iInstance)
        {
            if (iInstance == 0)
            {
                System.Diagnostics.Debug.Assert(false);
                return string.Empty;
            }

            Int64 iType = IfcEngine.sdaiGetInstanceType(iInstance);
            IntPtr type = IntPtr.Zero;
            IfcEngine.engiGetEntityName(iType, IfcEngine.sdaiSTRING, out type);
            string strIfcType = Marshal.PtrToStringAnsi(type);

            Int64 instanceName = IfcEngine.internalGetP21Line(iInstance);
            string iN = "#" + instanceName.ToString();
            strIfcType = iN +" "+ strIfcType;

            if (!IsInstanceOf(iInstance, "IFCRELSPACEBOUNDARY2NDLEVEL") && !IsInstanceOf(iInstance, "IFCRELSPACEBOUNDARY"))
            {
                IntPtr name;
                IfcEngine.sdaiGetAttrBN(iInstance, "Name", IfcEngine.sdaiSTRING, out name);
                string strName = Marshal.PtrToStringAnsi(name);

                IntPtr description;
                IfcEngine.sdaiGetAttrBN(iInstance, "Description", IfcEngine.sdaiSTRING, out description);
                string strDescription = Marshal.PtrToStringAnsi(description);

                string strItemText = strIfcType + (string.IsNullOrEmpty(strName) ? "" : "-'" + strName + "'")
                    + (string.IsNullOrEmpty(strDescription) ? "" : "-'" + strDescription + "'");
                return strItemText;
            }
            else
            {
                return strIfcType;
            }
        }

        // check whether the iInstance represents the strTpe
        private bool IsInstanceOf(Int64 iInstance, string strType)
        {
            if (IfcEngine.sdaiGetInstanceType(iInstance) == IfcEngine.sdaiGetEntity(_IfcModel.ifcModel, strType))
            {
                return true;
            }
            return false;
        }

        #region FindNonReferencedIFCItems
        // NonReferencedIFCItems refer to the ifcitems that do not have ifctreeview but they are actually ifc entities
        // Check later whether we need it or not 
        //private void FindNonReferencedIFCItems(IfcItem ifcParent, TreeNode tnNotReferenced)
        //{
        //    if (ifcParent == null)
        //    {
        //        return;
        //    }

        //    IfcItem ifcIterator = ifcParent;
        //    while (ifcIterator != null)
        //    {
        //        if ((ifcIterator.ifcTreeView == null) && (ifcIterator.instance != 0))
        //        {
        //            string strItemText = BuildItemText(ifcIterator.instance);

        //            TreeIfcItemView ifcTreeItem = new TreeIfcItemView(ifcIterator.instance, FindIFCItem(_IfcModel.RootIfcItem, ifcIterator.instance));
        //            ifcTreeItem.Node = tnNotReferenced.Nodes.Add(strItemText);
        //            ifcIterator.ifcTreeView = ifcTreeItem;
        //            ifcTreeItem.Node.Tag = ifcTreeItem;

        //            if (ifcTreeItem.Item != null)
        //            {
        //                ifcTreeItem.Item.ifcTreeView = ifcTreeItem;
        //                ifcTreeItem.Node.ImageIndex = ifcTreeItem.Node.SelectedImageIndex = IMAGE_CHECKED;
        //            }
        //            else
        //            {
        //                ifcTreeItem.Node.ImageIndex = ifcTreeItem.Node.SelectedImageIndex = IMAGE_NOT_REFERENCED;
        //            }
        //        }

        //        FindNonReferencedIFCItems(ifcIterator.child, tnNotReferenced);

        //        ifcIterator = ifcIterator.next;
        //    }

        //    FindNonReferencedIFCItems(ifcParent.child, tnNotReferenced);
        //}
        #endregion

        // update the status of childrenItems after changing (clicking) one item
        private void UpdateChildrenTreeItems(TreeNode tnParent)
        {
            foreach (TreeNode tnChild in tnParent.Nodes)
            {
                if ((tnChild.ImageIndex != IMAGE_CHECKED) && (tnChild.ImageIndex != IMAGE_UNCHECKED) && (tnChild.ImageIndex != IMAGE_MIDDLE))           
                    continue; // skip properties

                switch (tnParent.ImageIndex)
                {
                    case IMAGE_CHECKED:
                    case IMAGE_MIDDLE:
                        {
                            tnChild.ImageIndex = tnChild.SelectedImageIndex = IMAGE_CHECKED;
                        }
                        break;

                    case IMAGE_UNCHECKED:
                        {
                            tnChild.ImageIndex = tnChild.SelectedImageIndex = IMAGE_UNCHECKED;
                        }
                        break;
                } 
                UpdateChildrenTreeItems(tnChild);
            } 
        }

        // update the status of parentItems after changing (clicking) one item
        private void UpdateParentTreeItems(TreeNode tnItem)
        {
            if (tnItem.Parent == null)
                return;

            int iCheckedChildrenCount = 0;
            bool bMiddleStateChild = false;
            foreach (TreeNode tnChild in tnItem.Parent.Nodes)
            {
                if (tnChild.ImageIndex == IMAGE_MIDDLE)
                    bMiddleStateChild = true;

                if (tnChild.ImageIndex == IMAGE_CHECKED)
                    iCheckedChildrenCount++;
            }

            if (!bMiddleStateChild)
            {
                if (iCheckedChildrenCount > 0)
                {
                    tnItem.Parent.ImageIndex = tnItem.Parent.SelectedImageIndex =
                        iCheckedChildrenCount == tnItem.Parent.Nodes.Count ? IMAGE_CHECKED : IMAGE_MIDDLE;
                }
                else
                {
                    tnItem.Parent.ImageIndex = tnItem.Parent.SelectedImageIndex = IMAGE_UNCHECKED;
                }
            }
            else
            {
                tnItem.Parent.ImageIndex = tnItem.Parent.SelectedImageIndex = IMAGE_MIDDLE;
            }
            UpdateParentTreeItems(tnItem.Parent);
        }

        //必须要有，因为IfcTreeView 继承了一个interface “IfcViewer”
        public IfcRenderer Renderer
        {
            get;
            set;
        }

        //必须要有，因为IfcTreeView 继承了一个interface “IfcViewer”
        public void OnSelect(IfcItem ifcItem)
        {
            System.Diagnostics.Debug.Assert(ifcItem != null, "Internal error.");

            TreeIfcItemView treeItem = ifcItem.ifcItemView as TreeIfcItemView;
            System.Diagnostics.Debug.Assert(treeItem != null, "Internal error.");
            System.Diagnostics.Debug.Assert(treeItem.Node != null, "Internal error.");

            _TreeView.SelectedNode = treeItem.Node;
        } 
    }
}
