﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Threading;
using System.Runtime.InteropServices;

namespace SecondLevelSBValidation
{
    public partial class SecondLevelSBValidation : Form
    {
        IfcModel ifcModel = null;
        IfcRenderer ifcRenderer = null;
        IfcViewer ifcViewer = null;
        string IfcFilePath;

        bool checkingExecuted_SSV = false;
        bool checkingExecuted_GV = false;
        bool checkingExecuted_CV = false;
        RuleChecking_SSV checkingResults_SSV = new RuleChecking_SSV();
        RuleChecking_GV checkingResults_GV = new RuleChecking_GV();
        RuleChecking_CV checkingResults_CV = new RuleChecking_CV();
        List<IfcBuildingElement> Elements_IfcModel2019 = new List<IfcBuildingElement>();  // IfcModel2019 (involve the deletion of some instances for element geometry extraction) is independent from IfcModel (original one used for visualization and all other data extraction) 
        Dictionary<BuildingElementType, List<Int64>> elementTypes = new Dictionary<BuildingElementType, List<Int64>>();
        float dimensionalScale; // mm = 1; cm = 10; m = 1000
        List<IfcRelSpaceBoundary> SBs = new List<IfcRelSpaceBoundary>();

        public SecondLevelSBValidation()
        {
            this.SetStyle(ControlStyles.AllPaintingInWmPaint, true); //禁止擦除背景: if true，控件忽略 WM_ERASEBKGND 窗口消息以减少闪烁。仅当 UserPaint 设置为 true 时，才应用该样式。
            this.SetStyle(ControlStyles.UserPaint, true); //自绘: 控件将自行绘制，而不是通过操作系统来绘制           
            InitializeComponent();
            ifcModel = new IfcModel();
            ifcViewer = new IfcTreeView(ifcModel, IfcSBTree);
            ifcRenderer = new SharpDXRenderer(ifcModel, this.splitContainer_Visualization.Panel2); // VisualizationPanel refers to the panle used to visualize the geometry
            ifcViewer.Renderer = ifcRenderer;
            ifcRenderer.Viewer = ifcViewer;

            RuleDescription RD = new RuleDescription();

            treeView_CheckingRules.NodeMouseClick += (s, e) =>
            {
                if (e.Button == MouseButtons.Left)
                {
                    if (e.Node == treeView_CheckingRules.Nodes[0].Nodes[0].Nodes[0])
                    {
                        textBox_RuleDescription.Text = RD.SR_0;
                        if (checkingExecuted_SSV)
                        {
                            if (treeView_CheckingRules.Nodes[0].Nodes[0].Nodes[0].BackColor == Color.Red)
                            {
                                treeView_ResultReporting.Nodes.Clear();
                                SR_0_1_RuleReporting(checkingResults_SSV.SRC_0_1);
                                SR_0_2_RuleReporting(checkingResults_SSV.SRC_0_2);
                            }
                            else
                                treeView_ResultReporting.Nodes.Clear();
                        }
                    }
                    else if (e.Node == treeView_CheckingRules.Nodes[0].Nodes[0].Nodes[1])
                    {
                        textBox_RuleDescription.Text = RD.SR_1;
                        if (checkingExecuted_SSV)
                        {
                            if (treeView_CheckingRules.Nodes[0].Nodes[0].Nodes[1].BackColor == Color.Red)
                            {
                                treeView_ResultReporting.Nodes.Clear();
                                SR_1_1_RuleReporting(checkingResults_SSV.SRC_1_1);
                                SR_1_2_RuleReporting(checkingResults_SSV.SRC_1_2);
                            }
                            else
                                treeView_ResultReporting.Nodes.Clear();
                        }
                    }
                    else if (e.Node == treeView_CheckingRules.Nodes[0].Nodes[0].Nodes[2])
                    {
                        textBox_RuleDescription.Text = RD.SR_2;
                        if (checkingExecuted_SSV)
                        {
                            if (treeView_CheckingRules.Nodes[0].Nodes[0].Nodes[2].BackColor == Color.Red)
                            {
                                treeView_ResultReporting.Nodes.Clear();
                                SR_2_1_RuleReporting(checkingResults_SSV.SRC_2_1);
                                SR_2_2_RuleReporting(checkingResults_SSV.SRC_2_2);
                            }
                            else
                                treeView_ResultReporting.Nodes.Clear();

                        }
                    }
                    else if (e.Node == treeView_CheckingRules.Nodes[0].Nodes[0].Nodes[3])
                    {
                        textBox_RuleDescription.Text = RD.SR_3;
                        if (checkingExecuted_SSV)
                        {
                            if (treeView_CheckingRules.Nodes[0].Nodes[0].Nodes[3].BackColor == Color.Red)
                            {
                                treeView_ResultReporting.Nodes.Clear();
                                SR_3_1_RuleReporting(checkingResults_SSV.SRC_3_1);
                            }
                            else
                                treeView_ResultReporting.Nodes.Clear();
                        }
                    }
                    else if (e.Node == treeView_CheckingRules.Nodes[0].Nodes[0].Nodes[4])
                    {
                        textBox_RuleDescription.Text = RD.SR_4;
                        if (checkingExecuted_SSV)
                        {
                            if (treeView_CheckingRules.Nodes[0].Nodes[0].Nodes[4].BackColor == Color.Red)
                            {
                                treeView_ResultReporting.Nodes.Clear();
                                SR_4_1_RuleReporting(checkingResults_SSV.SRC_4_1);
                            }
                            else
                                treeView_ResultReporting.Nodes.Clear();
                        }
                    }

                    // GV reporting
                    if (e.Node == treeView_CheckingRules.Nodes[0].Nodes[1].Nodes[0])
                    {
                        textBox_RuleDescription.Text = RD.GR_1;
                        if (checkingExecuted_GV)
                        {
                            if (treeView_CheckingRules.Nodes[0].Nodes[1].Nodes[0].BackColor == Color.Red)
                            {
                                treeView_ResultReporting.Nodes.Clear();
                                GR_1_1_RuleReporting(checkingResults_GV.GRC_1_1);
                                GR_1_2_RuleReporting(checkingResults_GV.GRC_1_2);
                            }
                            else
                                treeView_ResultReporting.Nodes.Clear();
                        }
                    }
                    else if (e.Node == treeView_CheckingRules.Nodes[0].Nodes[1].Nodes[1])
                    {
                        textBox_RuleDescription.Text = RD.GR_2;
                        if (checkingExecuted_GV)
                        {
                            if (treeView_CheckingRules.Nodes[0].Nodes[1].Nodes[1].BackColor == Color.Red)
                            {
                                treeView_ResultReporting.Nodes.Clear();
                                GR_2_RuleReporting(checkingResults_GV.GRC_2);
                            }
                            else
                                treeView_ResultReporting.Nodes.Clear();
                        }
                    }
                   
                    // CV reporting
                    if (e.Node == treeView_CheckingRules.Nodes[0].Nodes[2].Nodes[0])
                    {
                        textBox_RuleDescription.Text = RD.CR_1;
                        if (checkingExecuted_CV)
                        {
                            if (treeView_CheckingRules.Nodes[0].Nodes[2].Nodes[0].BackColor == Color.Red)
                            {
                                treeView_ResultReporting.Nodes.Clear();
                                CR_1_RuleReporting(checkingResults_CV.CRC_1);
                                CR_1_6_RuleReporting(checkingResults_CV.CRC_1_6);
                            }
                            else
                                treeView_ResultReporting.Nodes.Clear();
                        }
                    }
                    else if (e.Node == treeView_CheckingRules.Nodes[0].Nodes[2].Nodes[1])
                    {
                        textBox_RuleDescription.Text = RD.CR_2;
                        if (checkingExecuted_CV)
                        {
                            if (treeView_CheckingRules.Nodes[0].Nodes[2].Nodes[1].BackColor == Color.Red)
                            {
                                treeView_ResultReporting.Nodes.Clear();
                                CR_2_RuleReporting(checkingResults_CV.CRC_2);
                            }
                            else
                                treeView_ResultReporting.Nodes.Clear();
                        }
                    }

                    else if (e.Node == treeView_CheckingRules.Nodes[0].Nodes[2].Nodes[2])
                    {
                        textBox_RuleDescription.Text = RD.CR_3;
                        if (checkingExecuted_CV)
                        {
                            if (treeView_CheckingRules.Nodes[0].Nodes[2].Nodes[2].BackColor == Color.Red)
                            {
                                treeView_ResultReporting.Nodes.Clear();
                                CR_3_RuleReporting(checkingResults_CV.CRC_3);
                            }
                            else
                                treeView_ResultReporting.Nodes.Clear();
                        }
                    }
                    else if (e.Node == treeView_CheckingRules.Nodes[0].Nodes[2].Nodes[3])
                    {
                        textBox_RuleDescription.Text = RD.CR_4;
                        if (checkingExecuted_CV)
                        {
                            if (treeView_CheckingRules.Nodes[0].Nodes[2].Nodes[3].BackColor == Color.Red)
                            {
                                treeView_ResultReporting.Nodes.Clear();
                                CR_4_RuleReporting(checkingResults_CV.CRC_4);
                            }
                            else
                                treeView_ResultReporting.Nodes.Clear();
                        }
                    }
                    else if (e.Node == treeView_CheckingRules.Nodes[0].Nodes[2].Nodes[4])
                    {
                        textBox_RuleDescription.Text = RD.CR_5;
                        if (checkingExecuted_CV)
                        {
                            if (treeView_CheckingRules.Nodes[0].Nodes[2].Nodes[4].BackColor == Color.Red)
                            {
                                treeView_ResultReporting.Nodes.Clear();
                                CR_5_RuleReporting(checkingResults_CV.CRC_5);
                            }
                            else
                                treeView_ResultReporting.Nodes.Clear();
                        }
                    }
                }
            };

            treeView_ResultReporting.NodeMouseClick += (s, e) =>
            {
                if (treeView_ResultReporting.Nodes.Count != 0)
                {
                    if (e.Button == MouseButtons.Left)
                    {
                        string text = e.Node.ToString();
                        string[] split = text.Split(' ');

                        // detect instances (SB and space only)
                        List<string> instances = new List<string>();
                        for (int i = 0; i < split.Count(); i++)
                        {
                            if (split[i].Contains("#"))
                            {
                                if (split[i + 1] == "IfcRelSpaceBoundary2ndLevel" || split[i + 1] == "IfcSpace")
                                    instances.Add(split[i] + " ");
                            }
                        }

                        if (instances.Count != 0)
                        {
                            // Initialize all tree Nodes of IfcSBTree to original white color
                            InitializeTreeNodesColor(IfcSBTree.Nodes[0]);

                            // Hightlight the exact instances as well as relevant parent instances in IfcSBTree
                            foreach (var item in instances)
                            {
                                HighlightRelevantTreeNodes(IfcSBTree.Nodes[0], item);
                            }
                        }
                    }
                }
            };
        }

        // Reset color of all tree nodes as the default one
        private void InitializeTreeNodesColor(TreeNode rootNode)
        {
            rootNode.BackColor = Color.White;
            foreach (TreeNode child in rootNode.Nodes)
            {
                child.BackColor = Color.White;
                string text = child.ToString();
                InitializeTreeNodesColor(child);
            }
        }
    
        private void HighlightRelevantTreeNodes(TreeNode rooteNode, string instanceName)
        {
            // Top-down search and hightlight the exact instances
            foreach (TreeNode Child in rooteNode.Nodes)
            {
                string text = Child.ToString();
                if (text.Contains(instanceName) && Child.ForeColor != Color.Gray) // Node.ForeColor == Color.Gray means that the node is a property
                {
                    Child.BackColor = Color.Red;          
                    BottomUpSearchParentTreeNodes(Child);  // Bottom-up search and hight their parent nodes (until IfcBuilding level)
                    break;
                }
                HighlightRelevantTreeNodes(Child, instanceName);
            }
        }

        // update the status of parentItems after changing (clicking) one item
        private void BottomUpSearchParentTreeNodes(TreeNode childNode)
        {
            if (childNode.Parent == null)
                return;
            else
            {
                string text = childNode.Parent.ToString();
                if (text.Contains("IfcSite"))
                    return;
                else
                {
                    childNode.Parent.BackColor = Color.Red;
                    BottomUpSearchParentTreeNodes(childNode.Parent);
                }
            }
        }

        #region Checking Result Reporting 

        public void SR_0_1_RuleReporting(SR_0_1_RuleChecking SRC_0_1)
        {
            if (SRC_0_1.hasErrors)
            {
                treeView_ResultReporting.Nodes.Add(SRC_0_1.errorReporting);
                int num = treeView_ResultReporting.Nodes.Count;
                foreach (var e in SRC_0_1.IfcCartesianPoint_SB)
                {
                    treeView_ResultReporting.Nodes[num - 1].Nodes.Add(e);
                }
            }
        }

        public void SR_0_2_RuleReporting(SR_0_2_RuleChecking SRC_0_2)
        {
            if (SRC_0_2.hasErrors)
            {
                treeView_ResultReporting.Nodes.Add(SRC_0_2.errorReporting);
                int num = treeView_ResultReporting.Nodes.Count;
                foreach (var e in SRC_0_2.IfcCartesianPoint_SB)
                {
                    treeView_ResultReporting.Nodes[num - 1].Nodes.Add(e);
                }
            }
        }

        public void SR_1_1_RuleReporting(SR_1_1_RuleChecking SRC_1_1)
        {
            if (SRC_1_1.hasErrors)
            {
                treeView_ResultReporting.Nodes.Add(SRC_1_1.errorReporting);
                int num = treeView_ResultReporting.Nodes.Count;
                foreach (var sb in SRC_1_1.failingSBs)
                {
                    treeView_ResultReporting.Nodes[num-1].Nodes.Add(sb);
                }
            }
        }

        public void SR_1_2_RuleReporting(SR_1_2_RuleChecking SRC_1_2)
        {
            if (SRC_1_2.hasErrors)
            {
                if (SRC_1_2.failingSBs_eR1.Count != 0)
                {
                    treeView_ResultReporting.Nodes.Add(SRC_1_2.errorReporting_1);
                    int num = treeView_ResultReporting.Nodes.Count;
                    foreach (var sb in SRC_1_2.failingSBs_eR1)
                    {
                        treeView_ResultReporting.Nodes[num - 1].Nodes.Add(sb);
                    }
                }

                if (SRC_1_2.failingSBs_eR2.Count != 0)
                {
                    treeView_ResultReporting.Nodes.Add(SRC_1_2.errorReporting_2);
                    int num = treeView_ResultReporting.Nodes.Count;
                    foreach (var sb in SRC_1_2.failingSBs_eR2)
                    {
                        treeView_ResultReporting.Nodes[num - 1].Nodes.Add(sb);
                    }
                }

                if (SRC_1_2.failingSBs_eR3.Count != 0)
                {
                    treeView_ResultReporting.Nodes.Add(SRC_1_2.errorReporting_3);
                    int num = treeView_ResultReporting.Nodes.Count;
                    foreach (var sb in SRC_1_2.failingSBs_eR3)
                    {
                        treeView_ResultReporting.Nodes[num - 1].Nodes.Add(sb);
                    }
                }
            }
        }

        public void SR_2_1_RuleReporting(SR_2_1_RuleChecking SRC_2_1)
        {
            if (SRC_2_1.hasErrors)
            {
                treeView_ResultReporting.Nodes.Add(SRC_2_1.errorReporting);
                int num = treeView_ResultReporting.Nodes.Count;
                foreach (var element in SRC_2_1.failingBuildingElements)
                {
                    treeView_ResultReporting.Nodes[num - 1].Nodes.Add(element);
                }
            }
        }

        public void SR_2_2_RuleReporting(SR_2_2_RuleChecking SRC_2_2)
        {
            if (SRC_2_2.hasErrors)
            {
                treeView_ResultReporting.Nodes.Add(SRC_2_2.errorReporting);
                int num = treeView_ResultReporting.Nodes.Count;
                foreach (var element in SRC_2_2.failingBuildingElements)
                {
                    treeView_ResultReporting.Nodes[num - 1].Nodes.Add(element);
                }
            }
        }

        public void SR_3_1_RuleReporting(SR_3_1_RuleChecking SRC_3_1)
        {
            if (SRC_3_1.hasErrors)
            {
                treeView_ResultReporting.Nodes.Add(SRC_3_1.errorReporting);
                int num = treeView_ResultReporting.Nodes.Count;
                foreach (var element in SRC_3_1.SB_CorrespondingOpening)
                {
                    treeView_ResultReporting.Nodes[num - 1].Nodes.Add(element.Key + " -> " + element.Value);
                }
            }
        }

        public void SR_4_1_RuleReporting(SR_4_1_RuleChecking SRC_4_1)
        {
            if (SRC_4_1.hasErrors)
            {
                treeView_ResultReporting.Nodes.Add(SRC_4_1.errorReporting);
                int num = treeView_ResultReporting.Nodes.Count;
                foreach (var element in SRC_4_1.SB_AggregrateContainerElement)
                {
                    treeView_ResultReporting.Nodes[num - 1].Nodes.Add(element.Key + " -> " + element.Value);
                }
            }
        }

        public void GR_1_1_RuleReporting(GR_1_1_RuleChecking GRC_1_1)
        {
            if (GRC_1_1.hasErrors)
            {
                treeView_ResultReporting.Nodes.Add(GRC_1_1.errorReporting);
                int num = treeView_ResultReporting.Nodes.Count;
                foreach (var sb in GRC_1_1.failingSBs_eR)
                {
                    treeView_ResultReporting.Nodes[num - 1].Nodes.Add(sb);
                }
            }
        }

        public void GR_1_2_RuleReporting(GR_1_2_RuleChecking GRC_1_2)
        {
            if (GRC_1_2.hasErrors)
            {
                if (GRC_1_2.failingSBs_eR1.Count != 0)
                {
                    treeView_ResultReporting.Nodes.Add(GRC_1_2.errorReporting_1);
                    int num = treeView_ResultReporting.Nodes.Count;
                    foreach (var sb in GRC_1_2.failingSBs_eR1)
                    {
                        treeView_ResultReporting.Nodes[num - 1].Nodes.Add(sb);
                    }
                }
            
                if (GRC_1_2.failingSBs_eR2.Count != 0)
                {
                    treeView_ResultReporting.Nodes.Add(GRC_1_2.errorReporting_2);
                    int num2 = treeView_ResultReporting.Nodes.Count;
                    foreach (var sb in GRC_1_2.failingSBs_eR2)
                    {
                        treeView_ResultReporting.Nodes[num2 - 1].Nodes.Add(sb);
                    }
                }              
            }
        }

        public void GR_2_RuleReporting(GR_2_RuleChecking GRC_2)
        {
            if (GRC_2.hasErrors)
            {
                treeView_ResultReporting.Nodes.Add(GRC_2.errorReporting);
                int num = treeView_ResultReporting.Nodes.Count;
                foreach (var item in GRC_2.failingSpaces_error)
                {
                    treeView_ResultReporting.Nodes[num - 1].Nodes.Add(item.Key + " (" + item.Value +")");
                }
            }
        }

        public void CR_1_RuleReporting(CR_1_RuleChecking CRC_1)
        {
            if (CRC_1.hasErrors)
            {
                if (CRC_1.failingSBs_eR1.Count != 0)
                {
                    treeView_ResultReporting.Nodes.Add(CRC_1.errorReporting_1);
                    int num = treeView_ResultReporting.Nodes.Count;
                    foreach (var sb in CRC_1.failingSBs_eR1)
                    {
                        treeView_ResultReporting.Nodes[num - 1].Nodes.Add(sb);
                    }
                }

                if (CRC_1.failingSBs_eR2.Count != 0)
                {
                    treeView_ResultReporting.Nodes.Add(CRC_1.errorReporting_2);
                    int num = treeView_ResultReporting.Nodes.Count;
                    foreach (var sb in CRC_1.failingSBs_eR2)
                    {
                        treeView_ResultReporting.Nodes[num - 1].Nodes.Add(sb);
                    }
                }

                if (CRC_1.failingSBs_eR3.Count != 0)
                {
                    treeView_ResultReporting.Nodes.Add(CRC_1.errorReporting_3);
                    int num = treeView_ResultReporting.Nodes.Count;
                    foreach (var sb in CRC_1.failingSBs_eR3)
                    {
                        treeView_ResultReporting.Nodes[num - 1].Nodes.Add(sb);
                    }
                }

                if (CRC_1.failingSBs_eR4.Count != 0)
                {
                    treeView_ResultReporting.Nodes.Add(CRC_1.errorReporting_4);
                    int num = treeView_ResultReporting.Nodes.Count;
                    foreach (var sb in CRC_1.failingSBs_eR4)
                    {
                        treeView_ResultReporting.Nodes[num - 1].Nodes.Add(sb);
                    }
                }

                if (CRC_1.failingSBs_eR5.Count != 0)
                {
                    treeView_ResultReporting.Nodes.Add(CRC_1.errorReporting_5);
                    int num = treeView_ResultReporting.Nodes.Count;
                    foreach (var sb in CRC_1.failingSBs_eR5)
                    {
                        treeView_ResultReporting.Nodes[num - 1].Nodes.Add(sb);
                    }
                }
            }
        }

        public void CR_1_6_RuleReporting(CR_1_6_RuleChecking CRC_1_6)
        {
            if (CRC_1_6.hasErrors)
            {
                treeView_ResultReporting.Nodes.Add(CRC_1_6.errorReporting);
                int num = treeView_ResultReporting.Nodes.Count;
                foreach (var sb in CRC_1_6.failingSBs)
                {
                    treeView_ResultReporting.Nodes[num - 1].Nodes.Add(sb);
                }
            }
        }

        public void CR_2_RuleReporting(CR_2_RuleChecking CRC_2)
        {
            if (CRC_2.hasErrors)
            {
                if (CRC_2.failingSBs_eR1.Count != 0)
                {
                    treeView_ResultReporting.Nodes.Add(CRC_2.errorReporting_1);
                    int num = treeView_ResultReporting.Nodes.Count;
                    foreach (var sb in CRC_2.failingSBs_eR1)
                    {
                        treeView_ResultReporting.Nodes[num - 1].Nodes.Add(sb);
                    }
                }
                if (CRC_2.failingSBs_eR2.Count != 0)
                {
                    treeView_ResultReporting.Nodes.Add(CRC_2.errorReporting_2);
                    int num = treeView_ResultReporting.Nodes.Count;
                    foreach (var sb in CRC_2.failingSBs_eR2)
                    {
                        treeView_ResultReporting.Nodes[num - 1].Nodes.Add(sb);
                    }
                }
            }
        }

        public void CR_3_RuleReporting(CR_3_RuleChecking CRC_3)
        {
            if (CRC_3.hasErrors)
            {
                if (CRC_3.failingSBs_eR1.Count != 0)
                {
                    treeView_ResultReporting.Nodes.Add(CRC_3.errorReporting_1);
                    int num = treeView_ResultReporting.Nodes.Count;
                    foreach (var sb in CRC_3.failingSBs_eR1)
                    {
                        treeView_ResultReporting.Nodes[num - 1].Nodes.Add(sb);
                    }
                }

                if (CRC_3.failingSBs_eR2.Count != 0)
                {
                    treeView_ResultReporting.Nodes.Add(CRC_3.errorReporting_2);
                    int num = treeView_ResultReporting.Nodes.Count;
                    foreach (var sb in CRC_3.failingSBs_eR2)
                    {
                        treeView_ResultReporting.Nodes[num - 1].Nodes.Add(sb);
                    }
                }
            }
        }

        public void CR_4_RuleReporting(CR_4_RuleChecking CRC_4)
        {
            if (CRC_4.hasErrors)
            {
                if (CRC_4.failingSBs_eR1.Count != 0)
                {
                    treeView_ResultReporting.Nodes.Add(CRC_4.errorReporting_1);
                    int num = treeView_ResultReporting.Nodes.Count;
                    foreach (var sb in CRC_4.failingSBs_eR1)
                    {
                        treeView_ResultReporting.Nodes[num - 1].Nodes.Add(sb);
                    }
                }

                if (CRC_4.failingSBs_eR2.Count != 0)
                {
                    treeView_ResultReporting.Nodes.Add(CRC_4.errorReporting_2);
                    int num = treeView_ResultReporting.Nodes.Count;
                    foreach (var sb in CRC_4.failingSBs_eR2)
                    {
                        treeView_ResultReporting.Nodes[num - 1].Nodes.Add(sb);
                    }
                }
            }
        }

        public void CR_5_RuleReporting(CR_5_RuleChecking CRC_5)
        {
            if (CRC_5.hasErrors)
            {
                treeView_ResultReporting.Nodes.Add(CRC_5.errorReporting);
                int num = treeView_ResultReporting.Nodes.Count;
                foreach (var item in CRC_5.failingCorrespondingSBs)
                {
                    treeView_ResultReporting.Nodes[num - 1].Nodes.Add(item.Key + " <-> " + item.Value);
                }
            }
        }

        #endregion

        private void sSVToolStripMenuItem_Click(object sender, EventArgs e)
        {
            checkingResults_SSV = new RuleChecking_SSV(ifcModel.ifcModel, SBs, elementTypes);
            checkingExecuted_SSV = true;
            bool SRC_red = false;

            if (checkingResults_SSV.SRC_0_1.hasErrors || checkingResults_SSV.SRC_0_2.hasErrors)
            {
                treeView_CheckingRules.Nodes[0].Nodes[0].Nodes[0].BackColor = Color.Red;
                SRC_red = true;
            }
            else
                treeView_CheckingRules.Nodes[0].Nodes[0].Nodes[0].BackColor = Color.GreenYellow;

            if (checkingResults_SSV.SRC_1_1.hasErrors || checkingResults_SSV.SRC_1_2.hasErrors)
            {
                treeView_CheckingRules.Nodes[0].Nodes[0].Nodes[1].BackColor = Color.Red;
                SRC_red = true;
            }
            else
                treeView_CheckingRules.Nodes[0].Nodes[0].Nodes[1].BackColor = Color.GreenYellow;

            if (checkingResults_SSV.SRC_2_1.hasErrors || checkingResults_SSV.SRC_2_2.hasErrors)
            {
                SRC_red = true;
                treeView_CheckingRules.Nodes[0].Nodes[0].Nodes[2].BackColor = Color.Red;
            }
            else
                treeView_CheckingRules.Nodes[0].Nodes[0].Nodes[2].BackColor = Color.GreenYellow;

            if (checkingResults_SSV.SRC_3_1.hasErrors)
            {
                treeView_CheckingRules.Nodes[0].Nodes[0].Nodes[3].BackColor = Color.Red;
                SRC_red = true;
            }
            else
                treeView_CheckingRules.Nodes[0].Nodes[0].Nodes[3].BackColor = Color.GreenYellow;

            if (checkingResults_SSV.SRC_4_1.hasErrors)
            {
                SRC_red = true;
                treeView_CheckingRules.Nodes[0].Nodes[0].Nodes[4].BackColor = Color.Red;
            }
            else
                treeView_CheckingRules.Nodes[0].Nodes[0].Nodes[4].BackColor = Color.GreenYellow;

            if (SRC_red)
                treeView_CheckingRules.Nodes[0].Nodes[0].BackColor = Color.Red;
            else
                treeView_CheckingRules.Nodes[0].Nodes[0].BackColor = Color.GreenYellow;          
        }

        private void gVToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // SBs failing SSV (i.e. have less than three vertices) are excluded in the function
            checkingResults_GV = new RuleChecking_GV(ifcModel.ifcModel, SBs, dimensionalScale, elementTypes, Elements_IfcModel2019); 
            checkingExecuted_GV = true;

            bool GRC_red = false;
            if (checkingResults_GV.GRC_1_1.hasErrors || checkingResults_GV.GRC_1_2.hasErrors)
            {
                GRC_red = true;
                treeView_CheckingRules.Nodes[0].Nodes[1].Nodes[0].BackColor = Color.Red;
            }
            else
                treeView_CheckingRules.Nodes[0].Nodes[1].Nodes[0].BackColor = Color.GreenYellow;

            if (checkingResults_GV.GRC_2.hasErrors)
            {
                GRC_red = true;
                treeView_CheckingRules.Nodes[0].Nodes[1].Nodes[1].BackColor = Color.Red;
            }
            else
                treeView_CheckingRules.Nodes[0].Nodes[1].Nodes[1].BackColor = Color.GreenYellow;

            if (GRC_red)
                treeView_CheckingRules.Nodes[0].Nodes[1].BackColor = Color.Red;
            else
                treeView_CheckingRules.Nodes[0].Nodes[1].BackColor = Color.GreenYellow;         
        }

        private void cVToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // !!! Different CV rules actually have dependencies on specifc Type 1 & Type 2 SSV rules.
            // !!! Currently we directly exclude SBs failing all Typ1 & Type 2SSV rules for CV implementatation for simplication 
            // !!! This will not affect the results in the practice once the validations are conducted according to the proposed validation framework. 
            //List<String> SBInstances_FailingTyp1_Type2SSV = new List<string>();
            //List<IfcRelSpaceBoundary> SBs_PassingTyp1_Type2SSV = new List<IfcRelSpaceBoundary>(); // Need manually add
            //foreach (var sb in SBs)
            //{
            //    if (!SBInstances_FailingTyp1_Type2SSV.Contains(sb.InstanceName))
            //        SBs_PassingSSV.Add(sb);
            //}

            checkingResults_CV = new RuleChecking_CV(ifcModel.ifcModel, Elements_IfcModel2019, SBs, dimensionalScale, elementTypes, checkingResults_GV.GRC_1_1.failingSBs_instanceNames, checkingResults_GV.GRC_1_2.failingSBs_instanceNames);
            checkingExecuted_CV = true;

            bool CRC_red = false;
            if (checkingResults_CV.CRC_1.hasErrors || checkingResults_CV.CRC_1_6.hasErrors)
            {
                CRC_red = true;
                treeView_CheckingRules.Nodes[0].Nodes[2].Nodes[0].BackColor = Color.Red;
            }
            else
                treeView_CheckingRules.Nodes[0].Nodes[2].Nodes[0].BackColor = Color.GreenYellow;

            if (checkingResults_CV.CRC_2.hasErrors)
            {
                CRC_red = true;
                treeView_CheckingRules.Nodes[0].Nodes[2].Nodes[1].BackColor = Color.Red;
            }
            else
                treeView_CheckingRules.Nodes[0].Nodes[2].Nodes[1].BackColor = Color.GreenYellow;

            if (checkingResults_CV.CRC_3.hasErrors)
            {
                CRC_red = true;
                treeView_CheckingRules.Nodes[0].Nodes[2].Nodes[2].BackColor = Color.Red;
            }
            else
                treeView_CheckingRules.Nodes[0].Nodes[2].Nodes[2].BackColor = Color.GreenYellow;

            if (checkingResults_CV.CRC_4.hasErrors)
            {
                CRC_red = true;
                treeView_CheckingRules.Nodes[0].Nodes[2].Nodes[3].BackColor = Color.Red;
            }
            else
                treeView_CheckingRules.Nodes[0].Nodes[2].Nodes[3].BackColor = Color.GreenYellow;

            if (checkingResults_CV.CRC_5.hasErrors)
            {
                CRC_red = true;
                treeView_CheckingRules.Nodes[0].Nodes[2].Nodes[4].BackColor = Color.Red;
            }
            else
                treeView_CheckingRules.Nodes[0].Nodes[2].Nodes[4].BackColor = Color.GreenYellow;

            if (CRC_red)
                treeView_CheckingRules.Nodes[0].Nodes[2].BackColor = Color.Red;
            else
                treeView_CheckingRules.Nodes[0].Nodes[2].BackColor = Color.GreenYellow;
        }

        private List<IfcBuildingElement> BuildingElementsExtraction(Int64 IfcModel)
        {
            List<IfcBuildingElement> Elements = new List<IfcBuildingElement>();

            // Column
            List<IfcBuildingElement> Columns_1 = ExtractObjects(IfcModel, "IfcColumnStandardCase");
            Elements.AddRange(Columns_1);

            List<IfcBuildingElement> Columns_2 = ExtractObjects(IfcModel, "IfcColumn");
            Elements.AddRange(Columns_2);

            // Beam
            List<IfcBuildingElement> Beams_1 = ExtractObjects(IfcModel, "IfcBeamStandardCase");
            Elements.AddRange(Beams_1);

            List<IfcBuildingElement> Beams_2 = ExtractObjects(IfcModel, "IfcBeam");
            Elements.AddRange(Beams_2);

            // Ceiling
            List<IfcBuildingElement> ceilings = ExtractObjects(IfcModel, "IfcCovering");
            Elements.AddRange(ceilings);

            // Explicitly defined Shading device
            List<IfcBuildingElement> ShadingDevices = ExtractObjects(IfcModel, "IfcShadingDevice");
            Elements.AddRange(ShadingDevices);

            // Window
            List<IfcBuildingElement> Windows_1 = ExtractObjects(IfcModel, "IfcWindowStandardCase");
            Elements.AddRange(Windows_1);

            List<IfcBuildingElement> Windows_2 = ExtractObjects(IfcModel, "IfcWindow");
            Elements.AddRange(Windows_2);

            // Door
            List<IfcBuildingElement> doors_1 = ExtractObjects(IfcModel, "IfcDoorStandardCase");
            Elements.AddRange(doors_1);

            List<IfcBuildingElement> doors_2 = ExtractObjects(IfcModel, "IfcDoor");
            Elements.AddRange(doors_2);

            // True opening element (that do not fill windows/doors)
            List<IfcBuildingElement> Openings_1 = ExtractObjects(IfcModel, "IfcOpeningStandardCase");
            Elements.AddRange(Openings_1);

            List<IfcBuildingElement> Openings_2 = ExtractObjects(IfcModel, "IfcOpeningElement");
            Elements.AddRange(Openings_2);

            // Curtain Wall: no "HasOpening" attribute
            List<IfcBuildingElement> CurtainWalls = ExtractObjects(IfcModel, "IfcCurtainWall");
            Elements.AddRange(CurtainWalls);


            // !!!: Must be put at the last as it will delete IfcRelVoidsElement instances for extracting IfcWallInstance/IfcSlab/IfcRoof geometries
            // Wall
            List<IfcBuildingElement> Walls_1 = ExtractObjects(IfcModel, "IfcWallStandardCase");
            Elements.AddRange(Walls_1);

            List<IfcBuildingElement> Walls_2 = ExtractObjects(IfcModel, "IfcWall");
            Elements.AddRange(Walls_2);

            List<IfcBuildingElement> Walls_3 = ExtractObjects(IfcModel, "IfcWallElementedCase");
            Elements.AddRange(Walls_3);


            // Slab: exclude slabs belonging IfcStair and IfcRoof
            List<IfcBuildingElement> Slabs_1 = ExtractObjects(IfcModel, "IfcSlabStandardCase");
            Elements.AddRange(Slabs_1);

            List<IfcBuildingElement> Slabs_2 = ExtractObjects(IfcModel, "IfcSlab"); ;
            Elements.AddRange(Slabs_2);

            List<IfcBuildingElement> Slabs_3 = ExtractObjects(IfcModel, "IfcSlabElementedCase");
            Elements.AddRange(Slabs_3);

            // Note: The above objects refer to individual objects, which do not include components of IfcStair and IfcRoof
            // Roof
            List<IfcBuildingElement> Roofs = ExtractObjects(IfcModel, "IfcRoof");
            Elements.AddRange(Roofs);
                     
            return Elements;
        }

        private List<IfcBuildingElement> ExtractObjects(Int64 IfcModel, string objType)
        {
            List<IfcBuildingElement> result = new List<IfcBuildingElement>();

            BuildingElementType type = new BuildingElementType();
            if (objType == "IfcColumn" || objType == "IfcColumnStandardCase")
                type = BuildingElementType.IfcColumnStandardCase;
            else if (objType == "IfcBeam" || objType == "IfcBeamStandardCase")
                type = BuildingElementType.IfcBeamStandardCase;
            else if (objType == "IfcCovering")
                type = BuildingElementType.IfcCovering;
            else if (objType == "IfcShadingDevice")
                type = BuildingElementType.IfcShadingDevice;
            else if (objType == "IfcWindow" || objType == "IfcWindowStandardCase")
                type = BuildingElementType.IfcWindowStandardCase;
            else if (objType == "IfcDoor" || objType == "IfcDoorStandardCase")
                type = BuildingElementType.IfcDoorStandardCase;
            else if (objType == "IfcOpeningElement" || objType == "IfcOpeningStandardCase")
                type = BuildingElementType.IfcOpeningStandardCase;
            else if (objType == "IfcCurtainWall")
                type = BuildingElementType.IfcCurtainWall;
            else if (objType == "IfcWall" || objType == "IfcWallStandardCase" || objType == "IfcWallElementedCase")
                type = BuildingElementType.IfcWallStandardCase;
            else if (objType == "IfcSlab" || objType == "IfcSlabStandardCase" || objType == "IfcSlabElementedCase")
                type = BuildingElementType.IfcSlabStandardCase;
            else if (objType == "IfcRoof")
                type = BuildingElementType.IfcRoof;

            Int64 ObjInstances = IfcEngine2019.sdaiGetEntityExtentBN(IfcModel, objType);
            Int64 NumObjs = IfcEngine2019.sdaiGetMemberCount(ObjInstances);
            if (NumObjs != 0)
            {
                for (int i = 0; i < NumObjs; i++)
                {
                    Int64 Instance = 0;
                    IfcEngine2019.engiGetAggrElement(ObjInstances, i, IfcEngine2019.sdaiINSTANCE, out Instance);
                    IfcBuildingElement obj = new IfcBuildingElement(IfcModel, Instance, type, "ifcengine2019");

                    if (type != BuildingElementType.IfcRoof)
                    {
                        // Exclude IfcSlabStandardCase belonging to IfcStair and IfcRoof
                        bool _stair = false;
                        bool _roof = false;
                        Int64 IfcRelAggregatesInstances = 0;
                        IfcEngine2019.sdaiGetAttrBN(Instance, "Decomposes", IfcEngine2019.sdaiAGGR, out IfcRelAggregatesInstances);
                        Int64 Num_relAggregates = IfcEngine2019.sdaiGetMemberCount(IfcRelAggregatesInstances);
                        if (Num_relAggregates != 0)
                        {
                            Int64 IfcRelAggregatesInstance = 0;
                            IfcEngine2019.engiGetAggrElement(IfcRelAggregatesInstances, 0, IfcEngine2019.sdaiINSTANCE, out IfcRelAggregatesInstance);

                            Int64 IfcStairInstance = 0;
                            IfcEngine2019.sdaiGetAttrBN(IfcRelAggregatesInstance, "RelatingObject", IfcEngine2019.sdaiINSTANCE, out IfcStairInstance);
                            if (IsInstanceOf(IfcModel, IfcStairInstance, "IfcStair"))
                                _stair = true;
                            else if (IsInstanceOf(IfcModel, IfcStairInstance, "IfcRoof"))
                                _roof = true;
                        }
                        if (!_stair && !_roof)
                        {
                            if (obj.FacetedBrep != null)
                                result.Add(obj);
                        }
                    }
                    else
                    {
                        if (obj.FacetedBrep != null)
                            result.Add(obj);
                    }
                }
            }
            return result;
        }



        private bool IsInstanceOf(Int64 IfcModel, Int64 iInstance, string strType)
        {
            if (IfcEngine2019.sdaiGetInstanceType(iInstance) == IfcEngine2019.sdaiGetEntity(IfcModel, strType))
            {
                return true;
            }
            return false;
        }

        // Open an IFC file and visualize the space boundary geometry
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {         
            OpenFileDialog _OpenDialogBox = new OpenFileDialog();
            _OpenDialogBox.Title = "Open IFC file";
            _OpenDialogBox.Filter = "IFC files|*.ifc";
            if (_OpenDialogBox.ShowDialog() != DialogResult.OK)
            {
                return;
            }
            this.IfcFilePath = _OpenDialogBox.FileName;

            if (ifcModel.IfcModelLoad(_OpenDialogBox.FileName))
            {
                this.Text = string.Format("{0} - 2ndLevelSBValidation", Path.GetFileNameWithoutExtension(_OpenDialogBox.FileName));
                this.splitContainer_Visualization.Panel2.BackColor = Color.Transparent;         
            }
            elementTypes = ElementType_TypeInstances(ifcModel.ifcModel);
            dimensionalScale = new IfcDimensionalScale(ifcModel.ifcModel).scale;

            // IfcRelSpaceBoundary instances
            Int64 SBInstances = IfcEngine.sdaiGetEntityExtentBN(ifcModel.ifcModel, "IfcRelSpaceBoundary");
            Int64 NumSBs = IfcEngine.sdaiGetMemberCount(SBInstances);
            if (NumSBs == 0)
            {
                SBInstances = IfcEngine.sdaiGetEntityExtentBN(ifcModel.ifcModel, "IfcRelSpaceBoundary2ndLevel");
                NumSBs = IfcEngine.sdaiGetMemberCount(SBInstances);
            }
            if (NumSBs != 0)
            {
                for (int i = 0; i < NumSBs; i++)
                {
                    Int64 SBInstance = 0;
                    IfcEngine.engiGetAggrElement(SBInstances, i, IfcEngine.sdaiINSTANCE, out SBInstance);
                    SBs.Add(new IfcRelSpaceBoundary(ifcModel.ifcModel, SBInstance, elementTypes));
                }
            }

            // write out all the SBs' global geometry in a text file
            string outputPath = this.IfcFilePath + "_SBGlobalGeometry.txt";
            using (StreamWriter writer = new StreamWriter(outputPath, false)) // 'false' to overwrite the file if it exists
            {
                foreach (var sb in SBs)
                {
                    string vertex = "";
                    foreach (var v in sb.Polygon3D_WCS.Vertices)
                    {
                        vertex += (v.x.ToString() + " " + v.y.ToString() + " " + v.z.ToString() + " ");
                    }

                    string line = sb.GlobalID + " " + vertex;

                    writer.WriteLine(line);
                }
            }



            // Extract all building elements using IfcModel2019
            // !!!! Note: all other data are extracted from IfcModel 
            Int64 IfcModel2019 = 0;
            IfcModel2019 = IfcEngine2019.sdaiOpenModelBNUnicode(0, Encoding.Unicode.GetBytes(IfcFilePath), Encoding.Unicode.GetBytes(ifcModel.SchemaName));
            List<IfcBuildingElement> BuildingElements = BuildingElementsExtraction(IfcModel2019);           
            IfcEngine2019.sdaiCloseModel(IfcModel2019);
            foreach (var item in BuildingElements)
            {
                if (item.FacetedBrep != null)
                    Elements_IfcModel2019.Add(item);
            }
        }

        private Dictionary<BuildingElementType, List<Int64>> ElementType_TypeInstances(Int64 IfcModel)
        {
            Dictionary<BuildingElementType, List<Int64>> result = new Dictionary<BuildingElementType, List<Int64>>();

            // Determine different entites in the model
            Int64 wall1 = IfcEngine.sdaiGetEntity(IfcModel, "IfcWallStandardCase"); // for the API, it does not distingusih capital and small letter.
            Int64 wall2 = IfcEngine.sdaiGetEntity(IfcModel, "IfcWall");
            Int64 wall3 = IfcEngine.sdaiGetEntity(IfcModel, "IfcWallElementedCase");
            List<Int64> walls = new List<Int64>();
            walls.Add(wall1);
            walls.Add(wall2);
            walls.Add(wall3);
            result.Add(BuildingElementType.IfcWallStandardCase, walls);

            List<Int64> CWalls = new List<Int64>();
            Int64 CWall = IfcEngine.sdaiGetEntity(IfcModel, "IfcCurtainWall");
            CWalls.Add(CWall);
            result.Add(BuildingElementType.IfcCurtainWall, CWalls);

            Int64 slab1 = IfcEngine.sdaiGetEntity(IfcModel, "IfcSlab");
            Int64 slab2 = IfcEngine.sdaiGetEntity(IfcModel, "IfcSlabStandardCase");
            Int64 slab3 = IfcEngine.sdaiGetEntity(IfcModel, "IfcSlabElementedCase");
            List<Int64> slabs = new List<Int64>();
            slabs.Add(slab1);
            slabs.Add(slab2);
            slabs.Add(slab3);
            result.Add(BuildingElementType.IfcSlabStandardCase, slabs);

            Int64 window1 = IfcEngine.sdaiGetEntity(IfcModel, "IfcWindow");
            Int64 window2 = IfcEngine.sdaiGetEntity(IfcModel, "IfcWindowStandardCase");
            List<Int64> windows = new List<Int64>();
            windows.Add(window1);
            windows.Add(window2);
            result.Add(BuildingElementType.IfcWindowStandardCase, windows);

            Int64 door1 = IfcEngine.sdaiGetEntity(IfcModel, "IfcDoor");
            Int64 door2 = IfcEngine.sdaiGetEntity(IfcModel, "IfcDoorStandardCase");
            List<Int64> doors = new List<Int64>();
            doors.Add(door1);
            doors.Add(door2);
            result.Add(BuildingElementType.IfcDoorStandardCase, doors);

            Int64 column1 = IfcEngine.sdaiGetEntity(IfcModel, "IfcColumn");
            Int64 column2 = IfcEngine.sdaiGetEntity(IfcModel, "IfcColumnStandardCase");
            List<Int64> columns = new List<Int64>();
            columns.Add(column1);
            columns.Add(column2);
            result.Add(BuildingElementType.IfcColumnStandardCase, columns);

            Int64 beam1 = IfcEngine.sdaiGetEntity(IfcModel, "IfcBeam");
            Int64 beam2 = IfcEngine.sdaiGetEntity(IfcModel, "IfcBeamStandardCase");
            List<Int64> beams = new List<Int64>();
            beams.Add(beam1);
            beams.Add(beam2);
            result.Add(BuildingElementType.IfcBeamStandardCase, beams);

            Int64 ceiling = IfcEngine.sdaiGetEntity(IfcModel, "IfcCovering");
            List<Int64> ceilings = new List<Int64>();
            ceilings.Add(ceiling);
            result.Add(BuildingElementType.IfcCovering, ceilings);

            Int64 shading = IfcEngine.sdaiGetEntity(IfcModel, "IfcShadingDevice");
            List<Int64> shadings = new List<Int64>();
            shadings.Add(shading);
            result.Add(BuildingElementType.IfcShadingDevice, shadings);
        
            Int64 roof = IfcEngine.sdaiGetEntity(IfcModel, "IfcRoof");
            List<Int64> roofs = new List<Int64>();
            roofs.Add(roof);
            result.Add(BuildingElementType.IfcRoof, roofs);

            Int64 opening1 = IfcEngine.sdaiGetEntity(IfcModel, "IfcOpeningElement");
            Int64 opening2 = IfcEngine.sdaiGetEntity(IfcModel, "IfcOpeningStandardCase");
            List<Int64> openings = new List<Int64>();
            openings.Add(opening1);
            openings.Add(opening2);
            result.Add(BuildingElementType.IfcOpeningStandardCase, openings);

            Int64 virtualElement = IfcEngine.sdaiGetEntity(IfcModel, "IfcVirtualElement");
            List<Int64> virtualElements = new List<Int64>();
            virtualElements.Add(virtualElement);
            result.Add(BuildingElementType.IfcVirtualElement, virtualElements);

            return result;
        }

        // Exist the application
        private void exiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    
        // Wireframe model visual mode
        private void wireframeModelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (wireframeModelToolStripMenuItem == sender)
            {
                ifcRenderer.ShowWireframes = wireframeModelToolStripMenuItem.Checked;
            }
        }

        // surface model visual mode
        private void surfaceModelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (surfaceModelToolStripMenuItem == sender)
            {
                ifcRenderer.ShowFaces = surfaceModelToolStripMenuItem.Checked;
            }
        }

        // reset the visualization mode
        private void resetToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ifcRenderer.Reset();
        }
      
    }

    public class RuleDescription
    {
        public string SR_0 = "This rule consists of two sub-rules: " + "\r\n" + "\r\n" +
                       "SR.0.1: The Coordinates of an IfcRelSpaceBoundary2ndLevel./…/.IfcAxis2Placement3D.Location.IfcCartesianPoint instance shall have three values." + "\r\n" + "\r\n" +
                       "SR.0.2: The Coordinates of an IfcRelSpaceBoundary2ndLevel./…/.IfcPolyline.Points.IfcCartesianPoint instance shall have two values.";
        public string SR_1 = "This rule consists of two sub-rules: " + "\r\n" + "\r\n" +
                       "SR1.1: IF RelatedBuildingElement ∈ {IfcDoor, IfcWindow, IfcOpeningElement, IfcShadingDevice}, THEN ParentBoundary must reference an IfcRelSpaceBoundary2ndLevel instance." + "\r\n" + "\r\n" +                     
                       "SR1.2: For IfcRelSpaceBoundary2ndLevel./.../.IfcAxis2Placement3D, either both Axis and RefDirection are not given and therefore defaulted, or both shall be given and not be parallel or anti-parallel.";
        public string SR_2 = "This rule consists of two sub-rules: " + "\r\n" + "\r\n" +
                       "SR2.1: The following building elements if available and bounding spaces shall provide SBs: walls (IfcWall), curtain walls (IfcCurtainWall), slabs (IfcSlab), roofs (IfcRoof), columns (IfcColumn), beams (IfcBeam), windows (IfcWindow), doors (IfcDoor), openings (IfcOpeningElement), virtual elements (i.e., space separators; IfcVirtualElement)." + "\r\n" + "\r\n" +
                       "SR2.2: The following elements if available shall not provide SBs: stairs (IfcStair) and ramps (IfcRamp).";
        public string SR_3 = "SR.3.1: SBs of windows and doors shall reference corresponding IfcWindow and IfcDoor instances rather than the IfcOpeningElement instances via the RelatedBuildingElement attribute.";
        public string SR_4 = "SR.4.1: SBs of aggregate elements, including curtain walls and roofs, shall reference corresponding IfcCurtanWall and IfcRoof instances rather than their component element instances.";      


        public string GR_1 = "This rule consists of two sub-rules: " + "\r\n" + "\r\n" +
                       "GR1.1: The geometry of each SB shall be a simple polygon." + "\r\n" + "\r\n" +
                       "GR1.2: Non-shading SBs and shading SBs shall be defined with a normal pointing outward the relating space and the related building element respectively.";       
        public string GR_2 = "GR.2.1: Any space should be airtightly enclosed by relevant SBs that are relating to the space.";


        public string CR_1 = "This rule consists of six sub-rules: " + "\r\n" + "\r\n" +
                        "CR1.1: IF Description = “2a” AND InternalOrExternalBoundary = “INTERNAL”, THEN the object on the other side of the RelatedBuildingElement of the SB must be a space." + "\r\n" + "\r\n" +
                        "CR1.2: IF Description = “2a” AND InternalOrExternalBoundary = “EXTERNAL”, THEN the object on the other side of the RelatedBuildingElement of the SB must be the outdoor environment." + "\r\n" + "\r\n" +
                        "CR1.3: IF Description = “2a” AND InternalOrExternalBoundary = “EXTERNAL_EARTH”, THEN the object on the other side of the RelatedBuildingElement of the SB must be a site object." + "\r\n" + "\r\n" +
                        "CR1.4: IF Description = “2b”, THEN the object on the other side of the RelatedBuildingElement of the SB must be a non-shading element." + "\r\n" + "\r\n" +
                        "CR1.5: IF Description = “Shading”, THEN the SB should not bound any interior spaces." + "\r\n" + "\r\n" +
                        "CR1.6: IF Description = “2a” AND InternalOrExternalBoudary = “INTERNAL”, THEN CorrespondingBoundary must reference an IfcRelSpaceBoundary2ndLevel instance.";
        public string CR_2 = "This rule consists of two sub-rules: " + "\r\n" + "\r\n" +
                       "CR2.1: IF the RelatingSpace of the SB is a space object, THEN the SB must be included by a relevant face of the RelatingSpace." + "\r\n" + "\r\n" +
                       "CR2.2: IF the RelatedBuildingElement of the SB is not a virtual element, THEN the SB must be included by a relevant face of the RelatedBuildingElement. Note: IF the RelatedBuildingElement of the SB is a window or a door, THEN the SB must be included by a relevant face of the IfcOpeningElement instance that fill the window or the door.";
        public string CR_3 = "This rule consists of two sub-rules: " + "\r\n" +
                       "CR3.1: IF PhysicalOrVirtualBoundary = “PHYSICAL”, THEN IfcRelSpaceBoundary2ndLevel.RelatedBuildingElement ∉ {IfcVirtualElement, IfcOpeningElement}." + "\r\n" + "\r\n" +
                       "CR3.2: IF PhysicalOrVirtualBoundary = “VIRTUAL”, THEN IfcRelSpaceBoundary2ndLevel.RelatedBuildingElement ∈ {IfcVirtualElement, IfcOpeningElement}.";
        public string CR_4 = "This rule consists of two sub-rules: " + "\r\n" +
                        "CR4.1: IF ParentBoundary of the SB is another SB AND Description != “Shading”, THEN this SB must be included by that SB." + "\r\n" + "\r\n" +
                        "CR4.2: IF ParentBoundary of the SB is another SB AND Description = “Shading”, THEN this SB must connect that SB.";
        public string CR_5 = "CR.5.1: IF CorrespondingBoundary of the SB is another SB, THEN this SB must fully overlap that SB after projecting this SB on the plane where that SB lies.";
    }
}
