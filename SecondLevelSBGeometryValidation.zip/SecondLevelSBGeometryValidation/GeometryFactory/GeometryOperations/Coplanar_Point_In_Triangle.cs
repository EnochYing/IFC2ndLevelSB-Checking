﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecondLevelSBValidation
{
    public class Coplanar_Point_In_Triangle
    {
        public bool Result = false;

        // Point in coplanar with the triangle
        // Same side technique: http://blackpawn.com/texts/pointinpoly/
        // More efficient than traditional method: sum of areas or sum of angles 
        // If the point was on the same side of AB as C and is also on the same side of BC as A and on the same side of CA as B, then it is in the triangle.
        public Coplanar_Point_In_Triangle(Point3D point, Triangle3D triangle, double toleranceScale)
        {
            // this check aims to (1) improve efficiencies as in the project many points of SB are the same to the triangle vertices of triangulated Space
            // (2) improve the roboustness as the same side technique may be unreliable when the point is very closed to the vertices of triangle
            bool check = false;  
            if (point.IsSamePoint(point, triangle.Vertex1, toleranceScale))
            {
                check = true;
                Result = true;
                return;
            } else if (point.IsSamePoint(point, triangle.Vertex2, toleranceScale))
            {
                check = true;
                Result = true;
                return;
            } else if (point.IsSamePoint(point, triangle.Vertex3, toleranceScale))
            {
                check = true;
                Result = true;
                return;
            }

            if (!check)
            {
                Vector3D vector = new Vector3D();
                Vector3D AB = vector.VectorConstructor(triangle.Vertex1, triangle.Vertex2);
                Vector3D AP = vector.VectorConstructor(triangle.Vertex1, point);
                Vector3D AC = vector.VectorConstructor(triangle.Vertex1, triangle.Vertex3);

                Vector3D cross_AB_AP = vector.CrossProduct(AB, AP);
                Vector3D cross_AB_AC = vector.CrossProduct(AB, AC);
                if (vector.DotProduct(cross_AB_AP, cross_AB_AC) >= 0)
                {
                    Vector3D BC = vector.VectorConstructor(triangle.Vertex2, triangle.Vertex3);
                    Vector3D BP = vector.VectorConstructor(triangle.Vertex2, point);
                    Vector3D BA = vector.VectorConstructor(triangle.Vertex2, triangle.Vertex1);

                    Vector3D cross_BC_BP = vector.CrossProduct(BC, BP);
                    Vector3D cross_BC_BA = vector.CrossProduct(BC, BA);

                    if (vector.DotProduct(cross_BC_BP, cross_BC_BA) >= 0)
                    {
                        Vector3D CA = vector.VectorConstructor(triangle.Vertex3, triangle.Vertex1);
                        Vector3D CP = vector.VectorConstructor(triangle.Vertex3, point);
                        Vector3D CB = vector.VectorConstructor(triangle.Vertex3, triangle.Vertex2);

                        Vector3D cross_CA_CP = vector.CrossProduct(CA, CP);
                        Vector3D cross_CA_CB = vector.CrossProduct(CA, CB);

                        if (vector.DotProduct(cross_CA_CP, cross_CA_CB) >= 0)
                        {
                            Result = true;
                        }
                    }
                }
            }
        }
    }
}
