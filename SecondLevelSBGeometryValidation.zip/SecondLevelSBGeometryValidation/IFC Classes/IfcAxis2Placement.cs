﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecondLevelSBValidation
{
    public class IfcAxis2Placement3D
    {
        public Point3D LCSLocation = new Point3D();
        public Int64 LCSLocation_Instance;
        public int LCSLocation_Dim;
        public Int64 LCSxAxis_Instance;
        public Vector3D LCSxAxis = new Vector3D();
        public int LCSxAxis_Dim;
        public Int64 LCSzAxis_Instance;
        public Vector3D LCSzAxis = new Vector3D();
        public int LCSzAxis_Dim;


        public IfcAxis2Placement3D(Int64 IfcAxis2Placement3DInstance)
        {
            //Extract the LCSLocation 
            Int64 IFCCartesianPointInstance = 0;
            Int64 CoordinatesInstance = 0;
            IfcEngine.sdaiGetAttrBN(IfcAxis2Placement3DInstance, "Location", IfcEngine.sdaiINSTANCE, out IFCCartesianPointInstance);
            this.LCSLocation_Instance = IFCCartesianPointInstance;
            IfcEngine.sdaiGetAttrBN(IFCCartesianPointInstance, "Coordinates", IfcEngine.sdaiAGGR, out CoordinatesInstance);
            Int64 NumCoordinatesInstance = IfcEngine.sdaiGetMemberCount(CoordinatesInstance);
            if (NumCoordinatesInstance == 3)
            {
                List<double> LCSPoint = new List<double>();
                for (Int64 iCoordinatesInstance = 0; iCoordinatesInstance < NumCoordinatesInstance; iCoordinatesInstance++)
                {
                    double Coordinates = 0;
                    IfcEngine.engiGetAggrElement(CoordinatesInstance, iCoordinatesInstance, IfcEngine.sdaiREAL, out Coordinates);
                    LCSPoint.Add(Coordinates);
                    //MessageBox.Show(LCSzAxis[Convert.ToInt32(izAxisInstance)].ToString());
                }
                this.LCSLocation.x = LCSPoint[0];
                this.LCSLocation.y = LCSPoint[1];
                this.LCSLocation.z = LCSPoint[2];
                this.LCSLocation_Dim = 3;
                //MessageBox.Show(LCSPoint[2].ToString());         
            }
            if (NumCoordinatesInstance == 2)
            {
                this.LCSLocation_Dim = 2;
            }



            // extract the LCSToRelatingSpace.Axis (z axis)(placement information)
            Int64 IFCDirection1Instance = 0;
            Int64 zAxisInstance = 0;
            IfcEngine.sdaiGetAttrBN(IfcAxis2Placement3DInstance, "Axis", IfcEngine.sdaiINSTANCE, out IFCDirection1Instance);

            if (IFCDirection1Instance == 0)  // If Axis and/or RefDirection is omitted, these directions are taken from the geometric coordinate system.
            {
                this.LCSzAxis.x = 0;
                this.LCSzAxis.y = 0;
                this.LCSzAxis.z = 1;
                this.LCSzAxis_Instance = 0;
            }
            else
            {
                IfcEngine.sdaiGetAttrBN(IFCDirection1Instance, "DirectionRatios", IfcEngine.sdaiAGGR, out zAxisInstance);
                Int64 NumzAxisInstance = IfcEngine.sdaiGetMemberCount(zAxisInstance);
                if (NumzAxisInstance == 3)
                {
                    List<double> _LCSzAxis = new List<double>();
                    for (Int64 izAxisInstance = 0; izAxisInstance < NumzAxisInstance; izAxisInstance++)
                    {
                        double zAxis = 0;
                        IfcEngine.engiGetAggrElement(zAxisInstance, izAxisInstance, IfcEngine.sdaiREAL, out zAxis);
                        _LCSzAxis.Add(zAxis);
                    }
                    this.LCSzAxis.x = _LCSzAxis[0];
                    this.LCSzAxis.y = _LCSzAxis[1];
                    this.LCSzAxis.z = _LCSzAxis[2];
                    this.LCSzAxis_Dim = 3;
                }

                if (NumzAxisInstance == 2)
                {
                    this.LCSzAxis_Dim = 2;
                }
            }

            // extract the LCSToRelatingSpace.RefDirection (x axis) (placement information)
            Int64 IFCDirection2Instance = 0;
            IfcEngine.sdaiGetAttrBN(IfcAxis2Placement3DInstance, "RefDirection", IfcEngine.sdaiINSTANCE, out IFCDirection2Instance);

            if (IFCDirection2Instance == 0)  // directly use the geometric coordinate system 
            {
                this.LCSxAxis.x = 1;
                this.LCSxAxis.y = 0;
                this.LCSxAxis.z = 0;
                this.LCSxAxis_Instance = 0;
            }
            else
            {
                Int64 xAxisInstance = 0;
                IfcEngine.sdaiGetAttrBN(IFCDirection2Instance, "DirectionRatios", IfcEngine.sdaiAGGR, out xAxisInstance);
                Int64 NumxAxisInstance = IfcEngine.sdaiGetMemberCount(xAxisInstance);
                if (NumxAxisInstance == 3)
                {
                    List<double> _LCSxAxis = new List<double>();
                    for (Int64 ixAxisInstance = 0; ixAxisInstance < NumxAxisInstance; ixAxisInstance++)
                    {
                        double xAxis = 0;
                        IfcEngine.engiGetAggrElement(xAxisInstance, ixAxisInstance, IfcEngine.sdaiREAL, out xAxis);
                        _LCSxAxis.Add(xAxis);
                    }
                    this.LCSxAxis.x = _LCSxAxis[0];
                    this.LCSxAxis.y = _LCSxAxis[1];
                    this.LCSxAxis.z = _LCSxAxis[2];
                    this.LCSxAxis_Dim = 3;
                }

                if (NumxAxisInstance == 2) // for validation purpose
                {
                    this.LCSxAxis_Dim = 2;
                }
            }
        }

    }

    public class IfcAxis2Placement3D_IfcEngine
    {
        public Point3D LCSLocation = new Point3D();
        public Int64 LCSxAxis_Instance;
        public Vector3D LCSxAxis = new Vector3D();
        public Int64 LCSzAxis_Instance;
        public Vector3D LCSzAxis = new Vector3D();

        public IfcAxis2Placement3D_IfcEngine(Int64 IfcAxis2Placement3DInstance)
        {
            //Extract the LCSLocation 
            Int64 IFCCartesianPointInstance = 0;
            Int64 CoordinatesInstance = 0;
            IfcEngine.sdaiGetAttrBN(IfcAxis2Placement3DInstance, "Location", IfcEngine.sdaiINSTANCE, out IFCCartesianPointInstance);
            IfcEngine.sdaiGetAttrBN(IFCCartesianPointInstance, "Coordinates", IfcEngine.sdaiAGGR, out CoordinatesInstance);
            Int64 NumCoordinatesInstance = IfcEngine.sdaiGetMemberCount(CoordinatesInstance);
            if (NumCoordinatesInstance != 0)
            {
                List<double> LCSPoint = new List<double>();
                for (Int64 iCoordinatesInstance = 0; iCoordinatesInstance < NumCoordinatesInstance; iCoordinatesInstance++)
                {
                    double Coordinates = 0;
                    IfcEngine.engiGetAggrElement(CoordinatesInstance, iCoordinatesInstance, IfcEngine.sdaiREAL, out Coordinates);
                    LCSPoint.Add(Coordinates);
                    //MessageBox.Show(LCSzAxis[Convert.ToInt32(izAxisInstance)].ToString());
                }
                this.LCSLocation.x = LCSPoint[0];
                this.LCSLocation.y = LCSPoint[1];
                this.LCSLocation.z = LCSPoint[2];
                //MessageBox.Show(LCSPoint[2].ToString());         
            }

            // extract the LCSToRelatingSpace.Axis (z axis)(placement information)
            Int64 IFCDirection1Instance = 0;
            Int64 zAxisInstance = 0;
            IfcEngine.sdaiGetAttrBN(IfcAxis2Placement3DInstance, "Axis", IfcEngine.sdaiINSTANCE, out IFCDirection1Instance);

            if (IFCDirection1Instance == 0)  // If Axis and/or RefDirection is omitted, these directions are taken from the geometric coordinate system.
            {
                this.LCSzAxis.x = 0;
                this.LCSzAxis.y = 0;
                this.LCSzAxis.z = 1;
                this.LCSzAxis_Instance = 0;
            }
            else
            {
                IfcEngine.sdaiGetAttrBN(IFCDirection1Instance, "DirectionRatios", IfcEngine.sdaiAGGR, out zAxisInstance);
                Int64 NumzAxisInstance = IfcEngine.sdaiGetMemberCount(zAxisInstance);
                if (NumzAxisInstance != 0)
                {
                    List<double> _LCSzAxis = new List<double>();
                    for (Int64 izAxisInstance = 0; izAxisInstance < NumzAxisInstance; izAxisInstance++)
                    {
                        double zAxis = 0;
                        IfcEngine.engiGetAggrElement(zAxisInstance, izAxisInstance, IfcEngine.sdaiREAL, out zAxis);
                        _LCSzAxis.Add(zAxis);
                        //MessageBox.Show(LCSzAxis[Convert.ToInt32(izAxisInstance)].ToString());
                    }
                    this.LCSzAxis.x = _LCSzAxis[0];
                    this.LCSzAxis.y = _LCSzAxis[1];
                    this.LCSzAxis.z = _LCSzAxis[2];
                    //MessageBox.Show(_SpaceBoundary.SBLCSToRelatingSpace.zaxis.x.ToString());
                }
            }

            // extract the LCSToRelatingSpace.RefDirection (x axis) (placement information)
            Int64 IFCDirection2Instance = 0;
            IfcEngine.sdaiGetAttrBN(IfcAxis2Placement3DInstance, "RefDirection", IfcEngine.sdaiINSTANCE, out IFCDirection2Instance);

            if (IFCDirection2Instance == 0)  // directly use the geometric coordinate system 
            {
                this.LCSxAxis.x = 1;
                this.LCSxAxis.y = 0;
                this.LCSxAxis.z = 0;
                this.LCSxAxis_Instance = 0;
            }
            else
            {
                Int64 xAxisInstance = 0;
                IfcEngine.sdaiGetAttrBN(IFCDirection2Instance, "DirectionRatios", IfcEngine.sdaiAGGR, out xAxisInstance);
                Int64 NumxAxisInstance = IfcEngine.sdaiGetMemberCount(xAxisInstance);
                if (NumxAxisInstance != 0)
                {
                    List<double> _LCSxAxis = new List<double>();
                    for (Int64 ixAxisInstance = 0; ixAxisInstance < NumxAxisInstance; ixAxisInstance++)
                    {
                        double xAxis = 0;
                        IfcEngine.engiGetAggrElement(xAxisInstance, ixAxisInstance, IfcEngine.sdaiREAL, out xAxis);
                        _LCSxAxis.Add(xAxis);
                        //MessageBox.Show(LCSxAxis[Convert.ToInt32(ixAxisInstance)].ToString());
                    }
                    this.LCSxAxis.x = _LCSxAxis[0];
                    this.LCSxAxis.y = _LCSxAxis[1];
                    this.LCSxAxis.z = _LCSxAxis[2];
                    //MessageBox.Show(_SpaceBoundary.SBLCSToRelatingSpace.xaxis.y.ToString());              
                }
            }
        }

    }

    public class IfcAxis2Placement2D
    {
        public Point2D LCSLocation = new Point2D();
        public Vector2D LCSxAxis = new Vector2D();

        public IfcAxis2Placement2D(Int64 IfcAxis2Placement2DInstance)
        {
            //Extract the LCSLocation 
            Int64 IFCCartesianPointInstance = 0;
            Int64 CoordinatesInstance = 0;
            IfcEngine.sdaiGetAttrBN(IfcAxis2Placement2DInstance, "Location", IfcEngine.sdaiINSTANCE, out IFCCartesianPointInstance);
            IfcEngine.sdaiGetAttrBN(IFCCartesianPointInstance, "Coordinates", IfcEngine.sdaiAGGR, out CoordinatesInstance);
            Int64 NumCoordinatesInstance = IfcEngine.sdaiGetMemberCount(CoordinatesInstance);
            if (NumCoordinatesInstance != 0)
            {
                List<double> LCSPoint = new List<double>();
                for (Int64 iCoordinatesInstance = 0; iCoordinatesInstance < NumCoordinatesInstance; iCoordinatesInstance++)
                {
                    double Coordinates = 0;
                    IfcEngine.engiGetAggrElement(CoordinatesInstance, iCoordinatesInstance, IfcEngine.sdaiREAL, out Coordinates);
                    LCSPoint.Add(Coordinates);
                    //MessageBox.Show(LCSzAxis[Convert.ToInt32(izAxisInstance)].ToString());
                }
                this.LCSLocation.x = LCSPoint[0];
                this.LCSLocation.y = LCSPoint[1];
                //MessageBox.Show(LCSPoint[2].ToString());         
            }

            // extract the LCSToRelatingSpace.RefDirection (x axis) (placement information)
            Int64 IFCDirection2Instance = 0;
            IfcEngine.sdaiGetAttrBN(IfcAxis2Placement2DInstance, "RefDirection", IfcEngine.sdaiINSTANCE, out IFCDirection2Instance);

            if (IFCDirection2Instance == 0) // if it is null, directly use geometric coordinate system
            {
                this.LCSxAxis.x = 1;
                this.LCSxAxis.y = 0;
            }
            else
            {
                Int64 xAxisInstance = 0;
                IfcEngine.sdaiGetAttrBN(IFCDirection2Instance, "DirectionRatios", IfcEngine.sdaiAGGR, out xAxisInstance);
                Int64 NumxAxisInstance = IfcEngine.sdaiGetMemberCount(xAxisInstance);
                if (NumxAxisInstance != 0)
                {
                    List<double> _LCSxAxis = new List<double>();
                    for (Int64 ixAxisInstance = 0; ixAxisInstance < NumxAxisInstance; ixAxisInstance++)
                    {
                        double xAxis = 0;
                        IfcEngine.engiGetAggrElement(xAxisInstance, ixAxisInstance, IfcEngine.sdaiREAL, out xAxis);
                        _LCSxAxis.Add(xAxis);
                    }
                    this.LCSxAxis.x = _LCSxAxis[0];
                    this.LCSxAxis.y = _LCSxAxis[1];
                }
            }

        }
    }
}
