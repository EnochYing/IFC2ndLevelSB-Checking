﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MathNet.Numerics.LinearAlgebra;


namespace SecondLevelSBValidation
{
    public class Ray3D_Triangle3D_do_Intersection
    {
        // if there exists more than one intersection points (ray coplanar triangle), return the first intersection point
        public Boolean Intersection = false;
        public Point3D IntersectionPoint = new Point3D(); // MUST initialization
        public Triangle3D Triangle = new Triangle3D();  // intersected triangle
        public double Distance = 0;

        #region Möller–Trumbore intersection algorithm
        // Möller, Tomas; Trumbore, Ben(1997). "Fast, Minimum Storage Ray-Triangle Intersection". 
        // Journal of Graphics Tools. 2: 21–28. doi:10.1080/10867651.1997.10487468
        #endregion
        public Ray3D_Triangle3D_do_Intersection(Ray3D ray, Triangle3D triangle)
        {
            const double EPSILON = 0.000000001;
            Vector3D vect = new Vector3D();

            Vector3D vertex0 = vect.NewVector(triangle.Vertex1);
            Vector3D vertex1 = vect.NewVector(triangle.Vertex2);
            Vector3D vertex2 = vect.NewVector(triangle.Vertex3);

            Vector3D edge1, edge2, h, s, q = new Vector3D();
            double a, f, u, v = 0;

            edge1 = vect.Subtraction(vertex0, vertex1);
            edge2 = vect.Subtraction(vertex0, vertex2);
            h = vect.CrossProduct(ray.Direction, edge2);
            a = vect.DotProduct(edge1, h);

            if (Math.Abs(a) < EPSILON)
                Intersection = false;
            else
            {
                f = 1 / a;
                s = vect.Subtraction(vertex0, vect.NewVector(ray.StartPoint));
                u = f * vect.DotProduct(s, h);
                if (u < 0.0 || u > 1.0)
                    Intersection = false;
                else
                {
                    q = vect.CrossProduct(s, edge1);
                    v = f * vect.DotProduct(ray.Direction, q);
                    if (v < 0.0 || (u + v) > 1.0)
                        Intersection = false;
                    else
                    {
                        double t = f * vect.DotProduct(edge2, q);
                        if (t > EPSILON)
                        {
                            Intersection = true;
                            Vector3D IP = vect.Addition
                                (vect.NewVector(ray.StartPoint), vect.Multiply_double_Vector3D(t, ray.Direction));
                            IntersectionPoint.x = IP.x;
                            IntersectionPoint.y = IP.y;
                            IntersectionPoint.z = IP.z;
                        }
                        else
                            Intersection = false;
                    }
                }
            }
        }      
    }
}

