﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecondLevelSBValidation
{
    public class BoundingBox3D
    {
        public double xmin = 0;
        public double ymin = 0;
        public double zmin = 0;
        public double xmax = 0;
        public double ymax = 0;
        public double zmax = 0;

        // create a root bounding box that contains a sequence of 3D triangles
        // !!! degeneration cases have not been considered: for example --- all the triangles belongs to one surface
        public BoundingBox3D (List<Triangle3D> Triangles)
        {
            List<double> _ListXmax = new List<double>();
            List<double> _ListXmin = new List<double>();
            List<double> _ListYmax = new List<double>();
            List<double> _ListYmin = new List<double>();
            List<double> _ListZmax = new List<double>();
            List<double> _ListZmin = new List<double>();

            for (int i = 0; i < Triangles.Count; i++)
            {
                double _xmin = 0;
                double _ymin = 0;
                double _zmin = 0;
                double _xmax = 0;
                double _ymax = 0;
                double _zmax = 0;

                double[] listx = { Triangles[i].Vertex1.x, Triangles[i].Vertex2.x, Triangles[i].Vertex3.x };
                _xmin = listx.Min();
                _xmax = listx.Max();
                double[] listy = { Triangles[i].Vertex1.y, Triangles[i].Vertex2.y, Triangles[i].Vertex3.y };
                _ymin = listy.Min();
                _ymax = listy.Max();
                double[] listz = { Triangles[i].Vertex1.z, Triangles[i].Vertex2.z, Triangles[i].Vertex3.z };
                _zmin = listz.Min();
                _zmax = listz.Max();

                _ListXmax.Add(_xmax);
                _ListYmax.Add(_ymax);
                _ListZmax.Add(_zmax);
                _ListXmin.Add(_xmin);
                _ListYmin.Add(_ymin);
                _ListZmin.Add(_zmin);
            }
            this.xmax = _ListXmax.Max();
            this.ymax = _ListYmax.Max();
            this.zmax = _ListZmax.Max();
            this.xmin = _ListXmin.Min();
            this.ymin = _ListYmin.Min();
            this.zmin = _ListZmin.Min();
        }

        public BoundingBox3D()
        {      
        }

        public BoundingBox3D BoundingBox3D_Polygons_Create(List<Polyline3D> Polygons)
        {
            BoundingBox3D _BoundingBox = new BoundingBox3D();
            List<double> _ListXmax = new List<double>();
            List<double> _ListXmin = new List<double>();
            List<double> _ListYmax = new List<double>();
            List<double> _ListYmin = new List<double>();
            List<double> _ListZmax = new List<double>();
            List<double> _ListZmin = new List<double>();

            for (int i = 0; i < Polygons.Count; i++)
            {
                double _xmin = 0;
                double _ymin = 0;
                double _zmin = 0;
                double _xmax = 0;
                double _ymax = 0;
                double _zmax = 0;

                List<double> listx = new List<double>();
                List<double> listy = new List<double>();
                List<double> listz = new List<double>();
                foreach (var vertex in Polygons[i].Vertices)
                {
                    listx.Add(vertex.x);
                    listy.Add(vertex.y);
                    listz.Add(vertex.z);
                }
                _xmin = listx.Min();
                _xmax = listx.Max();

                _ymin = listy.Min();
                _ymax = listy.Max();

                _zmin = listz.Min();
                _zmax = listz.Max();

                _ListXmax.Add(_xmax);
                _ListYmax.Add(_ymax);
                _ListZmax.Add(_zmax);
                _ListXmin.Add(_xmin);
                _ListYmin.Add(_ymin);
                _ListZmin.Add(_zmin);
            }
            _BoundingBox.xmax = _ListXmax.Max();
            _BoundingBox.ymax = _ListYmax.Max();
            _BoundingBox.zmax = _ListZmax.Max();
            _BoundingBox.xmin = _ListXmin.Min();
            _BoundingBox.ymin = _ListYmin.Min();
            _BoundingBox.zmin = _ListZmin.Min();

            return _BoundingBox;
        }
    }

    
}
