﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using EarClipperLib;


namespace SecondLevelSBValidation
{
    public class IfcRelSpaceBoundary
    {
        public Int64 Instance;
        public string InstanceName; // P21 Line
        public string GlobalID;
        public string Description; // new to space watertightness checking
        //public Int64 RelatingSpaceInstance; // had better not to use this but use GlobalID
        public SpaceType RelatingSpaceType;
        public string RelatingSpaceGlobalID;
        public string RelatingSpaceInstanceName;
        public string RelatedBuildingElementGlobalID;
        public string RelatedBuildingElementInstanceName;
        public Int64 RelatedBuildingElementInstance;  // had better not to use this but use GlobalID
        public BuildingElementType RelatedBuildingElementType; // door, window, wall, column, beam, slab, roof and other;
        public string IfcOpeningElementGlobalID;

        public Polyline2D Polygon2D_OwnLCS = new Polyline2D();

        public IfcPolyline polyline = null;
        public Polyline3D Polygon3D_InSpace = new Polyline3D();
        public bool OutputPolygon3D_InSpace = false;
        //public Polyline3D Polygon3D_InSpace_Nodigits = new Polyline3D();  // Redundant; can remove
        public List<Triangle3D> TriangulatedSB_InSpace = new List<Triangle3D>(); // will be generated only if isValidPolygon
        public IfcAxis2Placement3D Axis2Placement3D = null;

        public IfcLocalPlacement SpaceLP = null;
        public Polyline3D Polygon3D_WCS = new Polyline3D();
        //public Polyline3D Polygon3D_WCS_Nodigits = new Polyline3D();
        public List<Triangle3D> TriangulatedSB_WCS = new List<Triangle3D>(); // will be generated only if isValidPolygon

        public PhysicalOrVirtual PhysicalOrVirtualBoundary;  // new to space watertightness checking
        public InternalOrExternal InternalOrExternalBoundary; // new to space watertightness checking

        // for IfcRelSpaceBoundary2ndLevel only 
        public Int64 ParenBoundaryInstance; 
        public Int64 CorrespondingBoundaryInstance; 

        // Only assigned after GR.1.1 is executed
        public bool isValidPolygon = true;

        public IfcRelSpaceBoundary()
        {

        }

        public IfcRelSpaceBoundary(Int64 IfcModel, Int64 SBInstance, Dictionary<BuildingElementType, List<Int64>> ElementTypes)
        {
            this.Instance = SBInstance;

            Int64 instanceName = IfcEngine.internalGetP21Line(SBInstance);
            this.InstanceName = "#" + instanceName.ToString();
           
            IntPtr SBGlobalIdPtr = IntPtr.Zero;
            IfcEngine.sdaiGetAttrBN(SBInstance, "GlobalId", IfcEngine.sdaiUNICODE, out SBGlobalIdPtr);
            this.GlobalID = Marshal.PtrToStringUni(SBGlobalIdPtr);

            IntPtr DescriptionPtr = IntPtr.Zero;
            IfcEngine.sdaiGetAttrBN(SBInstance, "Description", IfcEngine.sdaiUNICODE, out DescriptionPtr);
            this.Description = Marshal.PtrToStringUni(DescriptionPtr);

            // identify the related building element GlobalID and Type
            Int64 IfcBuildingElementInstance = 0;
            IfcEngine.sdaiGetAttrBN(SBInstance, "RelatedBuildingElement", IfcEngine.sdaiINSTANCE, out IfcBuildingElementInstance);
            this.RelatedBuildingElementInstance = IfcBuildingElementInstance;

            Int64 ElementinstanceName = IfcEngine.internalGetP21Line(IfcBuildingElementInstance);
            this.RelatedBuildingElementInstanceName = "#" + ElementinstanceName.ToString();

            IntPtr BuildingElementGlobalIdPtr = IntPtr.Zero;
            IfcEngine.sdaiGetAttrBN(IfcBuildingElementInstance, "GlobalId", IfcEngine.sdaiUNICODE, out BuildingElementGlobalIdPtr);
            this.RelatedBuildingElementGlobalID = Marshal.PtrToStringUni(BuildingElementGlobalIdPtr);

            if (this.Description == "Shading")
                this.RelatedBuildingElementType = BuildingElementType.IfcShadingDevice;
            else
            {
                foreach (var e in ElementTypes)
                {
                    if (e.Value.Contains(IfcEngine.sdaiGetInstanceType(IfcBuildingElementInstance)))
                    {
                        this.RelatedBuildingElementType = e.Key;
                        break;
                    }
                }
            }
           
            // extract the GlobalID of the relating space
            Int64 IFCSpaceInstance = 0;
            IfcEngine.sdaiGetAttrBN(SBInstance, "RelatingSpace", IfcEngine.sdaiINSTANCE, out IFCSpaceInstance);
            //this.RelatingSpaceInstance = IFCSpaceInstance;
            if (IsInstanceOf(IfcModel, IFCSpaceInstance, "IfcSpace"))
                this.RelatingSpaceType = SpaceType.IfcSpace;
            else if (IsInstanceOf(IfcModel, IFCSpaceInstance, "IfcExternalSpatialElement"))
                this.RelatingSpaceType = SpaceType.IfcExternalSpatialElement;
            Int64 SpaceinstanceName = IfcEngine.internalGetP21Line(IFCSpaceInstance);
            this.RelatingSpaceInstanceName = "#" + SpaceinstanceName.ToString();
            IntPtr RelatingSpaceGlobalIDPtr = IntPtr.Zero;
            IfcEngine.sdaiGetAttrBN(IFCSpaceInstance, "GlobalID", IfcEngine.sdaiUNICODE, out RelatingSpaceGlobalIDPtr);
            this.RelatingSpaceGlobalID = Marshal.PtrToStringUni(RelatingSpaceGlobalIDPtr);

            // extract the Axis2Placement3D (placement information)
            Int64 IFCConnectionSurfaceGeometryInstance = 0;
            Int64 IFCCurveBoundedPlaneInstance = 0;
            IfcEngine.sdaiGetAttrBN(SBInstance, "ConnectionGeometry", IfcEngine.sdaiINSTANCE, out IFCConnectionSurfaceGeometryInstance);
            IfcEngine.sdaiGetAttrBN(IFCConnectionSurfaceGeometryInstance, "SurfaceOnRelatingElement", IfcEngine.sdaiINSTANCE, out IFCCurveBoundedPlaneInstance);
            Int64 IFCPlaneInstance = 0;
            Int64 IFCAxis2Placement3DInstance = 0;
            IfcEngine.sdaiGetAttrBN(IFCCurveBoundedPlaneInstance, "BasisSurface", IfcEngine.sdaiINSTANCE, out IFCPlaneInstance);
            IfcEngine.sdaiGetAttrBN(IFCPlaneInstance, "Position", IfcEngine.sdaiINSTANCE, out IFCAxis2Placement3DInstance);
            this.Axis2Placement3D = new IfcAxis2Placement3D(IFCAxis2Placement3DInstance);

            // transformation matrix calculation                   
            AffineTR _AffineTR = new AffineTR();
            double[,] TransformationMatrix = _AffineTR.TRMatrix(this.Axis2Placement3D.LCSLocation, this.Axis2Placement3D.LCSxAxis, this.Axis2Placement3D.LCSzAxis);

            // extract the SBPolyline (original geometry) (as the IFC files may not follow the MVD definition---, a general information 
            // extraction method is developed to ensure the extraction of SBs) 
            // transform SB geometry in LCS of Space
            Int64 IfcPolylineInstance = 0;
            IfcEngine.sdaiGetAttrBN(IFCCurveBoundedPlaneInstance, "OuterBoundary", IfcEngine.sdaiINSTANCE, out IfcPolylineInstance);
            PointCoordTransf PTransfer = new PointCoordTransf();
            if (IsInstanceOf(IfcModel, IfcPolylineInstance, "IfcPolyline")) // Actually according to SpaceBoundaryAddOnView, it must be IfcPolyline; here we just aim to extract SBs for geometry validation purpose
            {
                IfcPolyline _IfcPolyline = new IfcPolyline(IfcPolylineInstance);
                this.polyline = _IfcPolyline;
                if (_IfcPolyline.Polygon3D.Vertices.Count != 0)
                {
                    foreach (var p in _IfcPolyline.Polygon3D.Vertices)
                    {
                        Point2D p2d = new Point2D();
                        p2d.x = p.x;
                        p2d.y = p.y;
                        this.Polygon2D_OwnLCS.Vertices.Add(p2d);
                        this.Polygon3D_InSpace.Vertices.Add(/*KeepDigits(*/PTransfer.PointTransf3D(p, TransformationMatrix)/*, 5)*/);
                        //this.Polygon3D_InSpace_Nodigits.Vertices.Add(PTransfer.PointTransf3D(p, TransformationMatrix));
                    }                      
                }
            }
            else if (IsInstanceOf(IfcModel, IfcPolylineInstance, "IfcComPositeCurve"))
            {
                Int64 IfcCompositeCurveSegmentInstances = 0;
                IfcEngine.sdaiGetAttrBN(IfcPolylineInstance, "Segments", IfcEngine.sdaiAGGR, out IfcCompositeCurveSegmentInstances);
                Int64 Num = IfcEngine.sdaiGetMemberCount(IfcCompositeCurveSegmentInstances);
                if (Num != 0)
                {
                    for (int s = 0; s < Num; s++)
                    {
                        Int64 IfcCompositeCurveSegmentInstance = 0;
                        IfcEngine.engiGetAggrElement(IfcCompositeCurveSegmentInstances, s, IfcEngine.sdaiINSTANCE, out IfcCompositeCurveSegmentInstance);
                        Int64 ParentCurve = 0; // should be IfcPolyline
                        IfcEngine.sdaiGetAttrBN(IfcCompositeCurveSegmentInstance, "ParentCurve", IfcEngine.sdaiINSTANCE, out ParentCurve);
                        IfcPolyline _IfcPolyline = new IfcPolyline(ParentCurve);
                        if (_IfcPolyline.Polygon3D.Vertices.Count != 0) // Sometimes cooridnates defined as 3D (z should be always 0)
                        {
                            foreach (var p in _IfcPolyline.Polygon3D.Vertices)
                            {
                                Point2D p2d = new Point2D();
                                p2d.x = p.x;
                                p2d.y = p.y;
                                this.Polygon2D_OwnLCS.Vertices.Add(p2d);
                                this.Polygon3D_InSpace.Vertices.Add(/*KeepDigits(*/PTransfer.PointTransf3D(p, TransformationMatrix)/*,5)*/);
                                //this.Polygon3D_InSpace_Nodigits.Vertices.Add(PTransfer.PointTransf3D(p, TransformationMatrix));
                            }                               
                        }
                    }
                }
            }

            // calculate surface normal in Space using the surface normal transformation
            this.Polygon3D_InSpace.SurfaceNormal = this.Polygon3D_InSpace.AddSurfaceNormal(this.Polygon3D_InSpace);

            // compute SB geometry in WCS
            Int64 SpaceObjectPlacement = 0;
            IfcEngine.sdaiGetAttrBN(IFCSpaceInstance, "ObjectPlacement", IfcEngine.sdaiINSTANCE, out SpaceObjectPlacement);
            this.SpaceLP = new IfcLocalPlacement(SpaceObjectPlacement);
            if (this.Polygon3D_InSpace/*_Nodigits*/.Vertices.Count != 0)
            {
                foreach (var p in this.Polygon3D_InSpace/*_Nodigits*/.Vertices)
                {
                    this.Polygon3D_WCS.Vertices.Add(/*KeepDigits(*/PTransfer.PointTransf3D(p, this.SpaceLP.TransforMatrixToRoot)/*,5)*/);
                    //this.Polygon3D_WCS_Nodigits.Vertices.Add(PTransfer.PointTransf3D(p, this.SpaceLP.TransforMatrixToRoot));
                }                  
            }
            this.Polygon3D_WCS.SurfaceNormal = this.Polygon3D_WCS.AddSurfaceNormal(this.Polygon3D_WCS);

     
            // extract the "PhysicalOrVirtualBoundary" value
            IntPtr PhysicalOrVirtualBoundaryPtr = IntPtr.Zero;
            IfcEngine.sdaiGetAttrBN(SBInstance, "PhysicalOrVirtualBoundary", IfcEngine.sdaiUNICODE, out PhysicalOrVirtualBoundaryPtr);
            string PV = Marshal.PtrToStringUni(PhysicalOrVirtualBoundaryPtr);
            if (PV == ".PHYSICAL.")
                this.PhysicalOrVirtualBoundary = PhysicalOrVirtual.PHYSICAL;
            else if (PV == ".VIRTUAL.")
                this.PhysicalOrVirtualBoundary = PhysicalOrVirtual.VIRTUAL;
            else
                this.PhysicalOrVirtualBoundary = PhysicalOrVirtual.NOTDEFINED;

            // extract the "InternalOrExternalBoundary" value
            IntPtr InternalOrExternalBoundaryPtr = IntPtr.Zero;
            IfcEngine.sdaiGetAttrBN(SBInstance, "InternalOrExternalBoundary", IfcEngine.sdaiUNICODE, out InternalOrExternalBoundaryPtr);
            string IE = Marshal.PtrToStringUni(InternalOrExternalBoundaryPtr);
            if (IE == ".INTERNAL.")
                this.InternalOrExternalBoundary = InternalOrExternal.INTERNAL;
            else if (IE == ".EXTERNAL.")
                this.InternalOrExternalBoundary = InternalOrExternal.EXTERNAL;
            else if (IE == ".EXTERNAL_EARTH.")
                this.InternalOrExternalBoundary = InternalOrExternal.EXTERNAL_EARTH;

            // extract ParentBoundary
            Int64 parentSB = 0;
            IfcEngine.sdaiGetAttrBN(SBInstance, "ParentBoundary", IfcEngine.sdaiINSTANCE, out parentSB);
            this.ParenBoundaryInstance = parentSB;

            // extract correspondingBoundary
            Int64 correspondingSB = 0;
            IfcEngine.sdaiGetAttrBN(SBInstance, "CorrespondingBoundary", IfcEngine.sdaiINSTANCE, out correspondingSB);
            this.CorrespondingBoundaryInstance = correspondingSB;
        }
   
        // using KeepDigit()
        public void SBTriangulationSpaceLCSAndWCS()
        {
            PointCoordTransf PTransfer = new PointCoordTransf();

            List<Vector3m> polygon = new List<Vector3m>();
            foreach (var p in this.Polygon3D_InSpace.Vertices)
            {
                polygon.Add(new Vector3m(KeepDigit(p.x,6), KeepDigit(p.y,6), KeepDigit(p.z,6)));
            }

            EarClipping earClipping = new EarClipping();
            earClipping.SetPoints(polygon);
            earClipping.Triangulate();
            var res = earClipping.Result; 

            if (earClipping.success && res.Count != 0)
            {             
                for (int itri = 0; itri < res.Count / 3; itri++)
                {
                    Triangle3D triangle = new Triangle3D();
                    triangle.Vertex1 = new Point3D((double)res[3 * itri + 0].X, (double)res[3 * itri + 0].Y, (double)res[3 * itri + 0].Z);
                    triangle.Vertex2 = new Point3D((double)res[3 * itri + 1].X, (double)res[3 * itri + 1].Y, (double)res[3 * itri + 1].Z);
                    triangle.Vertex3 = new Point3D((double)res[3 * itri + 2].X, (double)res[3 * itri + 2].Y, (double)res[3 * itri + 2].Z);
                    triangle.NormalVector = this.Polygon3D_InSpace.SurfaceNormal;
                    this.TriangulatedSB_InSpace.Add(triangle);
                }

                foreach (var triangle in this.TriangulatedSB_InSpace)
                {
                    Triangle3D tri = new Triangle3D();
                    tri.Vertex1 = PTransfer.PointTransf3D(triangle.Vertex1, this.SpaceLP.TransforMatrixToRoot);
                    tri.Vertex2 = PTransfer.PointTransf3D(triangle.Vertex2, this.SpaceLP.TransforMatrixToRoot);
                    tri.Vertex3 = PTransfer.PointTransf3D(triangle.Vertex3, this.SpaceLP.TransforMatrixToRoot);
                    tri.NormalVector = this.Polygon3D_WCS.SurfaceNormal;
                    this.TriangulatedSB_WCS.Add(tri);
                }
            }
            else
                this.isValidPolygon = false;     
        }
   
        // 前 num-1 位小数值都是9, 返回a的整数+1
        // 前 num-1 位小数值都是0, 返回a的整数
        // 其他情况下, 返回a的整数以及前 num 位小数部分
        public double KeepDigit(double a, int num = 6)
        {
            double result = 0;

            if (a == 0 || Math.Abs(a) <0.00001)
                return 0;

            double b = (long)(a * Math.Pow(10, num));
            if (b == 0)
                return 0;

            string c = Convert.ToString(b);
            char[] charArray = c.ToCharArray();
            Array.Reverse(charArray);
            c = new string(charArray);
            if (charArray.Length < num)
                return a;

            c = c.Substring(1, num - 1);

            if (c == "00000")
            {
                result = Math.Floor(a);
            }
            else if (c == "99999")
            {
                result = Math.Ceiling(a);
            }
            else
            {
                result = b / (double)(Math.Pow(10, num));
            }

            return result;
        }

        public void SBTriangulation()
        {
            PointCoordTransf PTransfer = new PointCoordTransf();

            List<Vector3m> polygon = new List<Vector3m>();
            foreach (var p in this.Polygon2D_OwnLCS.Vertices)
            {
                polygon.Add(new Vector3m(p.x, p.y, 0));
            }

            EarClipping earClipping = new EarClipping();
            earClipping.SetPoints(polygon);
            earClipping.Triangulate();
            var res = earClipping.Result;

            if (earClipping.success && res.Count != 0)
            {
                List<Triangle3D> triangles = new List<Triangle3D>();
                for (int itri = 0; itri < res.Count / 3; itri++)
                {
                    Triangle3D triangle = new Triangle3D();
                    triangle.Vertex1 = new Point3D((double)res[3 * itri + 0].X, (double)res[3 * itri + 0].Y, (double)res[3 * itri + 0].Z);
                    triangle.Vertex2 = new Point3D((double)res[3 * itri + 1].X, (double)res[3 * itri + 1].Y, (double)res[3 * itri + 1].Z);
                    triangle.Vertex3 = new Point3D((double)res[3 * itri + 2].X, (double)res[3 * itri + 2].Y, (double)res[3 * itri + 2].Z);
                    triangles.Add(triangle);                  
                }

                foreach (var triangle in triangles)
                {
                    Triangle3D tri = new Triangle3D();
                    AffineTR _AffineTR = new AffineTR();
                    double[,] TRMatrix = _AffineTR.TRMatrix(this.Axis2Placement3D.LCSLocation, this.Axis2Placement3D.LCSxAxis, this.Axis2Placement3D.LCSzAxis);
                    tri.Vertex2 = PTransfer.PointTransf3D(triangle.Vertex1, TRMatrix);
                    tri.Vertex2 = PTransfer.PointTransf3D(triangle.Vertex2, TRMatrix);
                    tri.Vertex3 = PTransfer.PointTransf3D(triangle.Vertex3, TRMatrix);
                    tri.NormalVector = this.Polygon3D_InSpace.SurfaceNormal;
                    this.TriangulatedSB_InSpace.Add(tri);

                    Triangle3D tri_ = new Triangle3D();
                    tri_.Vertex1 = PTransfer.PointTransf3D(tri.Vertex1, this.SpaceLP.TransforMatrixToRoot);
                    tri_.Vertex2 = PTransfer.PointTransf3D(tri.Vertex2, this.SpaceLP.TransforMatrixToRoot);
                    tri_.Vertex3 = PTransfer.PointTransf3D(tri.Vertex3, this.SpaceLP.TransforMatrixToRoot);
                    tri_.NormalVector = this.Polygon3D_WCS.SurfaceNormal;
                    this.TriangulatedSB_WCS.Add(tri_);
                }
            }
            else
                this.isValidPolygon = false;
        }


        public IfcRelSpaceBoundary(Int64 SBInstance)
        {
            this.Instance = SBInstance;

            Int64 instanceName = IfcEngine.internalGetP21Line(SBInstance);
            this.InstanceName = "#" + instanceName.ToString();      
        }

        private bool IsInstanceOf(Int64 IfcModel, Int64 iInstance, string strType)
        {
            if (IfcEngine.sdaiGetInstanceType(iInstance) == IfcEngine.sdaiGetEntity(IfcModel, strType))
            {
                return true;
            }

            return false;
        } 
    }

    // IfcWall, IfcWindow, IfcDoor...
    public enum BuildingElementType
    {
        IfcWallStandardCase,
        IfcCurtainWall,
        IfcSlabStandardCase,
        IfcColumnStandardCase,
        IfcBeamStandardCase,
        IfcRoof,
        IfcCovering,
        IfcShadingDevice,
        IfcWindowStandardCase,
        IfcDoorStandardCase,
        IfcBuildingElementProxy,
        IfcOpeningStandardCase,  //Note: opening element actually does not belong to IfcBuildingElement; state here for convinence.
        IfcVirtualElement  // Note: same to above
    }

    public enum InternalOrExternal
    {
        INTERNAL,
        EXTERNAL,
        EXTERNAL_EARTH
    }

    public enum PhysicalOrVirtual
    {
        PHYSICAL,
        VIRTUAL,
        NOTDEFINED
    }

    public enum SpaceType
    {
        IfcSpace,
        IfcExternalSpatialElement
    }
}

