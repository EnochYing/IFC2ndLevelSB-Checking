IfcDoc
======
This project is based on .NET 2.0 and C# using Microsoft Visual Studio 2013.
